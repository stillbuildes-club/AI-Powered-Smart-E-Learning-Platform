import React from "react";
import ProgressDashboard from "./components/Dashboard/ProgressDashboard";
import RecommendedCourses from "./components/Recommendations/RecommendedCourses";

// For Week 4 this app renders the Progress Dashboard directly.
// Week 5 adds the Recommended Courses section below it.
// In the full platform these are separate routes (courses, auth, etc.)
// wired up with react-router-dom from earlier weeks.
function App() {
  return (
    <div className="App">
      <ProgressDashboard />
      <RecommendedCourses />
    </div>
  );
}

export default App;
