const mongoose = require("mongoose");

const quizSchema = new mongoose.Schema(
  {
    course: { type: mongoose.Schema.Types.ObjectId, ref: "Course", required: true },
    lesson: { type: mongoose.Schema.Types.ObjectId, ref: "Lesson" }, // optional: quiz tied to a specific lesson
    title: { type: String, required: true, trim: true },
    totalQuestions: { type: Number, required: true, default: 10 },
    passingScore: { type: Number, required: true, default: 70 }, // percentage required to pass
  },
  { timestamps: true }
);

module.exports = mongoose.model("Quiz", quizSchema);
