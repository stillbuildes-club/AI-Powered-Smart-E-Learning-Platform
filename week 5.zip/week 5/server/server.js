require("dotenv").config();
const express = require("express");
const cors = require("cors");
const connectDB = require("./config/db");

const progressRoutes = require("./routes/progressRoutes");
const activityRoutes = require("./routes/activityRoutes");
const milestoneRoutes = require("./routes/milestoneRoutes");
const recommendationRoutes = require("./routes/recommendationRoutes");

const app = express();

connectDB();

app.use(cors({ origin: process.env.CLIENT_URL || "http://localhost:3000" }));
app.use(express.json());

// Week 4 feature routes: Student Progress Dashboard, Lesson/Quiz progress,
// Activity History, Milestone Tracking, Progress Charts data.
app.use("/api/progress", progressRoutes);
app.use("/api/activity", activityRoutes);
app.use("/api/milestones", milestoneRoutes);

// Week 5 feature routes: AI-Based Course Recommendation Engine.
app.use("/api/recommendations", recommendationRoutes);

app.get("/", (req, res) => {
  res.send("E-Learning Platform API — Week 5: Recommendation Engine is running");
});

// Basic error handler
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ success: false, message: "Server error" });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
