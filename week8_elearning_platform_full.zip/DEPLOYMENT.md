# Deployment Guide — Week 7

Covers running the platform locally with Docker Compose and deploying it to
the cloud. Weeks 1–6 functionality is unchanged; this only adds
containerization, optimization, testing, and deployment tooling.

---

## 1. Local run with Docker Compose (recommended)

### Prerequisites
- Docker Desktop / Docker Engine 24+ with Compose v2 (`docker compose`, not `docker-compose`)

### Steps

```bash
# From the project root
cp .env.example .env
```

Edit `.env` and set at minimum:
```
JWT_SECRET=<a long random string>
```

Then build and start everything (MongoDB + backend + frontend):

```bash
docker compose up --build
```

- Frontend: http://localhost:8080
- Backend API: http://localhost:5000/api (also reachable via the frontend's
  nginx proxy at http://localhost:8080/api)
- MongoDB: mongodb://localhost:27017 (exposed for local inspection with
  Compass/mongosh; not required by the app itself, which talks to Mongo over
  the internal Docker network)

Stop everything:
```bash
docker compose down          # keeps volumes (DB data, uploaded files)
docker compose down -v       # also wipes the mongo_data/uploads_data volumes
```

View logs for one service:
```bash
docker compose logs -f backend
```

### How the containers talk to each other

- `frontend` (nginx) serves the built React app and reverse-proxies
  `/api/*`, `/uploads/*`, and `/socket.io/*` to `backend:5000` over the
  internal `elearning-net` Docker network — see `client/nginx.conf`.
- `backend` connects to `mongo:27017` using the Compose service name as the
  hostname (`MONGO_URI=mongodb://mongo:27017/elearning_platform` by default).
- Because the frontend is built with `REACT_APP_API_URL=/api` (relative),
  there's no CORS involved in the Dockerized setup — everything is same-origin
  from the browser's perspective, proxied by nginx.

---

## 2. Running without Docker (plain Node + npm, for reference)

```bash
# Backend
cd server
npm install
cp .env.example .env   # set MONGO_URI, JWT_SECRET, CLIENT_URL
npm run dev

# Frontend (separate terminal)
cd client
npm install
npm start
```

---

## 3. Cloud deployment

The two containers (backend, frontend) and MongoDB can be deployed
independently, which is generally the more cost-effective setup for a
student/internship project since it lets you use free tiers for each piece.

### 3.1 Database — MongoDB Atlas (recommended over self-hosting Mongo in the cloud)

1. Create a free (M0) cluster at https://www.mongodb.com/atlas
2. Create a database user and note the password
3. Under Network Access, allow access from anywhere (`0.0.0.0/0`) for a
   student project, or restrict to your hosting provider's IP range for
   something more locked-down
4. Copy the connection string — this becomes `MONGO_URI`, e.g.:
   ```
   mongodb+srv://<user>:<password>@cluster0.xxxxx.mongodb.net/elearning_platform
   ```

### 3.2 Backend — Render / Railway / Fly.io (any Docker-friendly PaaS)

These platforms build directly from `server/Dockerfile`, so no extra config
is needed beyond environment variables.

**Render (example)**
1. New → Web Service → connect the repo
2. Root directory: `server`
3. Environment: Docker (auto-detects `server/Dockerfile`)
4. Set environment variables:
   - `NODE_ENV=production`
   - `MONGO_URI=<Atlas connection string>`
   - `JWT_SECRET=<same long random string>`
   - `CLIENT_URL=<your deployed frontend URL, e.g. https://elearning.onrender.com>`
   - `RATE_LIMIT_WINDOW_MS=900000`, `RATE_LIMIT_MAX=300` (optional, defaults shown)
5. Health check path: `/api/health`
6. Deploy — Render assigns a public URL, e.g. `https://elearning-api.onrender.com`

**Railway** works the same way: New Project → Deploy from repo → set root
directory to `server` → it auto-detects the `Dockerfile` → add the same
environment variables → deploy.

Persisting uploaded assignment files: the free tiers of most PaaS platforms
use ephemeral filesystems, so files written to `server/uploads` will be lost
on redeploy/restart. For a production deployment, swap `multer`'s disk
storage (`server/middleware/upload.js`) for an S3-compatible bucket — the
rest of the codebase already treats it as an opaque `req.file.path`/`filename`,
so this is a contained change when you get there. For the internship
submission, the local-disk approach with a mounted Docker volume
(`uploads_data`, already in `docker-compose.yml`) is sufficient.

### 3.3 Frontend — same PaaS as Docker, or a static host

**Option A — Docker (same platform as the backend):**
1. New Web Service → root directory `client`
2. Build arg: `REACT_APP_API_URL=https://elearning-api.onrender.com/api`
   (point it at the backend's public URL instead of the relative `/api`
   used in the same-origin Compose setup, since frontend and backend are
   now on different domains)
3. Because frontend/backend are cross-origin now, also set the backend's
   `CLIENT_URL` env var to this frontend's URL so CORS allows it.

**Option B — Static hosting (Vercel/Netlify/Cloudflare Pages)** — cheaper
and simpler if you don't need the nginx proxy:
1. Build command: `npm run build`, output directory: `build`
2. Environment variable: `REACT_APP_API_URL=https://elearning-api.onrender.com/api`
   and `REACT_APP_SOCKET_URL=https://elearning-api.onrender.com`
3. These platforms rebuild automatically on push

### 3.4 Environment variable summary

| Variable | Where | Notes |
|---|---|---|
| `MONGO_URI` | backend | Atlas connection string in production |
| `JWT_SECRET` | backend | Must match between deploys — rotating it logs everyone out |
| `CLIENT_URL` | backend | Used for CORS + Socket.IO CORS; set to the deployed frontend origin |
| `PORT` | backend | Most PaaS platforms inject this automatically; the app respects it |
| `RATE_LIMIT_WINDOW_MS` / `RATE_LIMIT_MAX` | backend | Optional, sensible defaults apply |
| `REACT_APP_API_URL` | frontend (build-time) | `/api` for same-origin Docker Compose; full URL for cross-origin deploys |
| `REACT_APP_SOCKET_URL` | frontend (build-time) | Optional override; auto-inferred from `REACT_APP_API_URL` otherwise (see `client/src/services/socket.js`) |

Remember: CRA bakes `REACT_APP_*` variables into the JS bundle at **build
time**, not runtime — changing them requires a rebuild, not just a restart.

---

## 4. Testing

Run backend tests (Jest + Supertest + an in-memory MongoDB, no real DB needed):
```bash
cd server
npm install
npm test
```

Run frontend tests (React Testing Library, via CRA's built-in Jest runner):
```bash
cd client
npm install
npm test          # watch mode
npm run test:ci   # single run with coverage, for CI pipelines
```

---

## 5. Health checks & monitoring

- `GET /api/health` — added in Week 7, returns `{ success, status: "ok", uptimeSeconds }`.
  Used by:
  - Docker's `HEALTHCHECK` in `server/Dockerfile`
  - `docker-compose.yml` (indirectly, via the container healthcheck)
  - Should also be set as the health check path on whichever PaaS you deploy to
- The frontend's nginx container has its own `HEALTHCHECK` hitting `/`.

---

## 6. Troubleshooting

| Symptom | Likely cause |
|---|---|
| `backend` container restarts in a loop | `JWT_SECRET` not set in `.env`, or Mongo not reachable yet — check `docker compose logs backend` |
| Frontend loads but API calls 404 | `REACT_APP_API_URL` baked in at build time doesn't match where the backend actually lives — rebuild the frontend image after changing it |
| CORS errors in the browser console | `CLIENT_URL` on the backend doesn't match the frontend's actual origin |
| Socket.IO doesn't connect in production | Reverse proxy in front of the backend needs to forward the `Upgrade`/`Connection` headers — see the `/socket.io/` block in `client/nginx.conf` for a working example |
| Uploaded files disappear after a redeploy | Platform uses an ephemeral filesystem — mount a persistent volume, or move to S3-compatible storage |
