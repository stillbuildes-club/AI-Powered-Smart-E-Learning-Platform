// Week 7: tests for the JWT `protect` middleware (server/middleware/auth.js),
// exercised through a real protected route rather than mocking Express
// req/res objects, so it also confirms the middleware is actually wired in.
const request = require("supertest");
const jwt = require("jsonwebtoken");
const mongoose = require("mongoose");
const app = require("../server");

describe("protect middleware (via GET /api/courses)", () => {
  it("rejects requests with no Authorization header", async () => {
    const res = await request(app).get("/api/courses");
    expect(res.statusCode).toBe(401);
    expect(res.body.success).toBe(false);
  });

  it("rejects requests with an invalid/garbage token", async () => {
    const res = await request(app)
      .get("/api/courses")
      .set("Authorization", "Bearer not-a-real-token");
    expect(res.statusCode).toBe(401);
  });

  it("allows requests with a validly-signed token", async () => {
    const fakeUserId = new mongoose.Types.ObjectId().toString();
    const token = jwt.sign({ id: fakeUserId }, process.env.JWT_SECRET, { expiresIn: "1h" });

    const res = await request(app).get("/api/courses").set("Authorization", `Bearer ${token}`);
    expect(res.statusCode).toBe(200);
    expect(res.body.success).toBe(true);
    expect(Array.isArray(res.body.data)).toBe(true);
  });
});
