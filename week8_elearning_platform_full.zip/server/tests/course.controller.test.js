// Week 7: integration tests for the course list/detail endpoints, including
// the pagination behavior added to getCourses this week and its backward
// compatibility with the old "no params = everything" call shape.
const request = require("supertest");
const jwt = require("jsonwebtoken");
const app = require("../server");
const Course = require("../models/Course");

function authHeader() {
  const mongoose = require("mongoose");
  const token = jwt.sign({ id: new mongoose.Types.ObjectId().toString() }, process.env.JWT_SECRET, {
    expiresIn: "1h",
  });
  return `Bearer ${token}`;
}

describe("GET /api/courses", () => {
  beforeEach(async () => {
    await Course.create([
      { title: "React Basics", category: "Web Development", tags: ["react", "frontend"] },
      { title: "Intro to Python", category: "Data Science", tags: ["python"] },
      { title: "Advanced Node.js", category: "Web Development", tags: ["node", "backend"] },
    ]);
  });

  it("returns all courses when no pagination params are given (backward compatible)", async () => {
    const res = await request(app).get("/api/courses").set("Authorization", authHeader());
    expect(res.statusCode).toBe(200);
    expect(res.body.data).toHaveLength(3);
    expect(res.body.pagination).toBeUndefined();
  });

  it("paginates and reports pagination metadata when limit is given", async () => {
    const res = await request(app)
      .get("/api/courses?page=1&limit=2")
      .set("Authorization", authHeader());
    expect(res.statusCode).toBe(200);
    expect(res.body.data).toHaveLength(2);
    expect(res.body.pagination).toMatchObject({ page: 1, limit: 2, total: 3, totalPages: 2 });
  });

  it("returns courses sorted alphabetically by title", async () => {
    const res = await request(app).get("/api/courses").set("Authorization", authHeader());
    const titles = res.body.data.map((c) => c.title);
    expect(titles).toEqual([...titles].sort());
  });
});

describe("GET /api/courses/:id", () => {
  it("returns 404 for a well-formed but nonexistent course id", async () => {
    const mongoose = require("mongoose");
    const fakeId = new mongoose.Types.ObjectId().toString();
    const res = await request(app).get(`/api/courses/${fakeId}`).set("Authorization", authHeader());
    expect(res.statusCode).toBe(404);
  });
});
