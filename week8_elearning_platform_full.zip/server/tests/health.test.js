// Week 7: smoke test for the /api/health endpoint added for Docker/cloud
// healthchecks — also doubles as a check that the app boots with
// middleware (helmet/compression/rate-limit) attached without throwing.
const request = require("supertest");
const app = require("../server");

describe("GET /api/health", () => {
  it("returns 200 with an ok status", async () => {
    const res = await request(app).get("/api/health");
    expect(res.statusCode).toBe(200);
    expect(res.body.success).toBe(true);
    expect(res.body.status).toBe("ok");
    expect(typeof res.body.uptimeSeconds).toBe("number");
  });
});

describe("GET /api/unknown-route", () => {
  it("returns a JSON 404 for unmatched API routes", async () => {
    const res = await request(app).get("/api/this-route-does-not-exist");
    expect(res.statusCode).toBe(404);
    expect(res.body.success).toBe(false);
  });
});
