// Week 7: shared test bootstrap — spins up an in-memory MongoDB instance
// (via mongodb-memory-server) so the test suite never touches a real
// database, and sets the env vars server.js/config/db.js expect.
const { MongoMemoryServer } = require("mongodb-memory-server");
const mongoose = require("mongoose");

process.env.JWT_SECRET = process.env.JWT_SECRET || "test_secret_key_for_jest";
process.env.CLIENT_URL = process.env.CLIENT_URL || "http://localhost:3000";

let mongod;

beforeAll(async () => {
  mongod = await MongoMemoryServer.create();
  const uri = mongod.getUri();
  await mongoose.connect(uri);
});

afterEach(async () => {
  // Reset all collections between tests so they stay isolated from each other.
  const collections = mongoose.connection.collections;
  for (const key of Object.keys(collections)) {
    await collections[key].deleteMany({});
  }
});

afterAll(async () => {
  await mongoose.connection.dropDatabase();
  await mongoose.connection.close();
  if (mongod) await mongod.stop();
});
