const mongoose = require("mongoose");

const connectDB = async () => {
  try {
    // Week 7: tuned connection options for production use — caps the pool
    // so a traffic spike can't open unbounded connections against a small
    // Atlas tier, and fails fast instead of hanging if Mongo is unreachable
    // (important inside Docker Compose where startup order can race).
    const conn = await mongoose.connect(process.env.MONGO_URI, {
      maxPoolSize: parseInt(process.env.MONGO_MAX_POOL_SIZE) || 10,
      serverSelectionTimeoutMS: 10000,
    });
    console.log(`MongoDB connected: ${conn.connection.host}`);
  } catch (error) {
    console.error(`MongoDB connection error: ${error.message}`);
    process.exit(1);
  }
};

module.exports = connectDB;
