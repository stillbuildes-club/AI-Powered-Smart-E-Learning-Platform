const express = require("express");
const router = express.Router();
const { protect } = require("../middleware/auth");
const { getMilestones } = require("../controllers/milestoneController");

router.get("/", protect, getMilestones);

module.exports = router;
