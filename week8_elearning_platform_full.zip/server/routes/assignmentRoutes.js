const express = require("express");
const router = express.Router();
const { protect } = require("../middleware/auth");
const upload = require("../middleware/upload");
const {
  getAssignmentsForCourse,
  createAssignment,
  submitAssignment,
  getSubmissions,
  gradeSubmission,
} = require("../controllers/assignmentController");

router.get("/course/:courseId", protect, getAssignmentsForCourse);
router.post("/", protect, createAssignment);
router.post("/:assignmentId/submit", protect, upload.single("file"), submitAssignment);
router.get("/:assignmentId/submissions", protect, getSubmissions);
router.patch("/submissions/:submissionId/grade", protect, gradeSubmission);

module.exports = router;
