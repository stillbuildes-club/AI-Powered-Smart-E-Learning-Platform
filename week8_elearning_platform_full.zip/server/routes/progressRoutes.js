const express = require("express");
const router = express.Router();
const { protect } = require("../middleware/auth");
const {
  getDashboard,
  getCourseProgress,
  enrollInCourse,
  updateLessonProgress,
  updateQuizProgress,
  getProgressCharts,
} = require("../controllers/progressController");

router.get("/dashboard", protect, getDashboard);
router.get("/charts", protect, getProgressCharts);
router.get("/course/:courseId", protect, getCourseProgress);
router.post("/course/:courseId/enroll", protect, enrollInCourse);
router.patch("/course/:courseId/lesson/:lessonId", protect, updateLessonProgress);
router.patch("/course/:courseId/quiz/:quizId", protect, updateQuizProgress);

module.exports = router;
