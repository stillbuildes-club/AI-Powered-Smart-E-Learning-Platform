const express = require("express");
const router = express.Router();
const { protect } = require("../middleware/auth");
const {
  getConversations,
  startConversation,
  getMessages,
  sendMessage,
  markConversationRead,
} = require("../controllers/chatController");

router.get("/conversations", protect, getConversations);
router.post("/conversations", protect, startConversation);
router.get("/conversations/:conversationId/messages", protect, getMessages);
router.post("/conversations/:conversationId/messages", protect, sendMessage);
router.patch("/conversations/:conversationId/read", protect, markConversationRead);

module.exports = router;
