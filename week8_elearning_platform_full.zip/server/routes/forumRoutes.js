const express = require("express");
const router = express.Router();
const { protect } = require("../middleware/auth");
const {
  getPosts,
  getPostWithComments,
  createPost,
  addComment,
  toggleUpvote,
  deletePost,
} = require("../controllers/forumController");

router.get("/course/:courseId", protect, getPosts);
router.post("/course/:courseId", protect, createPost);
router.get("/post/:postId", protect, getPostWithComments);
router.post("/post/:postId/comments", protect, addComment);
router.patch("/post/:postId/upvote", protect, toggleUpvote);
router.delete("/post/:postId", protect, deletePost);

module.exports = router;
