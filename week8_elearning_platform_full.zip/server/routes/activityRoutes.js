const express = require("express");
const router = express.Router();
const { protect } = require("../middleware/auth");
const { getActivityHistory } = require("../controllers/activityController");

router.get("/", protect, getActivityHistory);

module.exports = router;
