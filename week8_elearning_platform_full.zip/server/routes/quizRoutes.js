const express = require("express");
const router = express.Router();
const { protect } = require("../middleware/auth");
const {
  getQuizzesForCourse,
  getQuizForTaking,
  submitQuiz,
  getQuizHistory,
  createQuiz,
} = require("../controllers/quizController");

router.get("/course/:courseId", protect, getQuizzesForCourse);
router.get("/:quizId/take", protect, getQuizForTaking);
router.post("/:quizId/submit", protect, submitQuiz);
router.get("/:quizId/history", protect, getQuizHistory);
router.post("/", protect, createQuiz);

module.exports = router;
