const express = require("express");
const router = express.Router();
const { protect } = require("../middleware/auth");
const { cacheMiddleware } = require("../utils/cache");
const { getCourses, getCourseById } = require("../controllers/courseController");

// Week 7: the course list changes rarely (new courses are added
// occasionally by instructors/admins, not every request), so it's cached
// per-URL (including query params) for 60s to cut repeated DB round-trips
// under load. Per-user auth still applies via `protect` before the cache
// check even runs.
router.get("/", protect, cacheMiddleware(60), getCourses);
router.get("/:id", protect, getCourseById);

module.exports = router;
