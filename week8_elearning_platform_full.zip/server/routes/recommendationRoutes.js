const express = require("express");
const router = express.Router();
const { protect } = require("../middleware/auth");
const {
  getRecommendations,
  getInterestBased,
  getCompletedBased,
  getEnrolledBased,
  getHistoryBased,
} = require("../controllers/recommendationController");

// All routes support optional query params: ?category=<name>&limit=<n>
router.get("/", protect, getRecommendations); // combined / smart ranking (default)
router.get("/interests", protect, getInterestBased);
router.get("/completed", protect, getCompletedBased);
router.get("/enrolled", protect, getEnrolledBased);
router.get("/history", protect, getHistoryBased);

module.exports = router;
