require("dotenv").config();
const path = require("path");
const http = require("http");
const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const compression = require("compression");
const morgan = require("morgan");
const rateLimit = require("express-rate-limit");
const connectDB = require("./config/db");

const progressRoutes = require("./routes/progressRoutes");
const activityRoutes = require("./routes/activityRoutes");
const milestoneRoutes = require("./routes/milestoneRoutes");
const recommendationRoutes = require("./routes/recommendationRoutes");

// Week 6 feature routes
const courseRoutes = require("./routes/courseRoutes");
const chatRoutes = require("./routes/chatRoutes");
const forumRoutes = require("./routes/forumRoutes");
const notificationRoutes = require("./routes/notificationRoutes");
const quizRoutes = require("./routes/quizRoutes");
const assignmentRoutes = require("./routes/assignmentRoutes");

const socket = require("./socket");

const app = express();

// Only open the real DB connection when this file is actually run as the
// server (`node server.js` / `npm start`/`npm run dev`), not when it's
// `require()`d by the Week 7 test suite via supertest, which manages its
// own in-memory MongoDB connection (see tests/setup.js).
const isTestEnv = process.env.NODE_ENV === "test";
if (!isTestEnv) {
  connectDB();
}

// ---------------------------------------------------------------------------
// Week 7: security & performance middleware
// ---------------------------------------------------------------------------

// Sets a sensible set of security-related HTTP headers.
app.use(helmet());

// Gzip/deflate compresses every JSON/HTML response — cheap win for API
// payloads like the dashboard/recommendations responses which can be large.
app.use(compression());

// Request logging: concise colored logs in dev, Apache-style combined logs
// in production (useful once this is running behind a cloud load balancer).
if (!isTestEnv) {
  app.use(morgan(process.env.NODE_ENV === "production" ? "combined" : "dev"));
}

// Basic abuse/DoS protection on the whole API surface. Limits are
// configurable via env so they can be tuned per deployment without a code
// change (see .env.example).
const apiLimiter = rateLimit({
  windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS) || 15 * 60 * 1000, // 15 min
  max: parseInt(process.env.RATE_LIMIT_MAX) || 300,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, message: "Too many requests, please try again later." },
});
app.use("/api", apiLimiter);

app.use(cors({ origin: process.env.CLIENT_URL || "http://localhost:3000" }));
app.use(express.json({ limit: "1mb" }));

// Serve uploaded assignment files (Week 6). Long cache since filenames are
// content-addressed with a random suffix and never overwritten in place.
app.use(
  "/uploads",
  express.static(path.join(__dirname, "uploads"), { maxAge: "7d", immutable: true })
);

// Liveness/readiness probe for Docker/Compose healthchecks and cloud
// platforms (Render, ECS, Kubernetes, etc.) — added in Week 7 for the
// deployment step, deliberately unauthenticated and DB-independent so it
// reflects whether the process itself is up.
app.get("/api/health", (req, res) => {
  res.status(200).json({
    success: true,
    status: "ok",
    uptimeSeconds: Math.round(process.uptime()),
    timestamp: new Date().toISOString(),
  });
});

// Week 4 feature routes: Student Progress Dashboard, Lesson/Quiz progress,
// Activity History, Milestone Tracking, Progress Charts data.
app.use("/api/progress", progressRoutes);
app.use("/api/activity", activityRoutes);
app.use("/api/milestones", milestoneRoutes);

// Week 5 feature routes: AI-Based Course Recommendation Engine.
app.use("/api/recommendations", recommendationRoutes);

// Week 6 feature routes: Chat, Discussion Forum, Live Notifications,
// Interactive Quiz System, Assignment Submission. `courseRoutes` was added
// alongside these since several of them need a course picker on the
// frontend and no generic course-listing endpoint existed yet.
app.use("/api/courses", courseRoutes);
app.use("/api/chat", chatRoutes);
app.use("/api/forum", forumRoutes);
app.use("/api/notifications", notificationRoutes);
app.use("/api/quizzes", quizRoutes);
app.use("/api/assignments", assignmentRoutes);

app.get("/", (req, res) => {
  res.send("E-Learning Platform API — Week 7: Dockerized, optimized & deployment-ready");
});

// 404 handler for unmatched API routes (added in Week 7 — previously any
// unknown /api/* path fell through with no explicit JSON response).
app.use("/api", (req, res) => {
  res.status(404).json({ success: false, message: "Route not found" });
});

// Centralized error handler
app.use((err, req, res, next) => {
  console.error(err.stack);
  const status = err.statusCode || 500;
  res.status(status).json({
    success: false,
    message: status === 500 ? "Server error" : err.message,
  });
});

// Export the Express app (without starting a listener) so the Week 7 test
// suite can drive it with supertest.
module.exports = app;

// Only actually bind a port and start Socket.IO when this file is the
// process entry point — i.e. not when it's imported by tests.
if (require.main === module) {
  const PORT = process.env.PORT || 5000;

  // Week 6: app is wrapped in a plain http.Server so Socket.IO can attach
  // to the same port as the REST API (no separate server/port needed).
  const server = http.createServer(app);
  socket.init(server, process.env.CLIENT_URL || "http://localhost:3000");

  server.listen(PORT, () => console.log(`Server running on port ${PORT} (HTTP + Socket.IO)`));

  // Week 7: graceful shutdown — let in-flight requests/DB writes finish and
  // close the Mongo connection cleanly on SIGTERM/SIGINT (sent by Docker
  // `stop`, Compose `down`, and most cloud platforms before a hard kill).
  const mongoose = require("mongoose");
  const shutdown = (signal) => {
    console.log(`\n${signal} received: closing server gracefully...`);
    server.close(async () => {
      try {
        await mongoose.connection.close();
        console.log("MongoDB connection closed. Exiting.");
        process.exit(0);
      } catch (err) {
        console.error("Error during shutdown:", err);
        process.exit(1);
      }
    });
    // Force-exit if shutdown hangs for longer than 10s.
    setTimeout(() => process.exit(1), 10000).unref();
  };
  process.on("SIGTERM", () => shutdown("SIGTERM"));
  process.on("SIGINT", () => shutdown("SIGINT"));
}
