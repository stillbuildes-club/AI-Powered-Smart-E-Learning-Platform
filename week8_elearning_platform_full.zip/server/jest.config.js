// Week 7: Jest configuration for the backend test suite.
module.exports = {
  testEnvironment: "node",
  setupFilesAfterEnv: ["<rootDir>/tests/setup.js"],
  testMatch: ["**/tests/**/*.test.js"],
  verbose: true,
  // Fails CI loudly instead of hanging if a test forgets to close a socket/timer.
  forceExit: true,
  testTimeout: 20000,
};
