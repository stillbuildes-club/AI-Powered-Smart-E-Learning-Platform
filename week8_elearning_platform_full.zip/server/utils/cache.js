const NodeCache = require("node-cache");

// Week 7: lightweight in-memory cache for cheap, high-traffic, rarely-changing
// GET endpoints (e.g. the course list). Not a substitute for Redis in a
// multi-instance deployment, but removes repeated DB round-trips for a
// single backend container at near-zero complexity cost.
const cache = new NodeCache({ stdTTL: 60, checkperiod: 90 });

// Wraps an Express GET handler with a cache read/write around it.
// `keyFn` builds the cache key from the request (defaults to originalUrl,
// which already includes query params).
function cacheMiddleware(ttlSeconds = 60, keyFn = (req) => req.originalUrl) {
  return (req, res, next) => {
    const key = keyFn(req);
    const cached = cache.get(key);
    if (cached) {
      return res.status(200).json(cached);
    }

    // Capture the JSON response so it can be cached after the real handler runs.
    const originalJson = res.json.bind(res);
    res.json = (body) => {
      if (res.statusCode === 200) {
        cache.set(key, body, ttlSeconds);
      }
      return originalJson(body);
    };

    next();
  };
}

// Clears every cache entry whose key starts with `prefix`. Call this from
// write endpoints (create/update/delete) that should invalidate a cached list.
function invalidate(prefix) {
  const keys = cache.keys().filter((k) => k.startsWith(prefix));
  cache.del(keys);
}

module.exports = { cache, cacheMiddleware, invalidate };
