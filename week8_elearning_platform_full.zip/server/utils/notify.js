const Notification = require("../models/Notification");
const { emitToUser } = require("../socket");

// Week 6: shared helper — every feature (chat, forum, quiz, assignment)
// calls this instead of duplicating "save to DB + push over socket" logic.
// Always persists first so the notification is there on next login even
// if the user is offline right now; the socket emit is a best-effort
// "live" delivery on top of that.
async function notify({ user, type = "system", title, message = "", link = "" }) {
  if (!user) return null;

  const notification = await Notification.create({ user, type, title, message, link });
  emitToUser(user, "notification:new", notification);
  return notification;
}

module.exports = { notify };
