const Milestone = require("../models/Milestone");
const Activity = require("../models/Activity");

// Definitions of percentage-based milestones, in ascending order.
const PERCENT_MILESTONES = [
  { threshold: 25, type: "quarter_complete", title: "Quarter of the way there!", icon: "star" },
  { threshold: 50, type: "halfway_complete", title: "Halfway there!", icon: "medal" },
  { threshold: 75, type: "three_quarter_complete", title: "Almost done!", icon: "flag" },
  { threshold: 100, type: "course_completed", title: "Course completed!", icon: "trophy" },
];

/**
 * Awards any percentage milestones the student has newly crossed for a course.
 * Safe to call every time progress updates — relies on the unique index on
 * (student, course, type) to silently avoid duplicate awards.
 */
async function checkAndAwardPercentMilestones({ studentId, courseId, completionPercentage }) {
  const awarded = [];

  for (const milestone of PERCENT_MILESTONES) {
    if (completionPercentage >= milestone.threshold) {
      try {
        const doc = await Milestone.create({
          student: studentId,
          course: courseId,
          type: milestone.type,
          title: milestone.title,
          icon: milestone.icon,
        });
        awarded.push(doc);

        await Activity.create({
          student: studentId,
          course: courseId,
          type: "milestone_achieved",
          description: milestone.title,
          metadata: { milestoneType: milestone.type, completionPercentage },
        });
      } catch (error) {
        // Duplicate key error (11000) just means it was already awarded — ignore.
        if (error.code !== 11000) throw error;
      }
    }
  }

  return awarded;
}

/**
 * Awards a "quiz master" milestone if the student has passed every quiz in the course.
 */
async function checkQuizMasterMilestone({ studentId, courseId, quizzesProgress, totalQuizzes }) {
  if (totalQuizzes === 0) return null;
  const allPassed =
    quizzesProgress.length === totalQuizzes && quizzesProgress.every((q) => q.passed);

  if (!allPassed) return null;

  try {
    const doc = await Milestone.create({
      student: studentId,
      course: courseId,
      type: "quiz_master",
      title: "Quiz Master",
      description: "Passed every quiz in the course",
      icon: "brain",
    });

    await Activity.create({
      student: studentId,
      course: courseId,
      type: "milestone_achieved",
      description: "Quiz Master milestone achieved",
      metadata: { milestoneType: "quiz_master" },
    });

    return doc;
  } catch (error) {
    if (error.code !== 11000) throw error;
    return null;
  }
}

module.exports = { checkAndAwardPercentMilestones, checkQuizMasterMilestone };
