const Milestone = require("../models/Milestone");

// GET /api/milestones
// Optional query param: courseId to filter milestones for a single course.
const getMilestones = async (req, res) => {
  try {
    const studentId = req.user.id;
    const filter = { student: studentId };
    if (req.query.courseId) filter.course = req.query.courseId;

    const milestones = await Milestone.find(filter)
      .populate("course", "title")
      .sort({ achievedAt: -1 });

    res.status(200).json({ success: true, data: milestones });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

module.exports = { getMilestones };
