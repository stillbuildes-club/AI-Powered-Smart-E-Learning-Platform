const Conversation = require("../models/Conversation");
const Message = require("../models/Message");
const User = require("../models/User");
const { emitToUser, getIO, conversationRoom } = require("../socket");

// Week 6: Real-time Chat between Students and Instructors.
// Socket.IO (server/socket/index.js) handles live delivery; these REST
// endpoints handle history loading and act as a fallback send path for
// clients that aren't connected to the socket yet.

// GET /api/chat/conversations
const getConversations = async (req, res) => {
  try {
    const conversations = await Conversation.find({ participants: req.user.id })
      .populate("participants", "name role email")
      .populate("course", "title")
      .sort({ updatedAt: -1 });

    res.status(200).json({ success: true, data: conversations });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// POST /api/chat/conversations  Body: { participantId, courseId? }
// Finds an existing 1-to-1 conversation between the two users, or creates one.
const startConversation = async (req, res) => {
  try {
    const { participantId, courseId } = req.body;
    if (!participantId) {
      return res.status(400).json({ success: false, message: "participantId is required" });
    }
    if (participantId === req.user.id) {
      return res.status(400).json({ success: false, message: "Cannot start a conversation with yourself" });
    }

    const otherUser = await User.findById(participantId).select("name role");
    if (!otherUser) return res.status(404).json({ success: false, message: "User not found" });

    let conversation = await Conversation.findOne({
      participants: { $all: [req.user.id, participantId], $size: 2 },
      ...(courseId ? { course: courseId } : {}),
    });

    if (!conversation) {
      conversation = await Conversation.create({
        participants: [req.user.id, participantId],
        course: courseId || undefined,
      });
    }

    conversation = await conversation.populate("participants", "name role email");
    res.status(201).json({ success: true, data: conversation });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// GET /api/chat/conversations/:conversationId/messages?before=<ISODate>&limit=30
const getMessages = async (req, res) => {
  try {
    const { conversationId } = req.params;
    const { before, limit = 30 } = req.query;

    const conversation = await Conversation.findById(conversationId);
    if (!conversation || !conversation.participants.some((p) => p.toString() === req.user.id)) {
      return res.status(403).json({ success: false, message: "Not part of this conversation" });
    }

    const query = { conversation: conversationId };
    if (before) query.createdAt = { $lt: new Date(before) };

    const messages = await Message.find(query)
      .sort({ createdAt: -1 })
      .limit(Number(limit))
      .populate("sender", "name role");

    res.status(200).json({ success: true, data: messages.reverse() });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// POST /api/chat/conversations/:conversationId/messages  Body: { text }
// REST fallback for sending — mirrors the socket "chat:message" handler so
// a message sent this way still shows up live for the other participant.
const sendMessage = async (req, res) => {
  try {
    const { conversationId } = req.params;
    const { text } = req.body;
    if (!text || !text.trim()) {
      return res.status(400).json({ success: false, message: "Message text is required" });
    }

    const conversation = await Conversation.findById(conversationId);
    if (!conversation || !conversation.participants.some((p) => p.toString() === req.user.id)) {
      return res.status(403).json({ success: false, message: "Not part of this conversation" });
    }

    const message = await Message.create({
      conversation: conversationId,
      sender: req.user.id,
      text: text.trim(),
      readBy: [req.user.id],
    });

    conversation.lastMessage = { text: message.text, sender: req.user.id, createdAt: message.createdAt };
    await conversation.save();

    const populated = await message.populate("sender", "name role");

    const io = getIO();
    if (io) io.to(conversationRoom(conversationId)).emit("chat:message", populated);

    conversation.participants
      .filter((p) => p.toString() !== req.user.id)
      .forEach((participantId) => emitToUser(participantId, "chat:incoming", { conversationId, message: populated }));

    res.status(201).json({ success: true, data: populated });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// PATCH /api/chat/conversations/:conversationId/read
const markConversationRead = async (req, res) => {
  try {
    const { conversationId } = req.params;
    await Message.updateMany(
      { conversation: conversationId, readBy: { $ne: req.user.id } },
      { $addToSet: { readBy: req.user.id } }
    );
    res.status(200).json({ success: true });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

module.exports = { getConversations, startConversation, getMessages, sendMessage, markConversationRead };
