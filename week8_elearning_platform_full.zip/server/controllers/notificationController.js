const Notification = require("../models/Notification");

// Week 6: Live Notifications — history/read-state REST API. Live delivery
// itself happens over Socket.IO ("notification:new") from utils/notify.js.

// GET /api/notifications?limit=20&unreadOnly=false
const getNotifications = async (req, res) => {
  try {
    const { limit = 20, unreadOnly = "false" } = req.query;
    const query = { user: req.user.id };
    if (unreadOnly === "true") query.isRead = false;

    const notifications = await Notification.find(query).sort({ createdAt: -1 }).limit(Number(limit));
    const unreadCount = await Notification.countDocuments({ user: req.user.id, isRead: false });

    res.status(200).json({ success: true, data: { notifications, unreadCount } });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// PATCH /api/notifications/:id/read
const markAsRead = async (req, res) => {
  try {
    const notification = await Notification.findOneAndUpdate(
      { _id: req.params.id, user: req.user.id },
      { isRead: true },
      { new: true }
    );
    if (!notification) return res.status(404).json({ success: false, message: "Notification not found" });
    res.status(200).json({ success: true, data: notification });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// PATCH /api/notifications/read-all
const markAllAsRead = async (req, res) => {
  try {
    await Notification.updateMany({ user: req.user.id, isRead: false }, { isRead: true });
    res.status(200).json({ success: true });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

module.exports = { getNotifications, markAsRead, markAllAsRead };
