const Progress = require("../models/Progress");
const Course = require("../models/Course");
const Lesson = require("../models/Lesson");
const Quiz = require("../models/Quiz");
const Activity = require("../models/Activity");
const mongoose = require("mongoose");
const {
  checkAndAwardPercentMilestones,
  checkQuizMasterMilestone,
} = require("../utils/milestoneChecker");

// Recalculates the overall completion percentage for a progress document
// as a weighted average of lesson completion and quiz completion.
function recalcCompletion(progressDoc, totalLessons, totalQuizzes) {
  const completedLessons = progressDoc.lessonsProgress.filter((l) => l.status === "completed").length;
  const passedQuizzes = progressDoc.quizzesProgress.filter((q) => q.passed).length;

  const lessonWeight = totalLessons > 0 ? completedLessons / totalLessons : 1;
  const quizWeight = totalQuizzes > 0 ? passedQuizzes / totalQuizzes : 1;

  // If a course has both lessons and quizzes, weight them 70/30.
  // If it only has one of the two, that one accounts for 100%.
  let percentage;
  if (totalLessons > 0 && totalQuizzes > 0) {
    percentage = lessonWeight * 70 + quizWeight * 30;
  } else if (totalLessons > 0) {
    percentage = lessonWeight * 100;
  } else if (totalQuizzes > 0) {
    percentage = quizWeight * 100;
  } else {
    percentage = 0;
  }

  progressDoc.completionPercentage = Math.round(percentage);
  progressDoc.status =
    progressDoc.completionPercentage >= 100
      ? "completed"
      : progressDoc.completionPercentage > 0
      ? "in_progress"
      : "not_started";

  if (progressDoc.status === "completed" && !progressDoc.completedAt) {
    progressDoc.completedAt = new Date();
  }

  return progressDoc;
}

// GET /api/progress/dashboard
// Overview across every course the logged-in student is enrolled in.
const getDashboard = async (req, res) => {
  try {
    const studentId = req.user.id;
    const progressRecords = await Progress.find({ student: studentId })
      .populate("course", "title thumbnail category totalLessons totalQuizzes")
      .sort({ lastAccessedAt: -1 });

    const totalCourses = progressRecords.length;
    const completedCourses = progressRecords.filter((p) => p.status === "completed").length;
    const inProgressCourses = progressRecords.filter((p) => p.status === "in_progress").length;
    const notStartedCourses = progressRecords.filter((p) => p.status === "not_started").length;

    const avgCompletion =
      totalCourses > 0
        ? Math.round(
            progressRecords.reduce((sum, p) => sum + p.completionPercentage, 0) / totalCourses
          )
        : 0;

    const recentActivity = await Activity.find({ student: studentId })
      .sort({ createdAt: -1 })
      .limit(5)
      .populate("course", "title");

    res.status(200).json({
      success: true,
      data: {
        summary: {
          totalCourses,
          completedCourses,
          inProgressCourses,
          notStartedCourses,
          avgCompletion,
        },
        courses: progressRecords,
        recentActivity,
      },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// GET /api/progress/course/:courseId
// Detailed progress for one course: lesson-by-lesson and quiz-by-quiz breakdown.
const getCourseProgress = async (req, res) => {
  try {
    const { courseId } = req.params;
    const studentId = req.user.id;

    const progress = await Progress.findOne({ student: studentId, course: courseId })
      .populate("course", "title totalLessons totalQuizzes")
      .populate("lessonsProgress.lesson", "title order durationMinutes")
      .populate("quizzesProgress.quiz", "title totalQuestions passingScore");

    if (!progress) {
      return res.status(404).json({ success: false, message: "No progress found for this course" });
    }

    res.status(200).json({ success: true, data: progress });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// POST /api/progress/course/:courseId/enroll
// Initializes a Progress document for a student starting a course.
const enrollInCourse = async (req, res) => {
  try {
    const { courseId } = req.params;
    const studentId = req.user.id;

    const course = await Course.findById(courseId);
    if (!course) return res.status(404).json({ success: false, message: "Course not found" });

    const lessons = await Lesson.find({ course: courseId }).sort({ order: 1 });
    const quizzes = await Quiz.find({ course: courseId });

    let progress = await Progress.findOne({ student: studentId, course: courseId });
    if (progress) {
      return res.status(200).json({ success: true, message: "Already enrolled", data: progress });
    }

    progress = await Progress.create({
      student: studentId,
      course: courseId,
      status: "in_progress",
      startedAt: new Date(),
      lessonsProgress: lessons.map((l) => ({ lesson: l._id, status: "not_started" })),
      quizzesProgress: quizzes.map((q) => ({ quiz: q._id })),
    });

    await Activity.create({
      student: studentId,
      course: courseId,
      type: "course_started",
      description: `Started course: ${course.title}`,
    });

    res.status(201).json({ success: true, data: progress });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// PATCH /api/progress/course/:courseId/lesson/:lessonId
// Body: { status: "in_progress" | "completed", timeSpentMinutes }
const updateLessonProgress = async (req, res) => {
  try {
    const { courseId, lessonId } = req.params;
    const { status, timeSpentMinutes } = req.body;
    const studentId = req.user.id;

    const progress = await Progress.findOne({ student: studentId, course: courseId });
    if (!progress) {
      return res.status(404).json({ success: false, message: "Enroll in the course first" });
    }

    const lessonEntry = progress.lessonsProgress.find((l) => l.lesson.toString() === lessonId);
    if (!lessonEntry) {
      return res.status(404).json({ success: false, message: "Lesson not part of this course" });
    }

    lessonEntry.status = status || lessonEntry.status;
    if (timeSpentMinutes) lessonEntry.timeSpentMinutes += timeSpentMinutes;
    if (status === "completed" && !lessonEntry.completedAt) {
      lessonEntry.completedAt = new Date();
    }

    const course = await Course.findById(courseId);
    recalcCompletion(progress, course.totalLessons, course.totalQuizzes);
    progress.lastAccessedAt = new Date();
    await progress.save();

    if (status === "completed") {
      const lesson = await Lesson.findById(lessonId);
      await Activity.create({
        student: studentId,
        course: courseId,
        type: "lesson_completed",
        description: `Completed lesson: ${lesson ? lesson.title : lessonId}`,
      });

      await checkAndAwardPercentMilestones({
        studentId,
        courseId,
        completionPercentage: progress.completionPercentage,
      });
    }

    res.status(200).json({ success: true, data: progress });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// PATCH /api/progress/course/:courseId/quiz/:quizId
// Body: { score } — score is a percentage (0-100) from the most recent attempt.
const updateQuizProgress = async (req, res) => {
  try {
    const { courseId, quizId } = req.params;
    const { score } = req.body;
    const studentId = req.user.id;

    if (typeof score !== "number" || score < 0 || score > 100) {
      return res.status(400).json({ success: false, message: "score must be a number between 0 and 100" });
    }

    const progress = await Progress.findOne({ student: studentId, course: courseId });
    if (!progress) {
      return res.status(404).json({ success: false, message: "Enroll in the course first" });
    }

    const quiz = await Quiz.findById(quizId);
    if (!quiz) return res.status(404).json({ success: false, message: "Quiz not found" });

    const quizEntry = progress.quizzesProgress.find((q) => q.quiz.toString() === quizId);
    if (!quizEntry) {
      return res.status(404).json({ success: false, message: "Quiz not part of this course" });
    }

    const isFirstAttempt = quizEntry.attempts === 0;
    quizEntry.attempts += 1;
    quizEntry.lastAttemptAt = new Date();
    quizEntry.bestScore = Math.max(quizEntry.bestScore, score);
    const justPassed = !quizEntry.passed && score >= quiz.passingScore;
    if (score >= quiz.passingScore) quizEntry.passed = true;

    const course = await Course.findById(courseId);
    recalcCompletion(progress, course.totalLessons, course.totalQuizzes);
    progress.lastAccessedAt = new Date();
    await progress.save();

    await Activity.create({
      student: studentId,
      course: courseId,
      type: justPassed ? "quiz_passed" : "quiz_attempted",
      description: `${justPassed ? "Passed" : "Attempted"} quiz: ${quiz.title} (${score}%)`,
      metadata: { score, attempts: quizEntry.attempts },
    });

    if (isFirstAttempt && justPassed) {
      await Activity.create({
        student: studentId,
        course: courseId,
        type: "milestone_achieved",
        description: "First Quiz Passed",
        metadata: { milestoneType: "first_quiz_passed" },
      });
    }

    await checkAndAwardPercentMilestones({
      studentId,
      courseId,
      completionPercentage: progress.completionPercentage,
    });

    await checkQuizMasterMilestone({
      studentId,
      courseId,
      quizzesProgress: progress.quizzesProgress,
      totalQuizzes: course.totalQuizzes,
    });

    res.status(200).json({ success: true, data: progress });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// GET /api/progress/charts
// Data shaped for the frontend charting library (course completion bar chart,
// lesson-vs-quiz breakdown, and a 7/30-day activity trend line).
const getProgressCharts = async (req, res) => {
  try {
    const studentId = req.user.id;

    // Week 7: `.lean()` — this endpoint only reads and reshapes data for
    // charts, so skipping Mongoose document hydration reduces CPU/memory
    // overhead on a route that's typically polled on every dashboard load.
    const progressRecords = await Progress.find({ student: studentId })
      .populate("course", "title")
      .lean();

    const courseCompletion = progressRecords.map((p) => ({
      courseId: p.course._id,
      courseTitle: p.course.title,
      completionPercentage: p.completionPercentage,
    }));

    const lessonVsQuiz = progressRecords.map((p) => ({
      courseTitle: p.course.title,
      lessonsCompleted: p.lessonsProgress.filter((l) => l.status === "completed").length,
      totalLessons: p.lessonsProgress.length,
      quizzesPassed: p.quizzesProgress.filter((q) => q.passed).length,
      totalQuizzes: p.quizzesProgress.length,
    }));

    // Activity trend: count of activities per day for the last 30 days.
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

    const activityTrend = await Activity.aggregate([
      { $match: { student: new mongoose.Types.ObjectId(studentId), createdAt: { $gte: thirtyDaysAgo } } },
      {
        $group: {
          _id: { $dateToString: { format: "%Y-%m-%d", date: "$createdAt" } },
          count: { $sum: 1 },
        },
      },
      { $sort: { _id: 1 } },
    ]);

    res.status(200).json({
      success: true,
      data: {
        courseCompletion,
        lessonVsQuiz,
        activityTrend: activityTrend.map((a) => ({ date: a._id, count: a.count })),
      },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

module.exports = {
  getDashboard,
  getCourseProgress,
  enrollInCourse,
  updateLessonProgress,
  updateQuizProgress,
  getProgressCharts,
};
