const Course = require("../models/Course");

// Week 6: a minimal read-only course list/detail API. Added because the
// new course-scoped features (Forum, Quiz, Assignments) need a course
// picker on the frontend, and no generic course listing endpoint existed
// yet in Weeks 1-5 (only nested progress/recommendation endpoints did).

// GET /api/courses
// Week 7: added `.lean()` (skips Mongoose document hydration — this
// endpoint is read-only, so plain JS objects are cheaper to build and
// serialize) and optional `?page=&limit=` pagination. Both params are
// optional and default to the old "return everything" behavior, so
// existing frontend calls (`getCourses()` with no args) are unaffected.
const getCourses = async (req, res) => {
  try {
    const page = Math.max(1, parseInt(req.query.page) || 1);
    const limit = req.query.limit ? Math.min(100, parseInt(req.query.limit)) : 0; // 0 = no limit (old behavior)

    let query = Course.find()
      .select("title category thumbnail instructor")
      .sort({ title: 1 })
      .lean();

    if (limit > 0) {
      query = query.skip((page - 1) * limit).limit(limit);
    }

    const [courses, total] = await Promise.all([
      query,
      limit > 0 ? Course.countDocuments() : Promise.resolve(null),
    ]);

    const response = { success: true, data: courses };
    if (total !== null) {
      response.pagination = { page, limit, total, totalPages: Math.ceil(total / limit) };
    }

    res.status(200).json(response);
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// GET /api/courses/:id
const getCourseById = async (req, res) => {
  try {
    const course = await Course.findById(req.params.id).populate("instructor", "name email role");
    if (!course) return res.status(404).json({ success: false, message: "Course not found" });
    res.status(200).json({ success: true, data: course });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

module.exports = { getCourses, getCourseById };
