const Quiz = require("../models/Quiz");
const QuizSubmission = require("../models/QuizSubmission");
const Progress = require("../models/Progress");
const Course = require("../models/Course");
const Activity = require("../models/Activity");
const User = require("../models/User");
const { notify } = require("../utils/notify");
const {
  checkAndAwardPercentMilestones,
  checkQuizMasterMilestone,
} = require("../utils/milestoneChecker");

// Week 6: Interactive Quiz System. Builds on top of the Quiz model that
// already existed for Week 4/5 progress tracking (title/passingScore),
// now extended with an embedded `questions` array (see models/Quiz.js).
//
// Mirrors the completion/milestone logic already used in
// controllers/progressController.js's updateQuizProgress, so a quiz taken
// here still shows up correctly on the Week 4 Progress Dashboard.
async function syncProgressAfterQuiz({ studentId, courseId, quizId, score, passingScore }) {
  const progress = await Progress.findOne({ student: studentId, course: courseId });
  if (!progress) return null;

  const quizEntry = progress.quizzesProgress.find((q) => q.quiz.toString() === quizId);
  if (!quizEntry) return null;

  const isFirstAttempt = quizEntry.attempts === 0;
  quizEntry.attempts += 1;
  quizEntry.lastAttemptAt = new Date();
  quizEntry.bestScore = Math.max(quizEntry.bestScore, score);
  const justPassed = !quizEntry.passed && score >= passingScore;
  if (score >= passingScore) quizEntry.passed = true;

  const course = await Course.findById(courseId);
  const completedLessons = progress.lessonsProgress.filter((l) => l.status === "completed").length;
  const passedQuizzes = progress.quizzesProgress.filter((q) => q.passed).length;
  const lessonWeight = course.totalLessons > 0 ? completedLessons / course.totalLessons : 1;
  const quizWeight = course.totalQuizzes > 0 ? passedQuizzes / course.totalQuizzes : 1;

  let percentage;
  if (course.totalLessons > 0 && course.totalQuizzes > 0) percentage = lessonWeight * 70 + quizWeight * 30;
  else if (course.totalLessons > 0) percentage = lessonWeight * 100;
  else if (course.totalQuizzes > 0) percentage = quizWeight * 100;
  else percentage = 0;

  progress.completionPercentage = Math.round(percentage);
  progress.status =
    progress.completionPercentage >= 100 ? "completed" : progress.completionPercentage > 0 ? "in_progress" : "not_started";
  if (progress.status === "completed" && !progress.completedAt) progress.completedAt = new Date();
  progress.lastAccessedAt = new Date();
  await progress.save();

  await checkAndAwardPercentMilestones({ studentId, courseId, completionPercentage: progress.completionPercentage });
  await checkQuizMasterMilestone({
    studentId,
    courseId,
    quizzesProgress: progress.quizzesProgress,
    totalQuizzes: course.totalQuizzes,
  });

  return { isFirstAttempt, justPassed, progress };
}

// GET /api/quizzes/course/:courseId  — list quizzes for a course (no answers).
const getQuizzesForCourse = async (req, res) => {
  try {
    const quizzes = await Quiz.find({ course: req.params.courseId }).select(
      "title totalQuestions passingScore lesson createdAt questions"
    );
    const withCounts = quizzes.map((q) => ({
      _id: q._id,
      title: q.title,
      lesson: q.lesson,
      passingScore: q.passingScore,
      questionCount: q.questions.length || q.totalQuestions,
      createdAt: q.createdAt,
    }));
    res.status(200).json({ success: true, data: withCounts });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// GET /api/quizzes/:quizId/take — questions WITHOUT correctOptionIndex.
const getQuizForTaking = async (req, res) => {
  try {
    const quiz = await Quiz.findById(req.params.quizId);
    if (!quiz) return res.status(404).json({ success: false, message: "Quiz not found" });

    const sanitized = {
      _id: quiz._id,
      title: quiz.title,
      course: quiz.course,
      passingScore: quiz.passingScore,
      questions: quiz.questions.map((q) => ({ _id: q._id, questionText: q.questionText, options: q.options })),
    };

    res.status(200).json({ success: true, data: sanitized });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// POST /api/quizzes/:quizId/submit  Body: { answers: [{ questionId, selectedOptionIndex }] }
const submitQuiz = async (req, res) => {
  try {
    const { quizId } = req.params;
    const { answers } = req.body;
    const studentId = req.user.id;

    if (!Array.isArray(answers) || answers.length === 0) {
      return res.status(400).json({ success: false, message: "answers array is required" });
    }

    const quiz = await Quiz.findById(quizId);
    if (!quiz) return res.status(404).json({ success: false, message: "Quiz not found" });

    let totalPoints = 0;
    let earnedPoints = 0;
    const gradedAnswers = quiz.questions.map((question) => {
      totalPoints += question.points || 1;
      const submitted = answers.find((a) => a.questionId === question._id.toString());
      const selectedOptionIndex = submitted ? submitted.selectedOptionIndex : -1;
      const correct = selectedOptionIndex === question.correctOptionIndex;
      if (correct) earnedPoints += question.points || 1;
      return { question: question._id, selectedOptionIndex, correct };
    });

    const score = totalPoints > 0 ? Math.round((earnedPoints / totalPoints) * 100) : 0;
    const passed = score >= quiz.passingScore;

    const submission = await QuizSubmission.create({
      quiz: quizId,
      student: studentId,
      answers: gradedAnswers,
      score,
      passed,
    });

    await Activity.create({
      student: studentId,
      course: quiz.course,
      type: passed ? "quiz_passed" : "quiz_attempted",
      description: `${passed ? "Passed" : "Attempted"} quiz: ${quiz.title} (${score}%)`,
      metadata: { score },
    });

    const sync = await syncProgressAfterQuiz({
      studentId,
      courseId: quiz.course.toString(),
      quizId,
      score,
      passingScore: quiz.passingScore,
    });

    await notify({
      user: studentId,
      type: "quiz",
      title: passed ? "Quiz passed!" : "Quiz submitted",
      message: `You scored ${score}% on "${quiz.title}"`,
      link: `quiz:${quizId}`,
    });

    res.status(201).json({
      success: true,
      data: {
        submission,
        score,
        passed,
        correctCount: gradedAnswers.filter((a) => a.correct).length,
        totalQuestions: gradedAnswers.length,
        progressSynced: !!sync,
      },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// GET /api/quizzes/:quizId/history — student's past attempts on this quiz.
const getQuizHistory = async (req, res) => {
  try {
    const submissions = await QuizSubmission.find({ quiz: req.params.quizId, student: req.user.id }).sort({
      createdAt: -1,
    });
    res.status(200).json({ success: true, data: submissions });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// POST /api/quizzes  (instructor) — create a quiz with questions.
// Body: { course, lesson?, title, passingScore, questions: [{questionText, options, correctOptionIndex, points}] }
const createQuiz = async (req, res) => {
  try {
    const requester = await User.findById(req.user.id).select("role");
    if (requester?.role !== "instructor" && requester?.role !== "admin") {
      return res.status(403).json({ success: false, message: "Only instructors can create quizzes" });
    }

    const { course, lesson, title, passingScore, questions } = req.body;
    if (!course || !title || !Array.isArray(questions) || questions.length === 0) {
      return res.status(400).json({ success: false, message: "course, title, and at least one question are required" });
    }

    const quiz = await Quiz.create({
      course,
      lesson: lesson || undefined,
      title,
      totalQuestions: questions.length,
      passingScore: passingScore || 70,
      questions,
      createdBy: req.user.id,
    });

    res.status(201).json({ success: true, data: quiz });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

module.exports = { getQuizzesForCourse, getQuizForTaking, submitQuiz, getQuizHistory, createQuiz };
