const path = require("path");
const Assignment = require("../models/Assignment");
const Submission = require("../models/Submission");
const User = require("../models/User");
const Activity = require("../models/Activity");
const { notify } = require("../utils/notify");

// Week 6: Assignment Submission — instructors post assignments, students
// upload a file and/or write text, instructors grade the result.

// GET /api/assignments/course/:courseId
const getAssignmentsForCourse = async (req, res) => {
  try {
    const { courseId } = req.params;
    const assignments = await Assignment.find({ course: courseId }).sort({ dueDate: 1 });

    // If the caller is a student, attach their own submission status per assignment.
    const requester = await User.findById(req.user.id).select("role");
    let data = assignments;
    if (requester?.role === "student") {
      const submissions = await Submission.find({
        assignment: { $in: assignments.map((a) => a._id) },
        student: req.user.id,
      });
      const byAssignment = Object.fromEntries(submissions.map((s) => [s.assignment.toString(), s]));
      data = assignments.map((a) => ({ ...a.toObject(), mySubmission: byAssignment[a._id.toString()] || null }));
    }

    res.status(200).json({ success: true, data });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// POST /api/assignments  (instructor)  Body: { course, title, description, dueDate, maxScore }
const createAssignment = async (req, res) => {
  try {
    const requester = await User.findById(req.user.id).select("role");
    if (requester?.role !== "instructor" && requester?.role !== "admin") {
      return res.status(403).json({ success: false, message: "Only instructors can create assignments" });
    }

    const { course, title, description, dueDate, maxScore } = req.body;
    if (!course || !title || !dueDate) {
      return res.status(400).json({ success: false, message: "course, title, and dueDate are required" });
    }

    const assignment = await Assignment.create({
      course,
      instructor: req.user.id,
      title,
      description,
      dueDate,
      maxScore: maxScore || 100,
    });

    res.status(201).json({ success: true, data: assignment });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// POST /api/assignments/:assignmentId/submit  (student, multipart/form-data)
// Fields: file (optional), textContent (optional)
const submitAssignment = async (req, res) => {
  try {
    const { assignmentId } = req.params;
    const { textContent } = req.body;

    if (!req.file && !(textContent && textContent.trim())) {
      return res.status(400).json({ success: false, message: "Provide a file or text content" });
    }

    const assignment = await Assignment.findById(assignmentId);
    if (!assignment) return res.status(404).json({ success: false, message: "Assignment not found" });

    const isLate = new Date() > new Date(assignment.dueDate);

    const update = {
      textContent: textContent || "",
      submittedAt: new Date(),
      isLate,
      status: "submitted",
      score: null,
      feedback: "",
      gradedBy: undefined,
      gradedAt: undefined,
    };
    if (req.file) {
      update.fileUrl = `/uploads/assignments/${req.file.filename}`;
      update.fileName = req.file.originalname;
    }

    // Upsert: resubmitting before grading overwrites the previous attempt.
    const submission = await Submission.findOneAndUpdate(
      { assignment: assignmentId, student: req.user.id },
      { $set: update, $setOnInsert: { assignment: assignmentId, student: req.user.id } },
      { new: true, upsert: true }
    );

    await Activity.create({
      student: req.user.id,
      course: assignment.course,
      type: "assignment_submitted",
      description: `Submitted assignment: ${assignment.title}${isLate ? " (late)" : ""}`,
    });

    await notify({
      user: assignment.instructor,
      type: "assignment",
      title: "New assignment submission",
      message: `A student submitted "${assignment.title}"${isLate ? " (late)" : ""}`,
      link: `assignment:${assignmentId}`,
    });

    res.status(201).json({ success: true, data: submission });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// GET /api/assignments/:assignmentId/submissions  (instructor)
const getSubmissions = async (req, res) => {
  try {
    const { assignmentId } = req.params;
    const submissions = await Submission.find({ assignment: assignmentId })
      .populate("student", "name email")
      .sort({ submittedAt: -1 });
    res.status(200).json({ success: true, data: submissions });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// PATCH /api/assignments/submissions/:submissionId/grade  (instructor)  Body: { score, feedback }
const gradeSubmission = async (req, res) => {
  try {
    const { submissionId } = req.params;
    const { score, feedback } = req.body;

    if (typeof score !== "number") {
      return res.status(400).json({ success: false, message: "score must be a number" });
    }

    const submission = await Submission.findById(submissionId).populate("assignment", "title");
    if (!submission) return res.status(404).json({ success: false, message: "Submission not found" });

    submission.score = score;
    submission.feedback = feedback || "";
    submission.status = "graded";
    submission.gradedBy = req.user.id;
    submission.gradedAt = new Date();
    await submission.save();

    await notify({
      user: submission.student,
      type: "assignment",
      title: "Assignment graded",
      message: `You scored ${score} on "${submission.assignment.title}"`,
      link: `assignment:${submission.assignment._id}`,
    });

    res.status(200).json({ success: true, data: submission });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

module.exports = {
  getAssignmentsForCourse,
  createAssignment,
  submitAssignment,
  getSubmissions,
  gradeSubmission,
};
