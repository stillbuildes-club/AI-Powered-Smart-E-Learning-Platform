const Activity = require("../models/Activity");

// GET /api/activity
// Query params: page (default 1), limit (default 20), courseId (optional filter), type (optional filter)
const getActivityHistory = async (req, res) => {
  try {
    const studentId = req.user.id;
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 20;
    const filter = { student: studentId };

    if (req.query.courseId) filter.course = req.query.courseId;
    if (req.query.type) filter.type = req.query.type;

    const [activities, total] = await Promise.all([
      Activity.find(filter)
        .populate("course", "title")
        .sort({ createdAt: -1 })
        .skip((page - 1) * limit)
        .limit(limit),
      Activity.countDocuments(filter),
    ]);

    res.status(200).json({
      success: true,
      data: activities,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

module.exports = { getActivityHistory };
