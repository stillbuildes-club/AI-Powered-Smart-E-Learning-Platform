const {
  getSmartRecommendations,
  getRecommendationsByInterests,
  getRecommendationsByCompletedCourses,
  getRecommendationsByEnrolledCourses,
  getRecommendationsByHistory,
} = require("../services/recommendationService");

// Shared query-param parsing for every endpoint below.
function parseOptions(req) {
  const category = req.query.category || undefined;
  const limit = Math.min(50, parseInt(req.query.limit) || 10);
  return { category, limit };
}

// GET /api/recommendations
// Main "smart" endpoint: combines interests, completed courses, enrolled
// courses, and learning history into one ranked list. Supports ?category=&limit=
const getRecommendations = async (req, res) => {
  try {
    const results = await getSmartRecommendations(req.user.id, parseOptions(req));
    res.status(200).json({ success: true, count: results.length, data: results });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// GET /api/recommendations/interests
const getInterestBased = async (req, res) => {
  try {
    const results = await getRecommendationsByInterests(req.user.id, parseOptions(req));
    res.status(200).json({ success: true, count: results.length, data: results });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// GET /api/recommendations/completed
const getCompletedBased = async (req, res) => {
  try {
    const results = await getRecommendationsByCompletedCourses(req.user.id, parseOptions(req));
    res.status(200).json({ success: true, count: results.length, data: results });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// GET /api/recommendations/enrolled
const getEnrolledBased = async (req, res) => {
  try {
    const results = await getRecommendationsByEnrolledCourses(req.user.id, parseOptions(req));
    res.status(200).json({ success: true, count: results.length, data: results });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// GET /api/recommendations/history
const getHistoryBased = async (req, res) => {
  try {
    const results = await getRecommendationsByHistory(req.user.id, parseOptions(req));
    res.status(200).json({ success: true, count: results.length, data: results });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

module.exports = {
  getRecommendations,
  getInterestBased,
  getCompletedBased,
  getEnrolledBased,
  getHistoryBased,
};
