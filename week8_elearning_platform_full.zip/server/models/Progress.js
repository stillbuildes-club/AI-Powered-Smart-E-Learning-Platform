const mongoose = require("mongoose");

// Tracks a single lesson's completion state within a course enrollment.
const lessonProgressSchema = new mongoose.Schema(
  {
    lesson: { type: mongoose.Schema.Types.ObjectId, ref: "Lesson", required: true },
    status: { type: String, enum: ["not_started", "in_progress", "completed"], default: "not_started" },
    timeSpentMinutes: { type: Number, default: 0 },
    completedAt: { type: Date, default: null },
  },
  { _id: false }
);

// Tracks quiz attempts and best result within a course enrollment.
const quizProgressSchema = new mongoose.Schema(
  {
    quiz: { type: mongoose.Schema.Types.ObjectId, ref: "Quiz", required: true },
    attempts: { type: Number, default: 0 },
    bestScore: { type: Number, default: 0 }, // percentage
    passed: { type: Boolean, default: false },
    lastAttemptAt: { type: Date, default: null },
  },
  { _id: false }
);

// One Progress document per (student, course) enrollment.
const progressSchema = new mongoose.Schema(
  {
    student: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    course: { type: mongoose.Schema.Types.ObjectId, ref: "Course", required: true },
    status: { type: String, enum: ["not_started", "in_progress", "completed"], default: "not_started" },
    completionPercentage: { type: Number, default: 0, min: 0, max: 100 },
    lessonsProgress: [lessonProgressSchema],
    quizzesProgress: [quizProgressSchema],
    startedAt: { type: Date, default: null },
    lastAccessedAt: { type: Date, default: Date.now },
    completedAt: { type: Date, default: null },
  },
  { timestamps: true }
);

// A student can only have one progress record per course.
progressSchema.index({ student: 1, course: 1 }, { unique: true });

module.exports = mongoose.model("Progress", progressSchema);
