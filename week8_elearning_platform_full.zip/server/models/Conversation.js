const mongoose = require("mongoose");

// Week 6: A conversation is a 1-to-1 thread between a student and an
// instructor (optionally scoped to a course). Kept generic so a student
// and instructor can also message outside a specific course.
const conversationSchema = new mongoose.Schema(
  {
    participants: [
      { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    ],
    course: { type: mongoose.Schema.Types.ObjectId, ref: "Course" },
    lastMessage: {
      text: { type: String, default: "" },
      sender: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
      createdAt: { type: Date },
    },
  },
  { timestamps: true }
);

// Speeds up "find the conversation between these two users" lookups.
conversationSchema.index({ participants: 1 });

module.exports = mongoose.model("Conversation", conversationSchema);
