const mongoose = require("mongoose");

const lessonSchema = new mongoose.Schema(
  {
    course: { type: mongoose.Schema.Types.ObjectId, ref: "Course", required: true },
    title: { type: String, required: true, trim: true },
    order: { type: Number, required: true }, // position of the lesson within the course
    durationMinutes: { type: Number, default: 10 },
    videoUrl: { type: String },
    content: { type: String },
  },
  { timestamps: true }
);

module.exports = mongoose.model("Lesson", lessonSchema);
