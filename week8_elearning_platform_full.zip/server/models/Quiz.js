const mongoose = require("mongoose");

// Week 6: added the embedded `questions` array + `createdBy` so the same
// Quiz document that Week 4/5 progress tracking already references can
// now actually be taken interactively (Interactive Quiz System). All
// existing fields (course, lesson, title, totalQuestions, passingScore)
// are untouched, so Week 4's Progress.quizzesProgress logic keeps working.
const quizQuestionSchema = new mongoose.Schema({
  questionText: { type: String, required: true, trim: true },
  options: {
    type: [{ type: String, trim: true }],
    validate: (opts) => Array.isArray(opts) && opts.length >= 2,
  },
  correctOptionIndex: { type: Number, required: true, min: 0 },
  points: { type: Number, default: 1 },
});

const quizSchema = new mongoose.Schema(
  {
    course: { type: mongoose.Schema.Types.ObjectId, ref: "Course", required: true },
    lesson: { type: mongoose.Schema.Types.ObjectId, ref: "Lesson" }, // optional: quiz tied to a specific lesson
    title: { type: String, required: true, trim: true },
    totalQuestions: { type: Number, required: true, default: 10 },
    passingScore: { type: Number, required: true, default: 70 }, // percentage required to pass
    // Week 6: the actual interactive question bank for this quiz.
    // Optional/defaults to [] so pre-existing Quiz documents from Week 4/5
    // (metadata only, no questions yet) remain valid.
    questions: { type: [quizQuestionSchema], default: [] },
    createdBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  },
  { timestamps: true }
);

module.exports = mongoose.model("Quiz", quizSchema);
