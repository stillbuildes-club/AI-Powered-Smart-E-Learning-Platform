const mongoose = require("mongoose");

// Week 6: a graded attempt record for an interactive Quiz, storing the
// student's answer per question so results can be reviewed afterwards.
// (Distinct from the lightweight aggregate kept in Progress.quizzesProgress
// from Week 4 — that one only tracks best score / pass state for the
// dashboard; this one keeps the full per-question breakdown.)
const quizSubmissionSchema = new mongoose.Schema(
  {
    quiz: { type: mongoose.Schema.Types.ObjectId, ref: "Quiz", required: true },
    student: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    answers: [
      {
        question: { type: mongoose.Schema.Types.ObjectId, required: true },
        selectedOptionIndex: { type: Number, required: true },
        correct: { type: Boolean, required: true },
      },
    ],
    score: { type: Number, required: true }, // percentage 0-100
    passed: { type: Boolean, required: true },
  },
  { timestamps: true }
);

quizSubmissionSchema.index({ quiz: 1, student: 1, createdAt: -1 });

module.exports = mongoose.model("QuizSubmission", quizSubmissionSchema);
