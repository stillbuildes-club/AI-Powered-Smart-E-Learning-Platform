const mongoose = require("mongoose");

// Minimal User model. In the full project this already exists from
// Week 2/3 (auth) — kept here so this module can run standalone.
const userSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    password: { type: String, required: true, select: false },
    role: { type: String, enum: ["student", "instructor", "admin"], default: "student" },
    // Week 5: student-selected topics/categories used by the recommendation engine.
    // Optional and defaults to an empty array, so existing users/documents are unaffected.
    interests: [{ type: String, trim: true }],
  },
  { timestamps: true }
);

module.exports = mongoose.model("User", userSchema);
