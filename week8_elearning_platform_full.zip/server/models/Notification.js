const mongoose = require("mongoose");

// Week 6: persisted notifications so the bell icon has history even for
// events the user missed while offline (socket only covers "live" delivery).
const notificationSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    type: {
      type: String,
      enum: ["chat", "forum", "quiz", "assignment", "system"],
      default: "system",
    },
    title: { type: String, required: true },
    message: { type: String, default: "" },
    link: { type: String, default: "" }, // frontend route/tab hint, e.g. "chat:<conversationId>"
    isRead: { type: Boolean, default: false },
  },
  { timestamps: true }
);

notificationSchema.index({ user: 1, createdAt: -1 });

module.exports = mongoose.model("Notification", notificationSchema);
