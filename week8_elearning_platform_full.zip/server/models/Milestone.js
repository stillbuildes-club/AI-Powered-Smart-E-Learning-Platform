const mongoose = require("mongoose");

// Achievements earned by a student, either global or tied to one course.
const milestoneSchema = new mongoose.Schema(
  {
    student: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    course: { type: mongoose.Schema.Types.ObjectId, ref: "Course", default: null },
    type: {
      type: String,
      enum: [
        "course_started",
        "quarter_complete", // 25%
        "halfway_complete", // 50%
        "three_quarter_complete", // 75%
        "course_completed",
        "first_quiz_passed",
        "quiz_master", // all quizzes in a course passed
      ],
      required: true,
    },
    title: { type: String, required: true },
    description: { type: String, default: "" },
    icon: { type: String, default: "trophy" },
    achievedAt: { type: Date, default: Date.now },
  },
  { timestamps: true }
);

// Prevent the same milestone being awarded twice for the same course.
milestoneSchema.index({ student: 1, course: 1, type: 1 }, { unique: true });

module.exports = mongoose.model("Milestone", milestoneSchema);
