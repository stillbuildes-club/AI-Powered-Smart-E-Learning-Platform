const mongoose = require("mongoose");

// Week 6: a reply on a ForumPost. Flat (non-nested) replies keep the
// discussion simple to render and grade for this internship project.
const forumCommentSchema = new mongoose.Schema(
  {
    post: { type: mongoose.Schema.Types.ObjectId, ref: "ForumPost", required: true },
    author: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    body: { type: String, required: true },
    isInstructorReply: { type: Boolean, default: false },
  },
  { timestamps: true }
);

forumCommentSchema.index({ post: 1, createdAt: 1 });

module.exports = mongoose.model("ForumComment", forumCommentSchema);
