const mongoose = require("mongoose");

// A running log of everything a student does — powers "Activity History".
const activitySchema = new mongoose.Schema(
  {
    student: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    course: { type: mongoose.Schema.Types.ObjectId, ref: "Course" },
    type: {
      type: String,
      enum: [
        "course_started",
        "lesson_completed",
        "quiz_attempted",
        "quiz_passed",
        "course_completed",
        "milestone_achieved",
      ],
      required: true,
    },
    description: { type: String, required: true },
    metadata: { type: mongoose.Schema.Types.Mixed, default: {} }, // e.g. { lessonTitle, score }
  },
  { timestamps: true }
);

activitySchema.index({ student: 1, createdAt: -1 });

module.exports = mongoose.model("Activity", activitySchema);
