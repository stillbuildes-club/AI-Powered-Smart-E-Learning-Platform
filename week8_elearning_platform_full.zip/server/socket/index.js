const jwt = require("jsonwebtoken");
const { Server } = require("socket.io");
const Conversation = require("../models/Conversation");
const Message = require("../models/Message");

// Week 6: real-time layer for Chat, Discussion Forum notifications, and
// Live Notifications in general. Kept as a small self-contained module so
// controllers can `emitToUser(...)` without needing to know about sockets.
let io = null;

// Every connected socket auto-joins a private room named `user:<id>`.
// Any part of the backend can then push a live event to that specific
// user with emitToUser(userId, event, payload) regardless of which
// device/tab they're connected from.
const userRoom = (userId) => `user:${userId}`;
const conversationRoom = (conversationId) => `conversation:${conversationId}`;

function init(httpServer, clientUrl) {
  io = new Server(httpServer, {
    cors: {
      origin: clientUrl || "http://localhost:3000",
      credentials: true,
    },
  });

  // Auth handshake: client connects with `io(url, { auth: { token } })`.
  // Mirrors server/middleware/auth.js so socket connections use the same
  // JWTs issued at login.
  io.use((socket, next) => {
    try {
      const token =
        socket.handshake.auth?.token ||
        socket.handshake.headers?.authorization?.split(" ")[1];
      if (!token) return next(new Error("Not authorized, no token provided"));
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      socket.userId = decoded.id;
      next();
    } catch (err) {
      next(new Error("Not authorized, invalid token"));
    }
  });

  io.on("connection", (socket) => {
    socket.join(userRoom(socket.userId));

    // ---- Chat: join/leave a specific conversation room ----
    socket.on("chat:join", (conversationId) => {
      if (conversationId) socket.join(conversationRoom(conversationId));
    });

    socket.on("chat:leave", (conversationId) => {
      if (conversationId) socket.leave(conversationRoom(conversationId));
    });

    // ---- Chat: send a message in real time ----
    socket.on("chat:message", async ({ conversationId, text }, callback) => {
      try {
        if (!conversationId || !text || !text.trim()) return;

        const conversation = await Conversation.findById(conversationId);
        if (!conversation || !conversation.participants.some((p) => p.toString() === socket.userId)) {
          return callback && callback({ success: false, message: "Not part of this conversation" });
        }

        const message = await Message.create({
          conversation: conversationId,
          sender: socket.userId,
          text: text.trim(),
          readBy: [socket.userId],
        });

        conversation.lastMessage = { text: message.text, sender: socket.userId, createdAt: message.createdAt };
        await conversation.save();

        const populated = await message.populate("sender", "name role");

        io.to(conversationRoom(conversationId)).emit("chat:message", populated);

        // Notify the other participant(s) even if they aren't in the room.
        conversation.participants
          .filter((p) => p.toString() !== socket.userId)
          .forEach((participantId) => {
            io.to(userRoom(participantId)).emit("chat:incoming", {
              conversationId,
              message: populated,
            });
          });

        callback && callback({ success: true, data: populated });
      } catch (err) {
        callback && callback({ success: false, message: err.message });
      }
    });

    socket.on("chat:typing", ({ conversationId, isTyping }) => {
      if (!conversationId) return;
      socket.to(conversationRoom(conversationId)).emit("chat:typing", {
        conversationId,
        userId: socket.userId,
        isTyping: !!isTyping,
      });
    });
  });

  return io;
}

function getIO() {
  return io;
}

// Push a live event straight to one user's room (used for the
// Notification bell, forum replies, quiz results, assignment grading...).
function emitToUser(userId, event, payload) {
  if (!io || !userId) return;
  io.to(userRoom(userId.toString())).emit(event, payload);
}

module.exports = { init, getIO, emitToUser, userRoom, conversationRoom };
