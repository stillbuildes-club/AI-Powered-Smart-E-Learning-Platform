const jwt = require("jsonwebtoken");

// Protects routes by verifying the JWT sent in the Authorization header.
// Expected header format: "Authorization: Bearer <token>"
const protect = (req, res, next) => {
  let token;

  if (req.headers.authorization && req.headers.authorization.startsWith("Bearer")) {
    try {
      token = req.headers.authorization.split(" ")[1];
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      req.user = { id: decoded.id };
      return next();
    } catch (error) {
      return res.status(401).json({ success: false, message: "Not authorized, invalid token" });
    }
  }

  return res.status(401).json({ success: false, message: "Not authorized, no token provided" });
};

module.exports = { protect };
