import React, { createContext, useContext, useEffect, useState } from "react";
import { connectSocket, disconnectSocket } from "../services/socket";

// Minimal placeholder matching the AuthContext built in Week 2/3.
// Included so this module's imports resolve if you drop it into a fresh
// project — replace with your existing AuthContext in the real repo.
//
// Week 6: now also connects/disconnects the shared Socket.IO connection
// (services/socket.js) alongside login/logout, so Chat and Live
// Notifications are ready as soon as the user is authenticated.
const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(() => {
    const stored = localStorage.getItem("user");
    return stored ? JSON.parse(stored) : null;
  });

  // If the user was already logged in from a previous session (token in
  // localStorage), reconnect the socket on page load too.
  useEffect(() => {
    if (localStorage.getItem("token")) connectSocket();
    return () => disconnectSocket();
  }, []);

  const login = (userData, token) => {
    localStorage.setItem("token", token);
    localStorage.setItem("user", JSON.stringify(userData));
    setUser(userData);
    connectSocket();
  };

  const logout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    setUser(null);
    disconnectSocket();
  };

  return <AuthContext.Provider value={{ user, login, logout }}>{children}</AuthContext.Provider>;
};

export const useAuth = () => useContext(AuthContext);
