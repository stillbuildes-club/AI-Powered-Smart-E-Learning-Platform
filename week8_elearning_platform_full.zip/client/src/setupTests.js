// Week 7: jest-dom adds custom matchers like toBeInTheDocument(). CRA's
// react-scripts test runner auto-loads this file before every test suite.
import "@testing-library/jest-dom";
