import React, { useState, lazy, Suspense, useCallback } from "react";
import NotificationBell from "./components/Notifications/NotificationBell";
import ErrorBoundary from "./components/common/ErrorBoundary";
import Loader from "./components/common/Loader";

// Week 7: code-split every tab into its own chunk with React.lazy so the
// initial bundle only ships the Dashboard (the default tab) — Chat, Forum,
// Quiz, Assignments, and Recommendations are fetched on first visit to that
// tab instead of on every page load. NotificationBell stays a normal (eager)
// import since it's always visible in the top bar.
const ProgressDashboard = lazy(() => import("./components/Dashboard/ProgressDashboard"));
const RecommendedCourses = lazy(() => import("./components/Recommendations/RecommendedCourses"));
const ChatPage = lazy(() => import("./components/Chat/ChatPage"));
const ForumPage = lazy(() => import("./components/Forum/ForumPage"));
const QuizPage = lazy(() => import("./components/Quiz/QuizPage"));
const AssignmentPage = lazy(() => import("./components/Assignments/AssignmentPage"));

// Week 4 rendered the Progress Dashboard directly, and Week 5 added
// Recommended Courses below it. Week 6 adds Chat, Discussion Forum, Live
// Notifications, Interactive Quizzes, and Assignment Submission.
//
// This project doesn't use react-router yet (Weeks 1-5 kept everything on
// one screen), so Week 6 introduces a light, dependency-free tab switcher
// instead of stacking every section on one long page. Swap this for real
// routes (react-router-dom) whenever the rest of the app adopts routing.
const TABS = [
  { key: "dashboard", label: "Dashboard", Component: ProgressDashboard },
  { key: "recommendations", label: "Recommendations", Component: RecommendedCourses },
  { key: "chat", label: "Chat", Component: ChatPage },
  { key: "forum", label: "Forum", Component: ForumPage },
  { key: "quizzes", label: "Quizzes", Component: QuizPage },
  { key: "assignments", label: "Assignments", Component: AssignmentPage },
];

function App() {
  const [activeTab, setActiveTab] = useState("dashboard");

  // Week 7: memoized so the tab buttons (wrapped in React.memo-friendly
  // props below) don't get a new handler identity on every render.
  const handleTabClick = useCallback((key) => setActiveTab(key), []);

  const ActiveTabComponent = TABS.find((t) => t.key === activeTab)?.Component;

  return (
    <div className="App">
      <div style={styles.topBar}>
        <div style={styles.tabs}>
          {TABS.map((tab) => (
            <button
              key={tab.key}
              onClick={() => handleTabClick(tab.key)}
              style={{ ...styles.tabBtn, ...(activeTab === tab.key ? styles.tabBtnActive : {}) }}
            >
              {tab.label}
            </button>
          ))}
        </div>
        <NotificationBell />
      </div>

      {/* Week 7: each lazy-loaded tab is wrapped in its own ErrorBoundary so
          a failure in one tab (e.g. Chat's socket connection) can't blank
          the whole app, plus a Suspense fallback for the chunk download. */}
      <ErrorBoundary key={activeTab} fallbackMessage={`The ${activeTab} tab failed to load.`}>
        <Suspense fallback={<Loader />}>{ActiveTabComponent && <ActiveTabComponent />}</Suspense>
      </ErrorBoundary>
    </div>
  );
}

const styles = {
  topBar: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    padding: "10px 24px",
    borderBottom: "1px solid #e5e7eb",
    background: "#fff",
    position: "sticky",
    top: 0,
    zIndex: 40,
  },
  tabs: { display: "flex", gap: 4, flexWrap: "wrap" },
  tabBtn: {
    padding: "8px 14px",
    borderRadius: 8,
    border: "none",
    background: "transparent",
    color: "#6b7280",
    fontWeight: 600,
    fontSize: 14,
  },
  tabBtnActive: { background: "#eef2ff", color: "#4f46e5" },
};

export default App;
