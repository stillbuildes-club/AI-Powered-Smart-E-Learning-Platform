import React, { useEffect, useRef, useState } from "react";
import { getNotifications, markAsRead, markAllAsRead } from "../../services/notificationService";
import { connectSocket } from "../../services/socket";

// Week 6: Live Notifications bell. Loads history via REST, then listens on
// the "notification:new" socket event for real-time pushes (chat, forum
// replies, quiz results, assignment grading, etc.).
const NotificationBell = () => {
  const [notifications, setNotifications] = useState([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [open, setOpen] = useState(false);
  const wrapperRef = useRef(null);

  const load = () => {
    getNotifications({ limit: 20 }).then(({ notifications, unreadCount }) => {
      setNotifications(notifications);
      setUnreadCount(unreadCount);
    });
  };

  useEffect(() => {
    load();

    const socket = connectSocket();
    if (socket) {
      const onNew = (notification) => {
        setNotifications((prev) => [notification, ...prev].slice(0, 20));
        setUnreadCount((c) => c + 1);
      };
      socket.on("notification:new", onNew);
      return () => socket.off("notification:new", onNew);
    }
  }, []);

  useEffect(() => {
    const handleClickOutside = (e) => {
      if (wrapperRef.current && !wrapperRef.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleOpen = () => setOpen((o) => !o);

  const handleItemClick = async (n) => {
    if (!n.isRead) {
      await markAsRead(n._id);
      setNotifications((prev) => prev.map((x) => (x._id === n._id ? { ...x, isRead: true } : x)));
      setUnreadCount((c) => Math.max(0, c - 1));
    }
  };

  const handleMarkAll = async () => {
    await markAllAsRead();
    setNotifications((prev) => prev.map((n) => ({ ...n, isRead: true })));
    setUnreadCount(0);
  };

  return (
    <div ref={wrapperRef} style={styles.wrapper}>
      <button onClick={handleOpen} style={styles.bellBtn} aria-label="Notifications">
        🔔
        {unreadCount > 0 && <span style={styles.badge}>{unreadCount > 9 ? "9+" : unreadCount}</span>}
      </button>

      {open && (
        <div style={styles.dropdown}>
          <div style={styles.dropdownHeader}>
            <strong>Notifications</strong>
            {unreadCount > 0 && (
              <button onClick={handleMarkAll} style={styles.markAllBtn}>
                Mark all read
              </button>
            )}
          </div>
          <div style={styles.list}>
            {notifications.length === 0 && <p style={styles.empty}>No notifications yet.</p>}
            {notifications.map((n) => (
              <div
                key={n._id}
                onClick={() => handleItemClick(n)}
                style={{ ...styles.item, background: n.isRead ? "#fff" : "#eef2ff" }}
              >
                <div style={styles.itemTitle}>{n.title}</div>
                {n.message && <div style={styles.itemMessage}>{n.message}</div>}
                <div style={styles.itemTime}>{new Date(n.createdAt).toLocaleString()}</div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

const styles = {
  wrapper: { position: "relative" },
  bellBtn: { position: "relative", background: "none", border: "none", fontSize: 20, cursor: "pointer", padding: 6 },
  badge: {
    position: "absolute",
    top: 0,
    right: 0,
    background: "#dc2626",
    color: "#fff",
    fontSize: 10,
    borderRadius: 999,
    padding: "1px 5px",
    fontWeight: 700,
  },
  dropdown: {
    position: "absolute",
    right: 0,
    top: "110%",
    width: 320,
    maxHeight: 400,
    overflowY: "auto",
    background: "#fff",
    border: "1px solid #e5e7eb",
    borderRadius: 12,
    boxShadow: "0 10px 30px rgba(0,0,0,0.1)",
    zIndex: 50,
  },
  dropdownHeader: { display: "flex", justifyContent: "space-between", alignItems: "center", padding: "10px 14px", borderBottom: "1px solid #f3f4f6" },
  markAllBtn: { background: "none", border: "none", color: "#4f46e5", fontSize: 12, cursor: "pointer" },
  list: { padding: 6 },
  empty: { padding: 14, color: "#6b7280", fontSize: 13 },
  item: { padding: "10px 10px", borderRadius: 8, cursor: "pointer", marginBottom: 2 },
  itemTitle: { fontSize: 13, fontWeight: 600, color: "#111827" },
  itemMessage: { fontSize: 12, color: "#4b5563", marginTop: 2 },
  itemTime: { fontSize: 11, color: "#9ca3af", marginTop: 4 },
};

export default NotificationBell;
