import React, { useEffect, useState } from "react";
import { getAssignmentsForCourse, submitAssignment } from "../../services/assignmentService";
import { useAuth } from "../../context/AuthContext";
import Loader from "../common/Loader";

// Week 6: lists assignments for a course. Students see a submit form
// inline; instructors see a "View submissions" link (handled by parent).
const AssignmentList = ({ courseId, onGrade }) => {
  const { user } = useAuth();
  const [assignments, setAssignments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [drafts, setDrafts] = useState({}); // { assignmentId: { file, textContent } }
  const [submittingId, setSubmittingId] = useState(null);

  const load = () => {
    if (!courseId) return;
    setLoading(true);
    getAssignmentsForCourse(courseId)
      .then(setAssignments)
      .finally(() => setLoading(false));
  };

  useEffect(load, [courseId]);

  const updateDraft = (id, field, value) => {
    setDrafts((prev) => ({ ...prev, [id]: { ...prev[id], [field]: value } }));
  };

  const handleSubmit = async (assignmentId) => {
    const draft = drafts[assignmentId] || {};
    if (!draft.file && !draft.textContent) return;
    setSubmittingId(assignmentId);
    try {
      await submitAssignment(assignmentId, draft);
      load();
    } finally {
      setSubmittingId(null);
    }
  };

  if (loading) return <Loader label="Loading assignments..." />;
  if (assignments.length === 0) return <p style={{ color: "#6b7280" }}>No assignments posted for this course yet.</p>;

  return (
    <div>
      {assignments.map((a) => {
        const overdue = new Date() > new Date(a.dueDate);
        return (
          <div key={a._id} style={styles.card}>
            <div style={styles.rowTop}>
              <strong>{a.title}</strong>
              <span style={{ ...styles.dueBadge, color: overdue ? "#dc2626" : "#6b7280" }}>
                Due {new Date(a.dueDate).toLocaleDateString()}
              </span>
            </div>
            <p style={styles.desc}>{a.description}</p>

            {user?.role === "instructor" ? (
              <button onClick={() => onGrade(a)} style={styles.viewBtn}>
                View Submissions
              </button>
            ) : a.mySubmission ? (
              <div style={styles.submittedBox}>
                ✅ Submitted {new Date(a.mySubmission.submittedAt).toLocaleString()}
                {a.mySubmission.isLate && " (late)"}
                {a.mySubmission.status === "graded" && (
                  <div>
                    Score: <strong>{a.mySubmission.score}</strong> / {a.maxScore}
                    {a.mySubmission.feedback && ` — ${a.mySubmission.feedback}`}
                  </div>
                )}
              </div>
            ) : (
              <div style={styles.submitForm}>
                <textarea
                  placeholder="Optional text answer..."
                  rows={2}
                  value={drafts[a._id]?.textContent ?? ""}
                  onChange={(e) => updateDraft(a._id, "textContent", e.target.value)}
                  style={styles.textarea}
                />
                <input
                  type="file"
                  onChange={(e) => updateDraft(a._id, "file", e.target.files[0])}
                  style={styles.fileInput}
                />
                <button
                  onClick={() => handleSubmit(a._id)}
                  disabled={submittingId === a._id}
                  style={styles.submitBtn}
                >
                  {submittingId === a._id ? "Submitting..." : "Submit Assignment"}
                </button>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
};

const styles = {
  card: { background: "#fff", border: "1px solid #e5e7eb", borderRadius: 10, padding: 14, marginBottom: 10 },
  rowTop: { display: "flex", justifyContent: "space-between", flexWrap: "wrap", gap: 6 },
  dueBadge: { fontSize: 12 },
  desc: { fontSize: 14, color: "#374151", margin: "6px 0 10px" },
  viewBtn: { padding: "8px 14px", borderRadius: 8, border: "1px solid #e5e7eb", background: "#f9fafb" },
  submittedBox: { fontSize: 13, color: "#166534", background: "#f0fdf4", padding: "8px 10px", borderRadius: 8 },
  submitForm: { display: "flex", flexDirection: "column", gap: 8 },
  textarea: { width: "100%", padding: "8px 10px", borderRadius: 8, border: "1px solid #e5e7eb", boxSizing: "border-box", fontFamily: "inherit", resize: "vertical" },
  fileInput: { fontSize: 13 },
  submitBtn: { padding: "8px 14px", borderRadius: 8, border: "none", background: "#4f46e5", color: "#fff", fontWeight: 600, alignSelf: "flex-start" },
};

export default AssignmentList;
