import React, { useState } from "react";
import CourseSelector from "../common/CourseSelector";
import AssignmentList from "./AssignmentList";
import SubmissionsGrading from "./SubmissionsGrading";

// Week 6: top-level Assignment Submission screen.
const AssignmentPage = () => {
  const [courseId, setCourseId] = useState(null);
  const [gradingAssignment, setGradingAssignment] = useState(null);

  return (
    <div style={styles.page}>
      <h2 style={styles.pageTitle}>Assignments</h2>

      {!gradingAssignment && (
        <div style={styles.topRow}>
          <CourseSelector value={courseId} onChange={setCourseId} />
        </div>
      )}

      {gradingAssignment ? (
        <SubmissionsGrading assignment={gradingAssignment} onBack={() => setGradingAssignment(null)} />
      ) : (
        <AssignmentList courseId={courseId} onGrade={setGradingAssignment} />
      )}
    </div>
  );
};

const styles = {
  page: { maxWidth: 900, margin: "0 auto", padding: 24, fontFamily: "Inter, system-ui, sans-serif" },
  pageTitle: { fontSize: 22, marginBottom: 16, color: "#111827" },
  topRow: { marginBottom: 16 },
};

export default AssignmentPage;
