import React, { useEffect, useState } from "react";
import { getSubmissions, gradeSubmission } from "../../services/assignmentService";
import Loader from "../common/Loader";

// Week 6: instructor-only view — list submissions for one assignment and grade them.
const SubmissionsGrading = ({ assignment, onBack }) => {
  const [submissions, setSubmissions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [drafts, setDrafts] = useState({}); // { submissionId: { score, feedback } }

  const load = () => {
    setLoading(true);
    getSubmissions(assignment._id)
      .then(setSubmissions)
      .finally(() => setLoading(false));
  };

  useEffect(load, [assignment._id]);

  const updateDraft = (id, field, value) => {
    setDrafts((prev) => ({ ...prev, [id]: { ...prev[id], [field]: value } }));
  };

  const handleGrade = async (submissionId) => {
    const draft = drafts[submissionId] || {};
    const score = Number(draft.score);
    if (Number.isNaN(score)) return;
    await gradeSubmission(submissionId, { score, feedback: draft.feedback || "" });
    load();
  };

  if (loading) return <Loader label="Loading submissions..." />;

  return (
    <div>
      <button onClick={onBack} style={styles.backLink}>
        ← Back to assignments
      </button>
      <h3 style={styles.title}>Submissions for "{assignment.title}"</h3>

      {submissions.length === 0 && <p style={{ color: "#6b7280" }}>No submissions yet.</p>}

      {submissions.map((s) => (
        <div key={s._id} style={styles.card}>
          <div style={styles.rowTop}>
            <strong>{s.student?.name}</strong>
            <span style={styles.status}>{s.status}{s.isLate ? " · late" : ""}</span>
          </div>
          {s.textContent && <p style={styles.text}>{s.textContent}</p>}
          {s.fileUrl && (
            <a href={`${process.env.REACT_APP_API_URL?.replace("/api", "") || "http://localhost:5000"}${s.fileUrl}`} target="_blank" rel="noreferrer" style={styles.fileLink}>
              📎 {s.fileName || "Download submission"}
            </a>
          )}

          {s.status === "graded" ? (
            <div style={styles.gradedBox}>
              Score: <strong>{s.score}</strong> / {assignment.maxScore} — {s.feedback || "No feedback"}
            </div>
          ) : (
            <div style={styles.gradeForm}>
              <input
                type="number"
                placeholder={`Score /${assignment.maxScore}`}
                value={drafts[s._id]?.score ?? ""}
                onChange={(e) => updateDraft(s._id, "score", e.target.value)}
                style={styles.scoreInput}
              />
              <input
                type="text"
                placeholder="Feedback (optional)"
                value={drafts[s._id]?.feedback ?? ""}
                onChange={(e) => updateDraft(s._id, "feedback", e.target.value)}
                style={styles.feedbackInput}
              />
              <button onClick={() => handleGrade(s._id)} style={styles.gradeBtn}>
                Grade
              </button>
            </div>
          )}
        </div>
      ))}
    </div>
  );
};

const styles = {
  backLink: { background: "none", border: "none", color: "#4f46e5", cursor: "pointer", marginBottom: 12, fontSize: 14, padding: 0 },
  title: { fontSize: 18, color: "#111827", marginBottom: 16 },
  card: { background: "#fff", border: "1px solid #e5e7eb", borderRadius: 10, padding: 14, marginBottom: 10 },
  rowTop: { display: "flex", justifyContent: "space-between", marginBottom: 6 },
  status: { fontSize: 12, color: "#6b7280", textTransform: "capitalize" },
  text: { fontSize: 14, color: "#374151", marginBottom: 8 },
  fileLink: { fontSize: 13, color: "#4f46e5", display: "inline-block", marginBottom: 8 },
  gradedBox: { fontSize: 13, color: "#111827", background: "#f0fdf4", padding: "8px 10px", borderRadius: 8 },
  gradeForm: { display: "flex", gap: 8, flexWrap: "wrap" },
  scoreInput: { width: 100, padding: "8px 10px", borderRadius: 8, border: "1px solid #e5e7eb" },
  feedbackInput: { flex: 1, minWidth: 160, padding: "8px 10px", borderRadius: 8, border: "1px solid #e5e7eb" },
  gradeBtn: { padding: "8px 14px", borderRadius: 8, border: "none", background: "#4f46e5", color: "#fff", fontWeight: 600 },
};

export default SubmissionsGrading;
