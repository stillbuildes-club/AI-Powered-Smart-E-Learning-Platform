import React, { useEffect, useState } from "react";
import { getPostWithComments, addComment, toggleUpvote } from "../../services/forumService";
import Loader from "../common/Loader";

// Week 6: single discussion thread — original post + comment list + reply box.
const ForumThread = ({ postId, onBack }) => {
  const [data, setData] = useState(null);
  const [reply, setReply] = useState("");
  const [loading, setLoading] = useState(true);
  const [posting, setPosting] = useState(false);

  const load = () => {
    setLoading(true);
    getPostWithComments(postId)
      .then(setData)
      .finally(() => setLoading(false));
  };

  useEffect(load, [postId]);

  const handleReply = async (e) => {
    e.preventDefault();
    if (!reply.trim()) return;
    setPosting(true);
    try {
      await addComment(postId, reply);
      setReply("");
      load();
    } finally {
      setPosting(false);
    }
  };

  const handleUpvote = async () => {
    const result = await toggleUpvote(postId);
    setData((prev) => ({ ...prev, post: { ...prev.post, upvotes: new Array(result.upvoteCount).fill(0) } }));
  };

  if (loading) return <Loader label="Loading thread..." />;
  if (!data) return null;

  const { post, comments } = data;

  return (
    <div>
      <button onClick={onBack} style={styles.backBtn}>
        ← Back to forum
      </button>

      <div style={styles.postCard}>
        <h3 style={styles.postTitle}>{post.title}</h3>
        <div style={styles.meta}>
          {post.author?.name} · {post.author?.role} · {new Date(post.createdAt).toLocaleString()}
        </div>
        <p style={styles.body}>{post.body}</p>
        <button onClick={handleUpvote} style={styles.upvoteBtn}>
          ▲ {post.upvotes?.length || 0} Upvotes
        </button>
      </div>

      <h4 style={styles.commentsTitle}>{comments.length} Replies</h4>
      {comments.map((c) => (
        <div key={c._id} style={styles.comment}>
          <div style={styles.meta}>
            <strong>{c.author?.name}</strong>
            {c.isInstructorReply && <span style={styles.instructorBadge}>Instructor</span>}
            {" · "}
            {new Date(c.createdAt).toLocaleString()}
          </div>
          <p style={styles.commentBody}>{c.body}</p>
        </div>
      ))}

      <form onSubmit={handleReply} style={styles.replyForm}>
        <textarea
          value={reply}
          onChange={(e) => setReply(e.target.value)}
          placeholder="Write a reply..."
          rows={3}
          style={styles.textarea}
        />
        <button type="submit" disabled={posting} style={styles.submitBtn}>
          {posting ? "Posting..." : "Reply"}
        </button>
      </form>
    </div>
  );
};

const styles = {
  backBtn: { background: "none", border: "none", color: "#4f46e5", cursor: "pointer", marginBottom: 12, fontSize: 14, padding: 0 },
  postCard: { background: "#fff", border: "1px solid #e5e7eb", borderRadius: 12, padding: 18, marginBottom: 20 },
  postTitle: { fontSize: 18, marginBottom: 6, color: "#111827" },
  meta: { fontSize: 12, color: "#6b7280", marginBottom: 10 },
  body: { fontSize: 14, color: "#374151", lineHeight: 1.6, whiteSpace: "pre-wrap" },
  upvoteBtn: { marginTop: 10, padding: "6px 12px", borderRadius: 8, border: "1px solid #e5e7eb", background: "#f9fafb", cursor: "pointer" },
  commentsTitle: { fontSize: 14, color: "#111827", marginBottom: 10 },
  comment: { background: "#fff", border: "1px solid #f3f4f6", borderRadius: 10, padding: 12, marginBottom: 8 },
  commentBody: { fontSize: 14, color: "#374151", marginTop: 4 },
  instructorBadge: { fontSize: 10, background: "#dcfce7", color: "#166534", padding: "1px 8px", borderRadius: 999, marginLeft: 6 },
  replyForm: { marginTop: 16 },
  textarea: { width: "100%", padding: "10px 12px", borderRadius: 8, border: "1px solid #e5e7eb", fontSize: 14, marginBottom: 10, boxSizing: "border-box", fontFamily: "inherit", resize: "vertical" },
  submitBtn: { padding: "8px 14px", borderRadius: 8, border: "none", background: "#4f46e5", color: "#fff", fontWeight: 600 },
};

export default ForumThread;
