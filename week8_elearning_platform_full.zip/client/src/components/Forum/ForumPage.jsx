import React, { useEffect, useState } from "react";
import { getPosts, createPost } from "../../services/forumService";
import CourseSelector from "../common/CourseSelector";
import NewPostForm from "./NewPostForm";
import ForumThread from "./ForumThread";
import Loader from "../common/Loader";

// Week 6: top-level Discussion Forum screen — course-scoped list of
// threads, with a "new post" composer and a thread detail view.
const ForumPage = () => {
  const [courseId, setCourseId] = useState(null);
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [openPostId, setOpenPostId] = useState(null);

  const loadPosts = (cId) => {
    if (!cId) return;
    setLoading(true);
    getPosts(cId)
      .then(setPosts)
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    loadPosts(courseId);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [courseId]);

  const handleCreate = async (payload) => {
    await createPost(courseId, payload);
    setShowForm(false);
    loadPosts(courseId);
  };

  return (
    <div style={styles.page}>
      <h2 style={styles.pageTitle}>Discussion Forum</h2>

      <div style={styles.topRow}>
        <CourseSelector value={courseId} onChange={setCourseId} />
        {!openPostId && (
          <button onClick={() => setShowForm((s) => !s)} style={styles.newPostBtn}>
            {showForm ? "Close" : "+ New Post"}
          </button>
        )}
      </div>

      {openPostId ? (
        <ForumThread postId={openPostId} onBack={() => setOpenPostId(null)} />
      ) : (
        <>
          {showForm && <NewPostForm onCreate={handleCreate} onCancel={() => setShowForm(false)} />}

          {loading ? (
            <Loader label="Loading discussions..." />
          ) : posts.length === 0 ? (
            <p style={{ color: "#6b7280" }}>No discussions yet for this course. Be the first to post!</p>
          ) : (
            posts.map((post) => (
              <div key={post._id} onClick={() => setOpenPostId(post._id)} style={styles.postRow}>
                <div style={styles.postRowTitle}>{post.title}</div>
                <div style={styles.postRowMeta}>
                  {post.author?.name} · {post.commentsCount} replies · ▲ {post.upvotes?.length || 0}
                </div>
              </div>
            ))
          )}
        </>
      )}
    </div>
  );
};

const styles = {
  page: { maxWidth: 900, margin: "0 auto", padding: 24, fontFamily: "Inter, system-ui, sans-serif" },
  pageTitle: { fontSize: 22, marginBottom: 16, color: "#111827" },
  topRow: { display: "flex", justifyContent: "space-between", alignItems: "center", gap: 10, marginBottom: 16, flexWrap: "wrap" },
  newPostBtn: { padding: "8px 16px", borderRadius: 8, border: "none", background: "#4f46e5", color: "#fff", fontWeight: 600 },
  postRow: { background: "#fff", border: "1px solid #e5e7eb", borderRadius: 10, padding: 14, marginBottom: 8, cursor: "pointer" },
  postRowTitle: { fontSize: 15, fontWeight: 600, color: "#111827" },
  postRowMeta: { fontSize: 12, color: "#6b7280", marginTop: 4 },
};

export default ForumPage;
