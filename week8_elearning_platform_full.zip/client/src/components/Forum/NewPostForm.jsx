import React, { useState } from "react";

// Week 6: small inline form for starting a new discussion thread.
const NewPostForm = ({ onCreate, onCancel }) => {
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!title.trim() || !body.trim()) return;
    setSubmitting(true);
    try {
      await onCreate({ title, body });
      setTitle("");
      setBody("");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} style={styles.form}>
      <input
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        placeholder="Post title"
        style={styles.input}
      />
      <textarea
        value={body}
        onChange={(e) => setBody(e.target.value)}
        placeholder="Write your question or discussion topic..."
        rows={4}
        style={styles.textarea}
      />
      <div style={styles.actions}>
        <button type="button" onClick={onCancel} style={styles.cancelBtn}>
          Cancel
        </button>
        <button type="submit" disabled={submitting} style={styles.submitBtn}>
          {submitting ? "Posting..." : "Post"}
        </button>
      </div>
    </form>
  );
};

const styles = {
  form: { background: "#fff", border: "1px solid #e5e7eb", borderRadius: 12, padding: 16, marginBottom: 16 },
  input: { width: "100%", padding: "10px 12px", borderRadius: 8, border: "1px solid #e5e7eb", fontSize: 14, marginBottom: 10, boxSizing: "border-box" },
  textarea: { width: "100%", padding: "10px 12px", borderRadius: 8, border: "1px solid #e5e7eb", fontSize: 14, marginBottom: 10, boxSizing: "border-box", fontFamily: "inherit", resize: "vertical" },
  actions: { display: "flex", justifyContent: "flex-end", gap: 8 },
  cancelBtn: { padding: "8px 14px", borderRadius: 8, border: "1px solid #e5e7eb", background: "#fff" },
  submitBtn: { padding: "8px 14px", borderRadius: 8, border: "none", background: "#4f46e5", color: "#fff", fontWeight: 600 },
};

export default NewPostForm;
