import React, { useEffect, useState } from "react";
import { getActivityHistory } from "../../services/progressService";
import Loader from "../common/Loader";

const typeIcons = {
  course_started: "🚀",
  lesson_completed: "📘",
  quiz_attempted: "📝",
  quiz_passed: "✅",
  course_completed: "🎓",
  milestone_achieved: "🏆",
};

// Paginated feed of everything the student has done, newest first.
const ActivityHistory = () => {
  const [activities, setActivities] = useState([]);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    getActivityHistory({ page, limit: 10 })
      .then((res) => {
        if (cancelled) return;
        setActivities(res.data);
        setTotalPages(res.pagination.totalPages);
      })
      .catch(() => {})
      .finally(() => !cancelled && setLoading(false));
    return () => {
      cancelled = true;
    };
  }, [page]);

  return (
    <div style={styles.wrapper}>
      <h4 style={styles.heading}>Activity History</h4>
      {loading ? (
        <Loader label="Loading activity..." />
      ) : (
        <>
          <ul style={styles.list}>
            {activities.map((a) => (
              <li key={a._id} style={styles.item}>
                <span style={styles.icon}>{typeIcons[a.type] || "•"}</span>
                <div>
                  <div style={styles.desc}>{a.description}</div>
                  <div style={styles.meta}>
                    {a.course?.title ? `${a.course.title} · ` : ""}
                    {new Date(a.createdAt).toLocaleString()}
                  </div>
                </div>
              </li>
            ))}
            {activities.length === 0 && <p style={styles.empty}>No activity yet.</p>}
          </ul>
          {totalPages > 1 && (
            <div style={styles.pagination}>
              <button disabled={page <= 1} onClick={() => setPage((p) => p - 1)}>
                Prev
              </button>
              <span>
                {page} / {totalPages}
              </span>
              <button disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)}>
                Next
              </button>
            </div>
          )}
        </>
      )}
    </div>
  );
};

const styles = {
  wrapper: { background: "#fff", border: "1px solid #e5e7eb", borderRadius: 12, padding: 16 },
  heading: { margin: "0 0 10px 0", fontSize: 15 },
  list: { listStyle: "none", margin: 0, padding: 0 },
  item: { display: "flex", gap: 10, padding: "8px 0", borderBottom: "1px solid #f3f4f6" },
  icon: { fontSize: 18 },
  desc: { fontSize: 13 },
  meta: { fontSize: 11, color: "#9ca3af" },
  empty: { fontSize: 13, color: "#9ca3af" },
  pagination: { display: "flex", justifyContent: "center", gap: 12, alignItems: "center", marginTop: 12, fontSize: 12 },
};

export default ActivityHistory;
