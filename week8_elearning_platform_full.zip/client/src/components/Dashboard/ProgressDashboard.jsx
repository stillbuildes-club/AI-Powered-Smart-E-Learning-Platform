import React, { useEffect, useState } from "react";
import { getDashboard } from "../../services/progressService";
import CourseCompletionCard from "./CourseCompletionCard";
import ActivityHistory from "./ActivityHistory";
import MilestoneTracker from "./MilestoneTracker";
import ProgressCharts from "./ProgressCharts";
import LessonProgressList from "./LessonProgressList";
import QuizProgressList from "./QuizProgressList";
import Loader from "../common/Loader";

// Top-level Week 4 screen: Student Progress Dashboard.
// Combines course completion, activity history, milestones, and charts.
const ProgressDashboard = () => {
  const [dashboard, setDashboard] = useState(null);
  const [selectedCourse, setSelectedCourse] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    getDashboard()
      .then((data) => {
        setDashboard(data);
        if (data.courses.length > 0) setSelectedCourse(data.courses[0]);
      })
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <Loader label="Loading your dashboard..." />;
  if (error) return <p style={{ color: "#dc2626" }}>Failed to load dashboard: {error}</p>;
  if (!dashboard) return null;

  const { summary, courses } = dashboard;

  return (
    <div style={styles.page}>
      <h2 style={styles.pageTitle}>Student Progress Dashboard</h2>

      {/* Summary cards */}
      <div style={styles.summaryRow}>
        <SummaryStat label="Enrolled Courses" value={summary.totalCourses} />
        <SummaryStat label="Completed" value={summary.completedCourses} color="#16a34a" />
        <SummaryStat label="In Progress" value={summary.inProgressCourses} color="#4f46e5" />
        <SummaryStat label="Avg. Completion" value={`${summary.avgCompletion}%`} color="#f59e0b" />
      </div>

      <div style={styles.mainGrid}>
        {/* Left column: course list + selected course detail */}
        <div style={styles.leftCol}>
          <h3 style={styles.sectionTitle}>Course Completion</h3>
          {courses.map((p) => (
            <div key={p._id} onClick={() => setSelectedCourse(p)} style={{ cursor: "pointer" }}>
              <CourseCompletionCard progress={p} />
            </div>
          ))}

          {selectedCourse && (
            <div style={styles.detailBlock}>
              <LessonProgressList lessonsProgress={selectedCourse.lessonsProgress} />
              <div style={{ height: 12 }} />
              <QuizProgressList quizzesProgress={selectedCourse.quizzesProgress} />
            </div>
          )}
        </div>

        {/* Right column: milestones + activity history */}
        <div style={styles.rightCol}>
          <MilestoneTracker courseId={selectedCourse?.course?._id} />
          <div style={{ height: 16 }} />
          <ActivityHistory />
        </div>
      </div>

      <div style={{ height: 24 }} />
      <h3 style={styles.sectionTitle}>Progress Charts</h3>
      <ProgressCharts />
    </div>
  );
};

const SummaryStat = ({ label, value, color = "#111827" }) => (
  <div style={styles.statCard}>
    <div style={{ ...styles.statValue, color }}>{value}</div>
    <div style={styles.statLabel}>{label}</div>
  </div>
);

const styles = {
  page: { maxWidth: 1100, margin: "0 auto", padding: 24, fontFamily: "Inter, system-ui, sans-serif" },
  pageTitle: { fontSize: 22, marginBottom: 20, color: "#111827" },
  summaryRow: { display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 12, marginBottom: 24 },
  statCard: { background: "#fff", border: "1px solid #e5e7eb", borderRadius: 12, padding: 16, textAlign: "center" },
  statValue: { fontSize: 24, fontWeight: 700 },
  statLabel: { fontSize: 12, color: "#6b7280", marginTop: 4 },
  mainGrid: { display: "grid", gridTemplateColumns: "1.2fr 1fr", gap: 20 },
  leftCol: { display: "flex", flexDirection: "column" },
  rightCol: { display: "flex", flexDirection: "column" },
  detailBlock: { marginTop: 12 },
  sectionTitle: { fontSize: 16, marginBottom: 10, color: "#111827" },
};

export default ProgressDashboard;
