import React, { useEffect, useState } from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  Legend,
} from "recharts";
import { getProgressCharts } from "../../services/progressService";
import Loader from "../common/Loader";

// Three charts: completion % per course, lessons vs quizzes completed, and a
// 30-day activity trend line.
const ProgressCharts = () => {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    getProgressCharts()
      .then((res) => !cancelled && setData(res))
      .catch(() => {})
      .finally(() => !cancelled && setLoading(false));
    return () => {
      cancelled = true;
    };
  }, []);

  if (loading) return <Loader label="Loading charts..." />;
  if (!data) return null;

  return (
    <div style={styles.wrapper}>
      <div style={styles.chartBlock}>
        <h4 style={styles.heading}>Course Completion (%)</h4>
        <ResponsiveContainer width="100%" height={260}>
          <BarChart data={data.courseCompletion}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="courseTitle" tick={{ fontSize: 11 }} />
            <YAxis domain={[0, 100]} />
            <Tooltip />
            <Bar dataKey="completionPercentage" fill="#4f46e5" radius={[6, 6, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>

      <div style={styles.chartBlock}>
        <h4 style={styles.heading}>Lessons vs Quizzes Completed</h4>
        <ResponsiveContainer width="100%" height={260}>
          <BarChart data={data.lessonVsQuiz}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="courseTitle" tick={{ fontSize: 11 }} />
            <YAxis />
            <Tooltip />
            <Legend />
            <Bar dataKey="lessonsCompleted" name="Lessons completed" fill="#4f46e5" radius={[6, 6, 0, 0]} />
            <Bar dataKey="quizzesPassed" name="Quizzes passed" fill="#16a34a" radius={[6, 6, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>

      <div style={styles.chartBlock}>
        <h4 style={styles.heading}>Activity Trend (last 30 days)</h4>
        <ResponsiveContainer width="100%" height={220}>
          <LineChart data={data.activityTrend}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="date" tick={{ fontSize: 10 }} />
            <YAxis allowDecimals={false} />
            <Tooltip />
            <Line type="monotone" dataKey="count" stroke="#4f46e5" strokeWidth={2} dot={false} />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

const styles = {
  wrapper: { display: "flex", flexDirection: "column", gap: 24 },
  chartBlock: { background: "#fff", border: "1px solid #e5e7eb", borderRadius: 12, padding: 16 },
  heading: { margin: "0 0 10px 0", fontSize: 15 },
};

export default ProgressCharts;
