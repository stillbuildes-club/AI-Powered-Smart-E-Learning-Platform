import React from "react";
import ProgressBar from "../common/ProgressBar";

// Shows a single enrolled course's completion percentage.
const CourseCompletionCard = ({ progress }) => {
  const { course, completionPercentage, status } = progress;

  const statusColor =
    status === "completed" ? "#16a34a" : status === "in_progress" ? "#4f46e5" : "#9ca3af";

  return (
    <div style={styles.card}>
      <div style={styles.headerRow}>
        <h4 style={styles.title}>{course?.title || "Untitled course"}</h4>
        <span style={{ ...styles.badge, backgroundColor: statusColor }}>
          {status.replace("_", " ")}
        </span>
      </div>
      <ProgressBar percentage={completionPercentage} color={statusColor} />
      <div style={styles.footerRow}>
        <span>{completionPercentage}% complete</span>
      </div>
    </div>
  );
};

const styles = {
  card: {
    background: "#fff",
    border: "1px solid #e5e7eb",
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
  },
  headerRow: { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 },
  title: { margin: 0, fontSize: 15, color: "#111827" },
  badge: {
    color: "#fff",
    fontSize: 11,
    padding: "3px 10px",
    borderRadius: 999,
    textTransform: "capitalize",
  },
  footerRow: { marginTop: 6, fontSize: 12, color: "#6b7280" },
};

export default CourseCompletionCard;
