import React from "react";

// Lists every quiz in a course with attempts, best score, and pass/fail state.
const QuizProgressList = ({ quizzesProgress = [] }) => (
  <div style={styles.wrapper}>
    <h4 style={styles.heading}>Quiz Progress</h4>
    {quizzesProgress.length === 0 && <p style={styles.empty}>No quizzes yet.</p>}
    <ul style={styles.list}>
      {quizzesProgress.map((entry) => (
        <li key={entry.quiz?._id || entry.quiz} style={styles.item}>
          <div>
            <div style={styles.quizTitle}>{entry.quiz?.title || "Quiz"}</div>
            <div style={styles.meta}>
              {entry.attempts} attempt{entry.attempts !== 1 ? "s" : ""} · best score {entry.bestScore}%
            </div>
          </div>
          <span style={{ color: entry.passed ? "#16a34a" : "#dc2626", fontSize: 12, fontWeight: 600 }}>
            {entry.passed ? "Passed" : "Not passed"}
          </span>
        </li>
      ))}
    </ul>
  </div>
);

const styles = {
  wrapper: { background: "#fff", border: "1px solid #e5e7eb", borderRadius: 12, padding: 16 },
  heading: { margin: "0 0 10px 0", fontSize: 15 },
  empty: { fontSize: 13, color: "#9ca3af" },
  list: { listStyle: "none", margin: 0, padding: 0 },
  item: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    padding: "8px 0",
    borderBottom: "1px solid #f3f4f6",
    fontSize: 13,
  },
  quizTitle: { fontWeight: 500 },
  meta: { color: "#6b7280", fontSize: 12 },
};

export default QuizProgressList;
