import React from "react";

const statusStyles = {
  completed: { color: "#16a34a", label: "✓ Completed" },
  in_progress: { color: "#4f46e5", label: "In progress" },
  not_started: { color: "#9ca3af", label: "Not started" },
};

// Lists every lesson in a course alongside its individual progress status.
const LessonProgressList = ({ lessonsProgress = [] }) => (
  <div style={styles.wrapper}>
    <h4 style={styles.heading}>Lesson Progress</h4>
    {lessonsProgress.length === 0 && <p style={styles.empty}>No lessons yet.</p>}
    <ul style={styles.list}>
      {lessonsProgress.map((entry) => {
        const s = statusStyles[entry.status] || statusStyles.not_started;
        return (
          <li key={entry.lesson?._id || entry.lesson} style={styles.item}>
            <span>{entry.lesson?.title || "Lesson"}</span>
            <span style={{ color: s.color, fontSize: 12, fontWeight: 600 }}>{s.label}</span>
          </li>
        );
      })}
    </ul>
  </div>
);

const styles = {
  wrapper: { background: "#fff", border: "1px solid #e5e7eb", borderRadius: 12, padding: 16 },
  heading: { margin: "0 0 10px 0", fontSize: 15 },
  empty: { fontSize: 13, color: "#9ca3af" },
  list: { listStyle: "none", margin: 0, padding: 0 },
  item: {
    display: "flex",
    justifyContent: "space-between",
    padding: "8px 0",
    borderBottom: "1px solid #f3f4f6",
    fontSize: 13,
  },
};

export default LessonProgressList;
