import React, { useEffect, useState } from "react";
import { getMilestones } from "../../services/progressService";
import Loader from "../common/Loader";

const iconMap = {
  star: "⭐",
  medal: "🥈",
  flag: "🚩",
  trophy: "🏆",
  brain: "🧠",
};

// Displays every milestone/achievement the student has unlocked.
const MilestoneTracker = ({ courseId }) => {
  const [milestones, setMilestones] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    getMilestones(courseId)
      .then((data) => !cancelled && setMilestones(data))
      .catch(() => {})
      .finally(() => !cancelled && setLoading(false));
    return () => {
      cancelled = true;
    };
  }, [courseId]);

  if (loading) return <Loader label="Loading milestones..." />;

  return (
    <div style={styles.wrapper}>
      <h4 style={styles.heading}>Milestones</h4>
      {milestones.length === 0 && <p style={styles.empty}>No milestones unlocked yet — keep going!</p>}
      <div style={styles.grid}>
        {milestones.map((m) => (
          <div key={m._id} style={styles.badge}>
            <div style={styles.badgeIcon}>{iconMap[m.icon] || "🏅"}</div>
            <div style={styles.badgeTitle}>{m.title}</div>
            <div style={styles.badgeMeta}>
              {m.course?.title ? `${m.course.title} · ` : ""}
              {new Date(m.achievedAt).toLocaleDateString()}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

const styles = {
  wrapper: { background: "#fff", border: "1px solid #e5e7eb", borderRadius: 12, padding: 16 },
  heading: { margin: "0 0 10px 0", fontSize: 15 },
  empty: { fontSize: 13, color: "#9ca3af" },
  grid: { display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(120px, 1fr))", gap: 12 },
  badge: {
    textAlign: "center",
    border: "1px solid #f3f4f6",
    borderRadius: 10,
    padding: 12,
  },
  badgeIcon: { fontSize: 28 },
  badgeTitle: { fontSize: 12, fontWeight: 600, marginTop: 4 },
  badgeMeta: { fontSize: 10, color: "#9ca3af", marginTop: 2 },
};

export default MilestoneTracker;
