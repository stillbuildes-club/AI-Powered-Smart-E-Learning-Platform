import React, { useEffect, useState } from "react";
import { getConversations, startConversation } from "../../services/chatService";
import { getCourseById } from "../../services/courseService";
import { useAuth } from "../../context/AuthContext";
import CourseSelector from "../common/CourseSelector";
import ChatSidebar from "./ChatSidebar";
import ChatWindow from "./ChatWindow";
import Loader from "../common/Loader";

// Week 6: top-level Chat screen — Real-time Chat between Students and
// Instructors. Students can start a new conversation with the instructor
// of a chosen course; both sides can continue any existing conversation
// from the sidebar.
const ChatPage = () => {
  const { user } = useAuth();
  const [conversations, setConversations] = useState([]);
  const [active, setActive] = useState(null);
  const [loading, setLoading] = useState(true);
  const [courseId, setCourseId] = useState(null);
  const [starting, setStarting] = useState(false);

  const loadConversations = () => {
    setLoading(true);
    getConversations()
      .then((data) => {
        setConversations(data);
        if (!active && data.length > 0) setActive(data[0]);
      })
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    loadConversations();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleMessageInstructor = async () => {
    if (!courseId) return;
    setStarting(true);
    try {
      const course = await getCourseById(courseId);
      if (!course.instructor) {
        alert("This course has no instructor assigned yet.");
        return;
      }
      const conv = await startConversation(course.instructor._id, courseId);
      setConversations((prev) => {
        const exists = prev.some((c) => c._id === conv._id);
        return exists ? prev : [conv, ...prev];
      });
      setActive(conv);
    } finally {
      setStarting(false);
    }
  };

  return (
    <div style={styles.page}>
      <h2 style={styles.pageTitle}>Chat</h2>

      {user?.role === "student" && (
        <div style={styles.starterRow}>
          <CourseSelector value={courseId} onChange={setCourseId} />
          <button onClick={handleMessageInstructor} disabled={starting || !courseId} style={styles.starterBtn}>
            {starting ? "Starting..." : "Message Instructor"}
          </button>
        </div>
      )}

      <div className="chat-shell" style={styles.chatShell}>
        {loading ? (
          <Loader label="Loading conversations..." />
        ) : (
          <>
            <ChatSidebar
              conversations={conversations}
              activeId={active?._id}
              onSelect={setActive}
              currentUserId={user?._id}
            />
            {active ? (
              <ChatWindow conversation={active} currentUserId={user?._id} />
            ) : (
              <div style={styles.placeholder}>Select or start a conversation.</div>
            )}
          </>
        )}
      </div>
    </div>
  );
};

const styles = {
  page: { maxWidth: 1100, margin: "0 auto", padding: 24, fontFamily: "Inter, system-ui, sans-serif" },
  pageTitle: { fontSize: 22, marginBottom: 16, color: "#111827" },
  starterRow: { display: "flex", gap: 10, marginBottom: 16, flexWrap: "wrap" },
  starterBtn: { padding: "8px 16px", borderRadius: 8, border: "none", background: "#4f46e5", color: "#fff", fontWeight: 600 },
  chatShell: {
    display: "flex",
    height: "60vh",
    minHeight: 420,
    border: "1px solid #e5e7eb",
    borderRadius: 12,
    overflow: "hidden",
    background: "#fff",
  },
  placeholder: { flex: 1, display: "flex", alignItems: "center", justifyContent: "center", color: "#6b7280" },
};

export default ChatPage;
