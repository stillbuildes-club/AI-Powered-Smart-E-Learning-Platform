import React from "react";

// Week 6: list of the current user's chat conversations.
const ChatSidebar = ({ conversations, activeId, onSelect, currentUserId }) => {
  const otherParticipant = (conv) => conv.participants.find((p) => p._id !== currentUserId);

  return (
    <div style={styles.sidebar}>
      <h3 style={styles.title}>Conversations</h3>
      {conversations.length === 0 && <p style={styles.empty}>No conversations yet.</p>}
      {conversations.map((conv) => {
        const other = otherParticipant(conv);
        return (
          <div
            key={conv._id}
            onClick={() => onSelect(conv)}
            style={{ ...styles.item, ...(activeId === conv._id ? styles.itemActive : {}) }}
          >
            <div style={styles.avatar}>{other?.name?.[0]?.toUpperCase() || "?"}</div>
            <div style={{ overflow: "hidden" }}>
              <div style={styles.name}>{other?.name || "Unknown user"}</div>
              <div style={styles.preview}>{conv.lastMessage?.text || "No messages yet"}</div>
            </div>
          </div>
        );
      })}
    </div>
  );
};

const styles = {
  sidebar: { width: 260, borderRight: "1px solid #e5e7eb", background: "#fff", overflowY: "auto" },
  title: { fontSize: 14, padding: "14px 16px 8px", color: "#111827" },
  empty: { fontSize: 13, color: "#6b7280", padding: "0 16px" },
  item: { display: "flex", gap: 10, padding: "10px 16px", cursor: "pointer", alignItems: "center" },
  itemActive: { background: "#eef2ff" },
  avatar: {
    width: 36,
    height: 36,
    borderRadius: "50%",
    background: "#4f46e5",
    color: "#fff",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    fontWeight: 600,
    flexShrink: 0,
  },
  name: { fontSize: 14, fontWeight: 600, color: "#111827" },
  preview: { fontSize: 12, color: "#6b7280", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" },
};

export default ChatSidebar;
