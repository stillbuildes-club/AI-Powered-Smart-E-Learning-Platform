import React, { useEffect, useRef, useState } from "react";
import { getMessages, sendMessageRest, markConversationRead } from "../../services/chatService";
import { connectSocket } from "../../services/socket";
import Loader from "../common/Loader";

// Week 6: message thread + composer for one conversation. Joins the
// conversation's Socket.IO room for instant delivery; falls back to a
// REST POST if the socket isn't connected.
const ChatWindow = ({ conversation, currentUserId }) => {
  const [messages, setMessages] = useState([]);
  const [text, setText] = useState("");
  const [loading, setLoading] = useState(true);
  const [typingUser, setTypingUser] = useState(null);
  const bottomRef = useRef(null);
  const typingTimeout = useRef(null);

  const other = conversation.participants.find((p) => p._id !== currentUserId);

  useEffect(() => {
    setLoading(true);
    getMessages(conversation._id)
      .then(setMessages)
      .finally(() => setLoading(false));
    markConversationRead(conversation._id).catch(() => {});

    const socket = connectSocket();
    if (socket) {
      socket.emit("chat:join", conversation._id);

      const onMessage = (msg) => {
        if (msg.conversation === conversation._id) setMessages((prev) => [...prev, msg]);
      };
      const onTyping = ({ conversationId, userId, isTyping }) => {
        if (conversationId === conversation._id && userId !== currentUserId) {
          setTypingUser(isTyping ? other?.name || "Someone" : null);
        }
      };

      socket.on("chat:message", onMessage);
      socket.on("chat:typing", onTyping);

      return () => {
        socket.emit("chat:leave", conversation._id);
        socket.off("chat:message", onMessage);
        socket.off("chat:typing", onTyping);
      };
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [conversation._id]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSend = async (e) => {
    e.preventDefault();
    const value = text.trim();
    if (!value) return;
    setText("");

    const socket = connectSocket();
    if (socket && socket.connected) {
      socket.emit("chat:message", { conversationId: conversation._id, text: value }, (ack) => {
        if (ack?.success) setMessages((prev) => [...prev, ack.data]);
      });
    } else {
      const saved = await sendMessageRest(conversation._id, value);
      setMessages((prev) => [...prev, saved]);
    }
  };

  const handleTyping = (isTyping) => {
    const socket = connectSocket();
    if (!socket) return;
    socket.emit("chat:typing", { conversationId: conversation._id, isTyping });
    if (isTyping) {
      clearTimeout(typingTimeout.current);
      typingTimeout.current = setTimeout(() => socket.emit("chat:typing", { conversationId: conversation._id, isTyping: false }), 2000);
    }
  };

  if (loading) return <Loader label="Loading messages..." />;

  return (
    <div style={styles.window}>
      <div style={styles.header}>
        <strong>{other?.name || "Conversation"}</strong>
        <span style={styles.roleTag}>{other?.role}</span>
      </div>

      <div style={styles.messages}>
        {messages.map((m) => {
          const mine = (m.sender?._id || m.sender) === currentUserId;
          return (
            <div key={m._id} style={{ ...styles.bubbleRow, justifyContent: mine ? "flex-end" : "flex-start" }}>
              <div style={{ ...styles.bubble, ...(mine ? styles.bubbleMine : styles.bubbleTheirs) }}>{m.text}</div>
            </div>
          );
        })}
        <div ref={bottomRef} />
      </div>

      {typingUser && <div style={styles.typing}>{typingUser} is typing…</div>}

      <form onSubmit={handleSend} style={styles.composer}>
        <input
          value={text}
          onChange={(e) => {
            setText(e.target.value);
            handleTyping(true);
          }}
          onBlur={() => handleTyping(false)}
          placeholder="Type a message..."
          style={styles.input}
        />
        <button type="submit" style={styles.sendBtn}>
          Send
        </button>
      </form>
    </div>
  );
};

const styles = {
  window: { flex: 1, display: "flex", flexDirection: "column", background: "#f9fafb" },
  header: { padding: "12px 16px", borderBottom: "1px solid #e5e7eb", background: "#fff", display: "flex", gap: 8, alignItems: "center" },
  roleTag: { fontSize: 11, color: "#6b7280", textTransform: "capitalize", background: "#f3f4f6", padding: "2px 8px", borderRadius: 999 },
  messages: { flex: 1, overflowY: "auto", padding: 16, display: "flex", flexDirection: "column", gap: 8 },
  bubbleRow: { display: "flex" },
  bubble: { maxWidth: "70%", padding: "8px 12px", borderRadius: 14, fontSize: 14, lineHeight: 1.4 },
  bubbleMine: { background: "#4f46e5", color: "#fff", borderBottomRightRadius: 4 },
  bubbleTheirs: { background: "#fff", color: "#111827", border: "1px solid #e5e7eb", borderBottomLeftRadius: 4 },
  typing: { fontSize: 12, color: "#6b7280", padding: "0 16px 4px" },
  composer: { display: "flex", gap: 8, padding: 12, borderTop: "1px solid #e5e7eb", background: "#fff" },
  input: { flex: 1, padding: "10px 12px", borderRadius: 8, border: "1px solid #e5e7eb", fontSize: 14 },
  sendBtn: { padding: "10px 18px", borderRadius: 8, border: "none", background: "#4f46e5", color: "#fff", fontWeight: 600 },
};

export default ChatWindow;
