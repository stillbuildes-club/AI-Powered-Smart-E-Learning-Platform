import React, { useEffect, useState } from "react";
import { getQuizzesForCourse } from "../../services/quizService";
import Loader from "../common/Loader";

// Week 6: lists quizzes available for a course; click one to take it.
const QuizList = ({ courseId, onSelectQuiz }) => {
  const [quizzes, setQuizzes] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!courseId) return;
    setLoading(true);
    getQuizzesForCourse(courseId)
      .then(setQuizzes)
      .finally(() => setLoading(false));
  }, [courseId]);

  if (loading) return <Loader label="Loading quizzes..." />;
  if (quizzes.length === 0) return <p style={{ color: "#6b7280" }}>No quizzes available for this course yet.</p>;

  return (
    <div style={styles.grid}>
      {quizzes.map((q) => (
        <div key={q._id} style={styles.card} onClick={() => onSelectQuiz(q._id)}>
          <div style={styles.cardTitle}>{q.title}</div>
          <div style={styles.cardMeta}>
            {q.questionCount} questions · Pass at {q.passingScore}%
          </div>
        </div>
      ))}
    </div>
  );
};

const styles = {
  grid: { display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(220px, 1fr))", gap: 12 },
  card: { background: "#fff", border: "1px solid #e5e7eb", borderRadius: 10, padding: 14, cursor: "pointer" },
  cardTitle: { fontSize: 15, fontWeight: 600, color: "#111827" },
  cardMeta: { fontSize: 12, color: "#6b7280", marginTop: 6 },
};

export default QuizList;
