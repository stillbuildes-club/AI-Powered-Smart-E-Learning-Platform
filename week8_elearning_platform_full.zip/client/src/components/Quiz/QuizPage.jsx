import React, { useState } from "react";
import CourseSelector from "../common/CourseSelector";
import QuizList from "./QuizList";
import QuizTaker from "./QuizTaker";

// Week 6: top-level Quiz screen combining the course picker, quiz list,
// and the interactive quiz taker.
const QuizPage = () => {
  const [courseId, setCourseId] = useState(null);
  const [activeQuizId, setActiveQuizId] = useState(null);

  return (
    <div style={styles.page}>
      <h2 style={styles.pageTitle}>Quizzes</h2>

      {!activeQuizId && (
        <div style={styles.topRow}>
          <CourseSelector value={courseId} onChange={setCourseId} />
        </div>
      )}

      {activeQuizId ? (
        <QuizTaker quizId={activeQuizId} onBack={() => setActiveQuizId(null)} />
      ) : (
        <QuizList courseId={courseId} onSelectQuiz={setActiveQuizId} />
      )}
    </div>
  );
};

const styles = {
  page: { maxWidth: 900, margin: "0 auto", padding: 24, fontFamily: "Inter, system-ui, sans-serif" },
  pageTitle: { fontSize: 22, marginBottom: 16, color: "#111827" },
  topRow: { marginBottom: 16 },
};

export default QuizPage;
