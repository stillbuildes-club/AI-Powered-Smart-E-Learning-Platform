import React, { useEffect, useState } from "react";
import { getQuizForTaking, submitQuiz } from "../../services/quizService";
import Loader from "../common/Loader";

// Week 6: Interactive Quiz System — renders questions, collects answers,
// submits for auto-grading, and shows the result (score + which were right).
const QuizTaker = ({ quizId, onBack }) => {
  const [quiz, setQuiz] = useState(null);
  const [answers, setAnswers] = useState({}); // { questionId: selectedOptionIndex }
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [result, setResult] = useState(null);

  useEffect(() => {
    getQuizForTaking(quizId)
      .then(setQuiz)
      .finally(() => setLoading(false));
  }, [quizId]);

  const handleSelect = (questionId, optionIndex) => {
    setAnswers((prev) => ({ ...prev, [questionId]: optionIndex }));
  };

  const handleSubmit = async () => {
    setSubmitting(true);
    try {
      const payload = Object.entries(answers).map(([questionId, selectedOptionIndex]) => ({
        questionId,
        selectedOptionIndex,
      }));
      const data = await submitQuiz(quizId, payload);
      setResult(data);
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) return <Loader label="Loading quiz..." />;
  if (!quiz) return null;

  if (result) {
    return (
      <div style={styles.resultCard}>
        <h3 style={{ color: result.passed ? "#16a34a" : "#dc2626" }}>
          {result.passed ? "You passed! 🎉" : "Not quite — try again"}
        </h3>
        <p style={styles.resultScore}>
          Score: <strong>{result.score}%</strong> ({result.correctCount}/{result.totalQuestions} correct)
        </p>
        <button onClick={onBack} style={styles.backBtn}>
          Back to quizzes
        </button>
      </div>
    );
  }

  const answeredCount = Object.keys(answers).length;

  return (
    <div>
      <button onClick={onBack} style={styles.backLink}>
        ← Back to quizzes
      </button>
      <h3 style={styles.title}>{quiz.title}</h3>
      <p style={styles.subtitle}>
        Passing score: {quiz.passingScore}% · {quiz.questions.length} questions
      </p>

      {quiz.questions.map((q, idx) => (
        <div key={q._id} style={styles.questionCard}>
          <div style={styles.questionText}>
            {idx + 1}. {q.questionText}
          </div>
          {q.options.map((opt, optIdx) => (
            <label key={optIdx} style={styles.optionLabel}>
              <input
                type="radio"
                name={q._id}
                checked={answers[q._id] === optIdx}
                onChange={() => handleSelect(q._id, optIdx)}
              />
              <span>{opt}</span>
            </label>
          ))}
        </div>
      ))}

      <button
        onClick={handleSubmit}
        disabled={submitting || answeredCount === 0}
        style={styles.submitBtn}
      >
        {submitting ? "Submitting..." : `Submit Quiz (${answeredCount}/${quiz.questions.length} answered)`}
      </button>
    </div>
  );
};

const styles = {
  backLink: { background: "none", border: "none", color: "#4f46e5", cursor: "pointer", marginBottom: 12, fontSize: 14, padding: 0 },
  title: { fontSize: 18, color: "#111827", marginBottom: 4 },
  subtitle: { fontSize: 13, color: "#6b7280", marginBottom: 16 },
  questionCard: { background: "#fff", border: "1px solid #e5e7eb", borderRadius: 10, padding: 14, marginBottom: 12 },
  questionText: { fontSize: 14, fontWeight: 600, color: "#111827", marginBottom: 8 },
  optionLabel: { display: "flex", alignItems: "center", gap: 8, fontSize: 14, color: "#374151", padding: "6px 0", cursor: "pointer" },
  submitBtn: { padding: "10px 20px", borderRadius: 8, border: "none", background: "#4f46e5", color: "#fff", fontWeight: 600, width: "100%" },
  resultCard: { background: "#fff", border: "1px solid #e5e7eb", borderRadius: 12, padding: 24, textAlign: "center" },
  resultScore: { fontSize: 16, margin: "10px 0 18px", color: "#111827" },
  backBtn: { padding: "8px 16px", borderRadius: 8, border: "1px solid #e5e7eb", background: "#f9fafb" },
};

export default QuizTaker;
