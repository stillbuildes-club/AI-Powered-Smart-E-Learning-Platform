import React, { useEffect, useMemo, useState } from "react";
import RecommendedCourseCard from "./RecommendedCourseCard";
import CategoryFilter from "./CategoryFilter";
import Loader from "../common/Loader";
import {
  getSmartRecommendations,
  getInterestRecommendations,
  getCompletedRecommendations,
  getEnrolledRecommendations,
  getHistoryRecommendations,
} from "../../services/recommendationService";

// Week 5: main recommendations screen. Tabs switch between the different
// recommendation signals; the category dropdown filters whichever tab is active.
const TABS = [
  { key: "smart", label: "For You", fetcher: getSmartRecommendations },
  { key: "interests", label: "Based on Interests", fetcher: getInterestRecommendations },
  { key: "completed", label: "Based on Completed Courses", fetcher: getCompletedRecommendations },
  { key: "enrolled", label: "Based on Enrolled Courses", fetcher: getEnrolledRecommendations },
  { key: "history", label: "Based on Learning History", fetcher: getHistoryRecommendations },
];

const RecommendedCourses = () => {
  const [activeTab, setActiveTab] = useState("smart");
  const [category, setCategory] = useState(null);
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [knownCategories, setKnownCategories] = useState([]);

  const activeFetcher = useMemo(() => TABS.find((t) => t.key === activeTab).fetcher, [activeTab]);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError(null);

    activeFetcher({ category, limit: 12 })
      .then((res) => {
        if (cancelled) return;
        setResults(res.data);
        // Build up the category filter's option list from whatever courses
        // we've seen so far (only need to do this once, on the unfiltered load).
        if (!category) {
          setKnownCategories((prev) => {
            const set = new Set(prev);
            res.data.forEach((r) => r.course?.category && set.add(r.course.category));
            return Array.from(set);
          });
        }
      })
      .catch((err) => !cancelled && setError(err.message))
      .finally(() => !cancelled && setLoading(false));

    return () => {
      cancelled = true;
    };
  }, [activeFetcher, category]);

  return (
    <div style={styles.wrapper}>
      <div style={styles.headerRow}>
        <h3 style={styles.heading}>Recommended For You</h3>
        <CategoryFilter categories={knownCategories} value={category} onChange={setCategory} />
      </div>

      <div style={styles.tabRow}>
        {TABS.map((tab) => (
          <button
            key={tab.key}
            onClick={() => setActiveTab(tab.key)}
            style={{
              ...styles.tabButton,
              ...(activeTab === tab.key ? styles.tabButtonActive : {}),
            }}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {loading && <Loader label="Finding courses for you..." />}
      {error && <p style={{ color: "#dc2626" }}>Failed to load recommendations: {error}</p>}
      {!loading && !error && results.length === 0 && (
        <p style={styles.empty}>
          No recommendations yet for this view. Try a different tab or update your interests.
        </p>
      )}

      <div style={styles.grid}>
        {results.map((item) => (
          <RecommendedCourseCard key={item.course._id} item={item} />
        ))}
      </div>
    </div>
  );
};

const styles = {
  wrapper: { maxWidth: 1100, margin: "0 auto", padding: "0 24px 24px 24px" },
  headerRow: { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 },
  heading: { fontSize: 18, margin: 0, color: "#111827" },
  tabRow: { display: "flex", flexWrap: "wrap", gap: 8, marginBottom: 16 },
  tabButton: {
    border: "1px solid #e5e7eb",
    background: "#fff",
    borderRadius: 999,
    padding: "6px 14px",
    fontSize: 12,
    color: "#374151",
  },
  tabButtonActive: { background: "#4f46e5", color: "#fff", borderColor: "#4f46e5" },
  grid: { display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: 14 },
  empty: { fontSize: 13, color: "#9ca3af" },
};

export default RecommendedCourses;
