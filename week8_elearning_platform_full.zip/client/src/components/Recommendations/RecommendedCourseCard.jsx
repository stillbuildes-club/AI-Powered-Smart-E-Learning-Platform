import React from "react";

// Single recommended course card. Shows the course, its category, and —
// when available — a lightweight "why this was recommended" score badge.
const RecommendedCourseCard = ({ item }) => {
  const { course, score, breakdown } = item;

  return (
    <div style={styles.card}>
      <div style={styles.thumbnailWrap}>
        {course.thumbnail ? (
          <img src={course.thumbnail} alt={course.title} style={styles.thumbnail} />
        ) : (
          <div style={styles.thumbnailPlaceholder}>{course.title?.[0] || "?"}</div>
        )}
      </div>
      <div style={styles.body}>
        <div style={styles.categoryTag}>{course.category}</div>
        <h4 style={styles.title}>{course.title}</h4>
        {course.description && <p style={styles.description}>{course.description}</p>}
        <div style={styles.footerRow}>
          <span style={styles.scoreBadge}>Match {Math.round(score)}%</span>
          {course.tags && course.tags.length > 0 && (
            <span style={styles.tags}>{course.tags.slice(0, 3).join(", ")}</span>
          )}
        </div>
        {breakdown && (
          <div style={styles.breakdown} title="How this score was calculated">
            interest {breakdown.interestScore} · completed {breakdown.completedScore} · enrolled{" "}
            {breakdown.enrolledScore} · history {breakdown.historyScore} · popularity{" "}
            {breakdown.popularityScore}
          </div>
        )}
      </div>
    </div>
  );
};

const styles = {
  card: {
    display: "flex",
    gap: 12,
    background: "#fff",
    border: "1px solid #e5e7eb",
    borderRadius: 12,
    padding: 14,
  },
  thumbnailWrap: { flexShrink: 0 },
  thumbnail: { width: 64, height: 64, borderRadius: 10, objectFit: "cover" },
  thumbnailPlaceholder: {
    width: 64,
    height: 64,
    borderRadius: 10,
    background: "#eef2ff",
    color: "#4f46e5",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    fontWeight: 700,
    fontSize: 22,
  },
  body: { flex: 1, minWidth: 0 },
  categoryTag: { fontSize: 11, color: "#4f46e5", fontWeight: 600, textTransform: "uppercase" },
  title: { margin: "2px 0 4px 0", fontSize: 15, color: "#111827" },
  description: {
    margin: 0,
    fontSize: 12,
    color: "#6b7280",
    overflow: "hidden",
    textOverflow: "ellipsis",
    display: "-webkit-box",
    WebkitLineClamp: 2,
    WebkitBoxOrient: "vertical",
  },
  footerRow: { display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 8 },
  scoreBadge: {
    fontSize: 11,
    fontWeight: 600,
    color: "#16a34a",
    background: "#f0fdf4",
    padding: "2px 8px",
    borderRadius: 999,
  },
  tags: { fontSize: 11, color: "#9ca3af" },
  breakdown: { marginTop: 6, fontSize: 10, color: "#c1c5cc" },
};

export default RecommendedCourseCard;
