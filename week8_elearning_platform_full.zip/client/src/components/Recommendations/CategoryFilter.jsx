import React from "react";

// Simple category dropdown filter shared across all recommendation tabs.
const CategoryFilter = ({ categories, value, onChange }) => (
  <select value={value || ""} onChange={(e) => onChange(e.target.value || null)} style={styles.select}>
    <option value="">All categories</option>
    {categories.map((c) => (
      <option key={c} value={c}>
        {c}
      </option>
    ))}
  </select>
);

const styles = {
  select: {
    padding: "6px 10px",
    borderRadius: 8,
    border: "1px solid #d1d5db",
    fontSize: 13,
    background: "#fff",
  },
};

export default CategoryFilter;
