import React from "react";

// Week 7: catches render-time errors in any subtree it wraps so one broken
// component (e.g. a bad API response shape) shows a recoverable message
// instead of blanking the whole app — and logs the stack for debugging.
class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, info) {
    // eslint-disable-next-line no-console
    console.error("[ErrorBoundary] caught:", error, info?.componentStack);
  }

  handleReset = () => {
    this.setState({ hasError: false, error: null });
  };

  render() {
    if (this.state.hasError) {
      return (
        <div style={styles.wrapper}>
          <h3 style={styles.title}>Something went wrong</h3>
          <p style={styles.message}>
            {this.props.fallbackMessage || "This section failed to load. You can try again below."}
          </p>
          <button style={styles.button} onClick={this.handleReset}>
            Try again
          </button>
        </div>
      );
    }

    return this.props.children;
  }
}

const styles = {
  wrapper: {
    padding: 24,
    margin: 16,
    borderRadius: 8,
    border: "1px solid #fecaca",
    background: "#fef2f2",
    textAlign: "center",
  },
  title: { color: "#b91c1c", margin: "0 0 8px" },
  message: { color: "#7f1d1d", margin: "0 0 16px" },
  button: {
    padding: "8px 16px",
    borderRadius: 8,
    border: "none",
    background: "#4f46e5",
    color: "#fff",
    fontWeight: 600,
    cursor: "pointer",
  },
};

export default ErrorBoundary;
