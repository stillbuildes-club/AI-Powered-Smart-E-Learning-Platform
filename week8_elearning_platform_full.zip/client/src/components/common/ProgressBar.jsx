import React from "react";

// Reusable horizontal progress bar. `percentage` should be 0-100.
const ProgressBar = ({ percentage = 0, height = 10, color = "#4f46e5" }) => {
  const clamped = Math.min(100, Math.max(0, percentage));
  return (
    <div style={{ ...styles.track, height }}>
      <div
        style={{
          ...styles.fill,
          width: `${clamped}%`,
          backgroundColor: color,
        }}
      />
    </div>
  );
};

const styles = {
  track: {
    width: "100%",
    backgroundColor: "#e5e7eb",
    borderRadius: 999,
    overflow: "hidden",
  },
  fill: {
    height: "100%",
    borderRadius: 999,
    transition: "width 0.4s ease",
  },
};

export default ProgressBar;
