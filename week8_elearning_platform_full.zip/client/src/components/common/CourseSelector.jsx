import React, { useEffect, useState } from "react";
import { getCourses } from "../../services/courseService";

// Week 6: shared course dropdown used by Forum, Quiz, and Assignment tabs
// so a student/instructor can pick which course's content to view.
const CourseSelector = ({ value, onChange }) => {
  const [courses, setCourses] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getCourses()
      .then((data) => {
        setCourses(data);
        if (!value && data.length > 0) onChange(data[0]._id);
      })
      .finally(() => setLoading(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (loading) return <p style={{ color: "#6b7280", fontSize: 14 }}>Loading courses...</p>;
  if (courses.length === 0) return <p style={{ color: "#6b7280", fontSize: 14 }}>No courses available yet.</p>;

  return (
    <select value={value || ""} onChange={(e) => onChange(e.target.value)} style={styles.select}>
      {courses.map((c) => (
        <option key={c._id} value={c._id}>
          {c.title}
        </option>
      ))}
    </select>
  );
};

const styles = {
  select: {
    padding: "8px 12px",
    borderRadius: 8,
    border: "1px solid #e5e7eb",
    fontSize: 14,
    background: "#fff",
    minWidth: 220,
  },
};

export default CourseSelector;
