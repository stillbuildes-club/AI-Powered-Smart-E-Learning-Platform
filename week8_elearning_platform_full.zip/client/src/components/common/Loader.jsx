import React from "react";

// Small, dependency-free loading spinner used across the dashboard.
const Loader = ({ label = "Loading..." }) => (
  <div style={styles.wrapper}>
    <div style={styles.spinner} />
    <span style={styles.label}>{label}</span>
  </div>
);

const styles = {
  wrapper: { display: "flex", alignItems: "center", gap: "10px", padding: "20px" },
  spinner: {
    width: 20,
    height: 20,
    border: "3px solid #e0e0e0",
    borderTop: "3px solid #4f46e5",
    borderRadius: "50%",
    animation: "spin 0.8s linear infinite",
  },
  label: { color: "#555", fontSize: 14 },
};

export default Loader;
