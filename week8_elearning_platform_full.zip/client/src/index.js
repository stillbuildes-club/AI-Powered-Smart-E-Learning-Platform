import React from "react";
import ReactDOM from "react-dom/client";
import "./index.css";
import App from "./App";
import ErrorBoundary from "./components/common/ErrorBoundary";

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(
  <React.StrictMode>
    {/* Week 7: top-level safety net in addition to App.jsx's per-tab
        boundaries, in case an error occurs outside the tab content
        (the top bar, notification bell, etc.). */}
    <ErrorBoundary fallbackMessage="The app hit an unexpected error. Please refresh the page.">
      <App />
    </ErrorBoundary>
  </React.StrictMode>
);
