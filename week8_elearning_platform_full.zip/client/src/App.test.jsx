import React from "react";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import App from "./App";

// Week 7: smoke tests for the tab switcher + code-splitting added this week.
// The heavier feature components (Dashboard/Chat/Forum/etc.) make real API
// calls on mount, so they're mocked here — this test is about App.jsx's own
// behavior (tab switching, lazy loading, error isolation), not their internals.
jest.mock("./components/Dashboard/ProgressDashboard", () => () => <div>Dashboard content</div>);
jest.mock("./components/Recommendations/RecommendedCourses", () => () => <div>Recommendations content</div>);
jest.mock("./components/Chat/ChatPage", () => () => <div>Chat content</div>);
jest.mock("./components/Forum/ForumPage", () => () => <div>Forum content</div>);
jest.mock("./components/Quiz/QuizPage", () => () => <div>Quiz content</div>);
jest.mock("./components/Assignments/AssignmentPage", () => () => <div>Assignments content</div>);
jest.mock("./components/Notifications/NotificationBell", () => () => <div>bell</div>);

describe("App tab switcher", () => {
  it("renders the Dashboard tab by default", async () => {
    render(<App />);
    expect(await screen.findByText("Dashboard content")).toBeInTheDocument();
  });

  it("switches to the Forum tab when clicked", async () => {
    render(<App />);
    await screen.findByText("Dashboard content");

    fireEvent.click(screen.getByRole("button", { name: "Forum" }));

    await waitFor(() => expect(screen.getByText("Forum content")).toBeInTheDocument());
    expect(screen.queryByText("Dashboard content")).not.toBeInTheDocument();
  });

  it("renders all six tab buttons", () => {
    render(<App />);
    ["Dashboard", "Recommendations", "Chat", "Forum", "Quizzes", "Assignments"].forEach((label) => {
      expect(screen.getByRole("button", { name: label })).toBeInTheDocument();
    });
  });
});
