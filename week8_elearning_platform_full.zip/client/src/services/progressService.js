import api from "./api";

// Thin wrapper functions around the Week 4 progress-tracking endpoints.
export const getDashboard = () => api.get("/progress/dashboard").then((res) => res.data.data);

export const getCourseProgress = (courseId) =>
  api.get(`/progress/course/${courseId}`).then((res) => res.data.data);

export const enrollInCourse = (courseId) =>
  api.post(`/progress/course/${courseId}/enroll`).then((res) => res.data.data);

export const updateLessonProgress = (courseId, lessonId, payload) =>
  api.patch(`/progress/course/${courseId}/lesson/${lessonId}`, payload).then((res) => res.data.data);

export const updateQuizProgress = (courseId, quizId, payload) =>
  api.patch(`/progress/course/${courseId}/quiz/${quizId}`, payload).then((res) => res.data.data);

export const getProgressCharts = () => api.get("/progress/charts").then((res) => res.data.data);

export const getActivityHistory = (params = {}) =>
  api.get("/activity", { params }).then((res) => res.data);

export const getMilestones = (courseId) =>
  api.get("/milestones", { params: courseId ? { courseId } : {} }).then((res) => res.data.data);
