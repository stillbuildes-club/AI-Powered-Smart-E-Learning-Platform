import api from "./api";

// Week 6: Assignment Submission REST helpers.
export const getAssignmentsForCourse = (courseId) =>
  api.get(`/assignments/course/${courseId}`).then((res) => res.data.data);

export const createAssignment = (payload) => api.post("/assignments", payload).then((res) => res.data.data);

// file: a File object from an <input type="file">, may be null if only submitting text.
export const submitAssignment = (assignmentId, { file, textContent }) => {
  const formData = new FormData();
  if (file) formData.append("file", file);
  if (textContent) formData.append("textContent", textContent);
  return api.post(`/assignments/${assignmentId}/submit`, formData).then((res) => res.data.data);
};

export const getSubmissions = (assignmentId) =>
  api.get(`/assignments/${assignmentId}/submissions`).then((res) => res.data.data);

export const gradeSubmission = (submissionId, payload) =>
  api.patch(`/assignments/submissions/${submissionId}/grade`, payload).then((res) => res.data.data);
