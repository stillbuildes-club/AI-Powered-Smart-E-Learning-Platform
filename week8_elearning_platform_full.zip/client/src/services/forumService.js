import api from "./api";

// Week 6: Discussion Forum REST helpers.
export const getPosts = (courseId) => api.get(`/forum/course/${courseId}`).then((res) => res.data.data);

export const getPostWithComments = (postId) => api.get(`/forum/post/${postId}`).then((res) => res.data.data);

export const createPost = (courseId, payload) =>
  api.post(`/forum/course/${courseId}`, payload).then((res) => res.data.data);

export const addComment = (postId, body) =>
  api.post(`/forum/post/${postId}/comments`, { body }).then((res) => res.data.data);

export const toggleUpvote = (postId) => api.patch(`/forum/post/${postId}/upvote`).then((res) => res.data.data);

export const deletePost = (postId) => api.delete(`/forum/post/${postId}`).then((res) => res.data);
