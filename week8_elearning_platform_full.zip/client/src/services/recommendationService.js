import api from "./api";

// Week 5: API wrappers for the recommendation engine endpoints.
// Every function accepts an optional { category, limit } object.
const toParams = (opts = {}) => {
  const params = {};
  if (opts.category) params.category = opts.category;
  if (opts.limit) params.limit = opts.limit;
  return params;
};

export const getSmartRecommendations = (opts) =>
  api.get("/recommendations", { params: toParams(opts) }).then((res) => res.data);

export const getInterestRecommendations = (opts) =>
  api.get("/recommendations/interests", { params: toParams(opts) }).then((res) => res.data);

export const getCompletedRecommendations = (opts) =>
  api.get("/recommendations/completed", { params: toParams(opts) }).then((res) => res.data);

export const getEnrolledRecommendations = (opts) =>
  api.get("/recommendations/enrolled", { params: toParams(opts) }).then((res) => res.data);

export const getHistoryRecommendations = (opts) =>
  api.get("/recommendations/history", { params: toParams(opts) }).then((res) => res.data);
