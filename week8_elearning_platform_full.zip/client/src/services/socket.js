import { io } from "socket.io-client";

// Week 6: single shared Socket.IO connection for Chat + Live Notifications.
// Reuses the same JWT the axios instance (services/api.js) already attaches
// to REST calls, so no separate login step is needed for real-time features.
//
// Week 7: in the Dockerized deployment, nginx proxies both /api and
// /socket.io to the backend on the *same* origin the frontend is served
// from (see client/nginx.conf), and REACT_APP_API_URL is built as the
// relative path "/api". In that case the socket should connect to the
// current page's origin too, instead of the Week 6 hardcoded
// http://localhost:5000 default, which only applies to local (non-Docker)
// development where the CRA dev server and API run on different ports.
function resolveSocketUrl() {
  if (process.env.REACT_APP_SOCKET_URL) return process.env.REACT_APP_SOCKET_URL;
  const apiUrl = process.env.REACT_APP_API_URL || "http://localhost:5000/api";
  return apiUrl.startsWith("/") ? window.location.origin : "http://localhost:5000";
}

const SOCKET_URL = resolveSocketUrl();

let socket = null;

export const connectSocket = () => {
  const token = localStorage.getItem("token");
  if (!token) return null;

  if (socket && socket.connected) return socket;

  socket = io(SOCKET_URL, {
    auth: { token },
    transports: ["websocket", "polling"],
  });

  return socket;
};

export const getSocket = () => socket;

export const disconnectSocket = () => {
  if (socket) {
    socket.disconnect();
    socket = null;
  }
};
