import api from "./api";

// Week 6: Live Notifications REST helpers (history + read state).
export const getNotifications = (params = {}) =>
  api.get("/notifications", { params }).then((res) => res.data.data);

export const markAsRead = (id) => api.patch(`/notifications/${id}/read`).then((res) => res.data.data);

export const markAllAsRead = () => api.patch("/notifications/read-all").then((res) => res.data);
