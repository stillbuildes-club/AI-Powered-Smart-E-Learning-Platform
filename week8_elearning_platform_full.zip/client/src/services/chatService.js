import api from "./api";

// Week 6: Real-time Chat REST helpers (history + fallback send).
// Live delivery itself goes through services/socket.js.
export const getConversations = () => api.get("/chat/conversations").then((res) => res.data.data);

export const startConversation = (participantId, courseId) =>
  api.post("/chat/conversations", { participantId, courseId }).then((res) => res.data.data);

export const getMessages = (conversationId, params = {}) =>
  api.get(`/chat/conversations/${conversationId}/messages`, { params }).then((res) => res.data.data);

export const sendMessageRest = (conversationId, text) =>
  api.post(`/chat/conversations/${conversationId}/messages`, { text }).then((res) => res.data.data);

export const markConversationRead = (conversationId) =>
  api.patch(`/chat/conversations/${conversationId}/read`).then((res) => res.data);
