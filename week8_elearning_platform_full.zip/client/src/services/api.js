import axios from "axios";

// Central axios instance. Attaches the JWT (stored after login in Week 2/3)
// to every request automatically.
const api = axios.create({
  baseURL: process.env.REACT_APP_API_URL || "http://localhost:5000/api",
  timeout: 15000, // Week 7: fail fast instead of hanging forever on a dead backend
});

api.interceptors.request.use((config) => {
  const token = localStorage.getItem("token");
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// Week 7: centralized response handling for easier debugging in dev and
// consistent behavior in prod — logs the failing method/URL/status once
// instead of every call site needing its own .catch(console.error), and
// normalizes network/timeout errors (which have no `error.response`) into
// the same { message } shape the backend's JSON error responses use.
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (process.env.NODE_ENV !== "production") {
      const { config, response } = error;
      // eslint-disable-next-line no-console
      console.error(
        `[API] ${config?.method?.toUpperCase()} ${config?.url} failed:`,
        response?.status,
        response?.data?.message || error.message
      );
    }

    if (!error.response) {
      error.response = { data: { success: false, message: "Network error — please check your connection." } };
    }

    return Promise.reject(error);
  }
);

export default api;
