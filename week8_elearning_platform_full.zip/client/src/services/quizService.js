import api from "./api";

// Week 6: Interactive Quiz System REST helpers.
export const getQuizzesForCourse = (courseId) => api.get(`/quizzes/course/${courseId}`).then((res) => res.data.data);

export const getQuizForTaking = (quizId) => api.get(`/quizzes/${quizId}/take`).then((res) => res.data.data);

export const submitQuiz = (quizId, answers) =>
  api.post(`/quizzes/${quizId}/submit`, { answers }).then((res) => res.data.data);

export const getQuizHistory = (quizId) => api.get(`/quizzes/${quizId}/history`).then((res) => res.data.data);

export const createQuiz = (payload) => api.post("/quizzes", payload).then((res) => res.data.data);
