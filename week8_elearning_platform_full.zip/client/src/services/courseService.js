import api from "./api";

// Week 6: thin wrapper around the new read-only course listing endpoint,
// used to populate course pickers in Chat/Forum/Quiz/Assignment screens.
export const getCourses = () => api.get("/courses").then((res) => res.data.data);

export const getCourseById = (courseId) => api.get(`/courses/${courseId}`).then((res) => res.data.data);
