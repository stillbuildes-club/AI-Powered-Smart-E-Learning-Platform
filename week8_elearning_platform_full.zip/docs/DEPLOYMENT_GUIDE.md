# Deployment Guide (Final)
## AI Powered Smart E-Learning Web Platform (MERN Stack)
**Week 8 — Final Documentation Release**

> The full step-by-step Docker Compose and cloud deployment walkthrough
> was written in Week 7 and lives at the project root:
> **[`/DEPLOYMENT.md`](../DEPLOYMENT.md)**. It is unchanged in Week 8. This
> document adds the final, submission-ready summary on top of it: a
> one-page deployment overview, the environment variable matrix, and a
> go-live checklist.

## 1. Deployment Overview

| Layer | Technology | Where it runs |
|---|---|---|
| Frontend | React (CRA build) served by nginx | `client/Dockerfile` → container, or static host (Vercel/Netlify) |
| Backend | Node.js + Express + Socket.IO | `server/Dockerfile` → container, or any Docker-friendly PaaS (Render/Railway/Fly.io) |
| Database | MongoDB | `docker-compose.yml` locally; MongoDB Atlas in the cloud |
| File storage | Local disk (`server/uploads`, Docker volume) | Sufficient for the internship submission; see note below for production |

## 2. Fastest path — Docker Compose (single command)

```bash
cp .env.example .env      # set JWT_SECRET at minimum
docker compose up --build
```
- Frontend → `http://localhost:8080`
- Backend API → `http://localhost:5000/api` (also proxied through the frontend at `/api`)

Full explanation of the nginx proxy, container networking, and
`docker compose` commands: see `DEPLOYMENT.md` §1.

## 3. Cloud deployment path

1. **Database:** MongoDB Atlas free (M0) cluster → copy the `mongodb+srv://` connection string.
2. **Backend:** deploy `server/Dockerfile` to Render/Railway/Fly.io, set env vars (table below), health check path `/api/health`.
3. **Frontend:** either the same PaaS as Docker (`client/Dockerfile`) or a static host (Vercel/Netlify/Cloudflare Pages) with `npm run build`.

Full step-by-step instructions for each provider: see `DEPLOYMENT.md` §3.

## 4. Environment Variable Matrix

| Variable | Layer | Required | Notes |
|---|---|---|---|
| `MONGO_URI` | backend | Yes | Atlas connection string in production |
| `JWT_SECRET` | backend | Yes | Must stay identical across restarts/deploys |
| `CLIENT_URL` | backend | Yes | CORS + Socket.IO CORS origin |
| `PORT` | backend | No | Most PaaS platforms inject this automatically |
| `RATE_LIMIT_WINDOW_MS` / `RATE_LIMIT_MAX` | backend | No | Defaults: 15 min / 300 requests |
| `REACT_APP_API_URL` | frontend (build-time) | Yes | `/api` for same-origin Compose; full URL for cross-origin deploys |
| `REACT_APP_SOCKET_URL` | frontend (build-time) | No | Auto-inferred from `REACT_APP_API_URL` if omitted |

`REACT_APP_*` variables are baked into the bundle at **build time** — a
rebuild is required after changing them, not just a restart.

## 5. Go-Live Checklist

- [ ] `JWT_SECRET` set to a long random value (not the `.env.example` placeholder)
- [ ] `MONGO_URI` points to a production/Atlas database, not localhost
- [ ] `CLIENT_URL` matches the deployed frontend's real origin exactly
- [ ] `REACT_APP_API_URL` rebuilt and pointing at the deployed backend
- [ ] `/api/health` returns `200` from the deployed backend URL
- [ ] Login → dashboard → enroll → chat → forum → quiz → assignment flow smoke-tested against the deployed URLs
- [ ] `docker compose logs -f backend` / platform logs checked for startup errors
- [ ] Backend + frontend test suites passing before the deploy (`npm test` in `server/` and `client/`)
- [ ] Uploaded-file persistence understood: local disk works for this submission; production would move to S3-compatible storage (see `DEPLOYMENT.md` §3.2)

## 6. Rollback

Both `docker compose` and typical PaaS platforms (Render/Railway) keep the
previous container image on a failed deploy — redeploying the last known
good image/tag is the fastest rollback path. Since `JWT_SECRET` is shared
across environments, a rollback does not require re-issuing tokens as long
as the secret itself hasn't changed.

---

*Document prepared as part of Week 8 — Final Documentation & Project Wrap-Up. See `DEPLOYMENT.md` (Week 7) for the complete original guide this summarizes.*
