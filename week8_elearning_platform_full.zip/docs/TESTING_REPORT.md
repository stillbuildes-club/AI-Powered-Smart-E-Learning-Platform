# Testing Report
## AI Powered Smart E-Learning Web Platform (MERN Stack)
**Week 8 — Final Documentation Release**

> Note on scope: this report documents the automated test suite that
> already exists in the codebase (`server/tests/`, `client/src/App.test.jsx`,
> written in Week 7) — what each test verifies and how to run it. This
> documentation environment has no network access to install npm
> dependencies, so it reports the suite's designed coverage from the test
> source rather than a fabricated live console output. Run `npm test` in
> `server/` and `client/` (see §5) to produce your own live pass/fail log
> for submission.

## 1. Testing Strategy

| Layer | Framework | Approach |
|---|---|---|
| Backend | Jest + Supertest + `mongodb-memory-server` | Integration tests that hit real Express routes against an in-memory MongoDB instance — no mocking of the database layer |
| Frontend | React Testing Library (via CRA's Jest runner) | Component-level tests with feature tabs mocked, focused on `App.jsx`'s own tab-switching/routing behavior |

Backend tests import the exported Express `app` from `server.js` directly
(the file only opens a real Mongo connection and binds a port when run as
the process entry point — see `require.main === module` in `server.js`),
so each test file spins up its own isolated in-memory database via
`server/tests/setup.js`.

## 2. Backend Test Suite (`server/tests/`)

### 2.1 `health.test.js` — System endpoints
| Test | Verifies |
|---|---|
| `GET /api/health` returns 200 with an ok status | Health check payload shape (`success`, `status`, `uptimeSeconds`) and that the app boots with all Week 7 middleware attached without throwing |
| `GET /api/unknown-route` returns a JSON 404 | The catch-all 404 handler for unmatched `/api/*` paths |

### 2.2 `auth.test.js` — JWT `protect` middleware
Exercised through a real protected route (`GET /api/courses`) rather than
mocked req/res objects, so it also confirms the middleware is correctly
wired into the route chain.
| Test | Verifies |
|---|---|
| Rejects requests with no `Authorization` header | Returns `401`, `success: false` |
| Rejects requests with an invalid/garbage token | Returns `401` |
| Allows requests with a validly-signed token | Returns `200`, `success: true`, `data` is an array |

### 2.3 `course.controller.test.js` — Course catalog
| Test | Verifies |
|---|---|
| Returns all courses when no pagination params are given | Backward compatibility with pre-Week-7 callers |
| Paginates and reports pagination metadata when `limit` is given | `pagination.{page,limit,total,totalPages}` correctness |
| Returns courses sorted alphabetically by title | Sort order contract |
| `GET /api/courses/:id` returns 404 for a well-formed but nonexistent id | Not-found handling on a valid ObjectId with no matching document |

**Backend total: 9 automated test cases across 3 suites.**

## 3. Frontend Test Suite (`client/src/App.test.jsx`)

Feature tabs (Dashboard, Recommendations, Chat, Forum, Quizzes,
Assignments, NotificationBell) are mocked with `jest.mock`, since they
make real API/socket calls on mount — these tests are scoped to
`App.jsx`'s own behavior, not the internals of each tab.

| Test | Verifies |
|---|---|
| Renders the Dashboard tab by default | Initial tab state |
| Switches to the Forum tab when clicked | Tab-switch handler + lazy-loaded chunk renders, previous tab unmounts |
| Renders all six tab buttons | Dashboard, Recommendations, Chat, Forum, Quizzes, Assignments all present |

**Frontend total: 3 automated test cases.**

## 4. Manual / Exploratory Testing Checklist

For features not yet covered by automated tests (recommendation scoring
correctness, milestone-award edge cases, quiz auto-grading accuracy,
Socket.IO live delivery, file upload/grading flow), use this checklist
before each submission or deploy:

- [ ] Register/log in, confirm JWT persists across a page refresh
- [ ] Enroll in a course, mark a lesson complete, confirm dashboard % updates
- [ ] Pass a quiz, confirm a `first_quiz_passed` milestone appears
- [ ] Complete every quiz in one course, confirm the `quiz_master` milestone appears exactly once (not duplicated on repeat attempts)
- [ ] Add `interests` to a user and `tags` to a course, confirm `/api/recommendations` re-ranks accordingly
- [ ] Open two browser sessions as different users, start a chat, confirm messages and typing indicators arrive live via Socket.IO
- [ ] Post in the Forum from one session, confirm the other session's notification bell updates live
- [ ] Submit an assignment file, grade it as the instructor, confirm the student sees the score/feedback
- [ ] Restart the backend mid-session, confirm the frontend's `ErrorBoundary` isolates the failure to one tab instead of blanking the app
- [ ] Hit `/api/health` directly to confirm it's DB-independent (works even if Mongo is briefly unreachable)

## 5. Running the Suites

```bash
# Backend
cd server
npm install
npm test              # single run
npm run test:watch    # watch mode during development

# Frontend
cd client
npm install
npm test               # watch mode
npm run test:ci        # single run with coverage, for CI pipelines
```

## 6. Known Gaps / Recommendations for Future Test Coverage

- No automated tests yet for: `recommendationService.js` scoring math,
  `milestoneChecker.js` award logic, quiz auto-grading in
  `quizController.js`, or the Socket.IO event handlers in
  `server/socket/index.js`.
- No end-to-end (browser-driven) test suite (e.g. Playwright/Cypress)
  covering a full user journey across tabs.
- Frontend component tests exist only for `App.jsx`; individual feature
  components (Dashboard, Chat, Forum, Quiz, Assignments) have no
  dedicated unit tests yet.

These are natural candidates for a future testing pass — see
[`CONCLUSION_AND_FUTURE_SCOPE.md`](./CONCLUSION_AND_FUTURE_SCOPE.md).

---

*Document prepared as part of Week 8 — Final Documentation & Project Wrap-Up.*
