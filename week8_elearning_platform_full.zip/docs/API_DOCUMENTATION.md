# API Documentation
## AI Powered Smart E-Learning Web Platform (MERN Stack)
**Week 8 — Final Documentation Release**

Base URL (local): `http://localhost:5000/api`
Base URL (Docker Compose): `http://localhost:8080/api` (proxied by nginx)

All endpoints below (except `/health`) require a JSON Web Token issued at
login, sent as:

```
Authorization: Bearer <token>
```

Requests without a valid token receive `401 Unauthorized`:
```json
{ "success": false, "message": "Not authorized, no token provided" }
```

Every JSON response follows one envelope:
```json
{ "success": true,  "data": ... }
{ "success": false, "message": "..." }
```
List endpoints additionally return `"count"` and, where paginated, a
`"pagination"` object (`{ page, limit, total, totalPages }`).

---

## Table of Contents
1. [System](#1-system)
2. [Courses](#2-courses)
3. [Student Progress Tracking (Week 4)](#3-student-progress-tracking-week-4)
4. [Activity History (Week 4)](#4-activity-history-week-4)
5. [Milestones (Week 4)](#5-milestones-week-4)
6. [AI-Based Course Recommendations (Week 5)](#6-ai-based-course-recommendations-week-5)
7. [Chat / Direct Messaging (Week 6)](#7-chat--direct-messaging-week-6)
8. [Discussion Forum (Week 6)](#8-discussion-forum-week-6)
9. [Live Notifications (Week 6)](#9-live-notifications-week-6)
10. [Interactive Quizzes (Week 6)](#10-interactive-quizzes-week-6)
11. [Assignments (Week 6)](#11-assignments-week-6)
12. [Real-Time Events (Socket.IO)](#12-real-time-events-socketio)
13. [Error Reference](#13-error-reference)

---

## 1. System

### `GET /api/health`
No authentication required. Liveness/readiness probe used by Docker and
cloud health checks.

**Response `200`**
```json
{ "success": true, "status": "ok", "uptimeSeconds": 1234, "timestamp": "2026-07-21T06:00:00.000Z" }
```

---

## 2. Courses

### `GET /api/courses`
Returns the course catalog. Response is cached server-side for 60 seconds.

| Query param | Type | Notes |
|---|---|---|
| `page` | number | optional |
| `limit` | number | optional, max 100. Omitting both `page`/`limit` returns every course (legacy behavior). |

**Response `200`**
```json
{
  "success": true,
  "data": [{ "_id": "...", "title": "React Basics", "category": "Web Development", "thumbnail": "", "instructor": "..." }],
  "pagination": { "page": 1, "limit": 20, "total": 42, "totalPages": 3 }
}
```

### `GET /api/courses/:id`
Returns one course with the instructor populated (`name`, `email`, `role`).
`404` if the course does not exist.

---

## 3. Student Progress Tracking (Week 4)

| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/progress/dashboard` | Summary stats, all enrolled courses, recent activity |
| GET | `/api/progress/charts` | Chart-ready data: per-course completion, lessons vs quizzes, 30-day activity trend |
| GET | `/api/progress/course/:courseId` | Lesson/quiz breakdown for one course |
| POST | `/api/progress/course/:courseId/enroll` | Initialize progress tracking for a course |
| PATCH | `/api/progress/course/:courseId/lesson/:lessonId` | Body: `{ status, timeSpentMinutes }` — mark a lesson `not_started`/`in_progress`/`completed` |
| PATCH | `/api/progress/course/:courseId/quiz/:quizId` | Body: `{ score }` — record a quiz attempt against the completion tracker |

Completion percentage is a weighted average — 70% lesson completion + 30%
quiz pass rate when a course has both; 100% of whichever exists otherwise.
Updating a lesson or quiz automatically re-evaluates and awards any
newly-unlocked milestones.

---

## 4. Activity History (Week 4)

### `GET /api/activity`
Paginated, append-only log of student actions.

| Query param | Type |
|---|---|
| `page`, `limit` | number |
| `courseId` | ObjectId, filter to one course |
| `type` | one of `course_started`, `lesson_completed`, `quiz_attempted`, `quiz_passed`, `course_completed`, `milestone_achieved` |

---

## 5. Milestones (Week 4)

### `GET /api/milestones?courseId=`
Returns unlocked achievements for the logged-in student: `course_started`,
`quarter_complete` (25%), `halfway_complete` (50%),
`three_quarter_complete` (75%), `course_completed`, `first_quiz_passed`,
`quiz_master` (every quiz in a course passed). A unique index on
`(student, course, type)` guarantees each is awarded at most once.

---

## 6. AI-Based Course Recommendations (Week 5)

All routes accept optional query params `?category=<name>&limit=<n>`
(`limit` defaults to 10, max 50).

| Method | Endpoint | Signal |
|---|---|---|
| GET | `/api/recommendations` | Combined smart ranking (all signals + popularity), includes a per-signal `breakdown` |
| GET | `/api/recommendations/interests` | `User.interests` matched to course category/tags |
| GET | `/api/recommendations/completed` | Category frequency among completed courses |
| GET | `/api/recommendations/enrolled` | Category frequency among all touched courses |
| GET | `/api/recommendations/history` | Recency-weighted categories from the Activity log |

Scoring weights: interests 30%, completed courses 25%, learning history
20%, enrolled courses 15%, popularity 10%.

**Response `200` (combined endpoint)**
```json
{
  "success": true,
  "count": 8,
  "data": [{
    "course": { "_id": "...", "title": "...", "category": "...", "tags": ["..."] },
    "score": 62.5,
    "breakdown": { "interestScore": 70, "completedScore": 40, "enrolledScore": 0, "historyScore": 55, "popularityScore": 20 }
  }]
}
```

---

## 7. Chat / Direct Messaging (Week 6)

| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/chat/conversations` | List the caller's conversations, most recent first |
| POST | `/api/chat/conversations` | Start (or fetch, if already exists) a 1-to-1 conversation |
| GET | `/api/chat/conversations/:conversationId/messages` | Message history |
| POST | `/api/chat/conversations/:conversationId/messages` | Send a message over REST (also mirrored over Socket.IO) |
| PATCH | `/api/chat/conversations/:conversationId/read` | Mark a conversation as read |

---

## 8. Discussion Forum (Week 6)

| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/forum/course/:courseId` | List posts for a course |
| POST | `/api/forum/course/:courseId` | Create a post |
| GET | `/api/forum/post/:postId` | One post with its comments |
| POST | `/api/forum/post/:postId/comments` | Add a comment/reply |
| PATCH | `/api/forum/post/:postId/upvote` | Toggle the caller's upvote |
| DELETE | `/api/forum/post/:postId` | Delete a post (author/instructor) |

---

## 9. Live Notifications (Week 6)

| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/notifications` | List notifications for the caller |
| PATCH | `/api/notifications/:id/read` | Mark one as read |
| PATCH | `/api/notifications/read-all` | Mark all as read |

Notification types: `chat`, `forum`, `quiz`, `assignment`, `system`. Each
persisted notification is also pushed live over Socket.IO to the user's
private room so the bell icon updates instantly even before a page refresh.

---

## 10. Interactive Quizzes (Week 6)

| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/quizzes/course/:courseId` | List quizzes for a course |
| GET | `/api/quizzes/:quizId/take` | Fetch a quiz for taking (correct answers withheld) |
| POST | `/api/quizzes/:quizId/submit` | Submit answers, get scored instantly |
| GET | `/api/quizzes/:quizId/history` | The caller's past attempts on this quiz |
| POST | `/api/quizzes` | Create a quiz (instructor) |

A quiz submission is scored server-side, stored in `QuizSubmission` with a
per-question correct/incorrect breakdown, and also rolls up into the
lightweight `Progress.quizzesProgress` aggregate used by the dashboard.

---

## 11. Assignments (Week 6)

| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/assignments/course/:courseId` | List assignments for a course |
| POST | `/api/assignments` | Create an assignment (instructor) |
| POST | `/api/assignments/:assignmentId/submit` | Submit — `multipart/form-data`, file field name `file` |
| GET | `/api/assignments/:assignmentId/submissions` | List submissions (instructor) |
| PATCH | `/api/assignments/submissions/:submissionId/grade` | Grade a submission — body: `{ score, feedback }` |

Uploaded files are served back from `/uploads/assignments/<filename>`
(long-lived cache headers, immutable filenames). One submission per
student per assignment; resubmitting before grading overwrites it.

---

## 12. Real-Time Events (Socket.IO)

Connect with `io(url, { auth: { token } })` using the same JWT as REST
calls. Every socket auto-joins a private room `user:<id>`.

| Event (client → server) | Payload | Purpose |
|---|---|---|
| `chat:join` | `conversationId` | Join a conversation room |
| `chat:leave` | `conversationId` | Leave a conversation room |
| `chat:message` | `{ conversationId, text }` | Send a message; acks with `{ success, data }` |
| `chat:typing` | `{ conversationId, isTyping }` | Typing indicator |

| Event (server → client) | Payload | Purpose |
|---|---|---|
| `chat:message` | populated message | Broadcast to everyone in the conversation room |
| `chat:incoming` | `{ conversationId, message }` | Pushed to the other participant's user room |
| `chat:typing` | `{ conversationId, userId, isTyping }` | Typing indicator relay |

Notifications, forum replies, quiz results, and assignment grading also
push live events to a user's `user:<id>` room via the shared
`emitToUser()` helper (`server/socket/index.js`), which the
`NotificationBell.jsx` component listens for.

---

## 13. Error Reference

| Status | Meaning |
|---|---|
| `400` | Validation error — check the request body against the endpoint's expected fields |
| `401` | Missing, malformed, or expired JWT |
| `403` | Authenticated but not permitted (e.g. non-instructor calling an instructor-only route) |
| `404` | Resource not found, or an unmatched `/api/*` route |
| `429` | Rate limit exceeded — default 300 requests / 15 minutes per client, tunable via `RATE_LIMIT_MAX` / `RATE_LIMIT_WINDOW_MS` |
| `500` | Unhandled server error — centralized handler in `server.js`, logs `err.stack` |

---

*Document prepared as part of Week 8 — Final Documentation & Project Wrap-Up.*
