# User Manual
## AI Powered Smart E-Learning Web Platform (MERN Stack)
**Week 8 — Final Documentation Release**

This manual explains how to use the platform from a student's
perspective, tab by tab, as the interface exists at the end of Week 7.

## 1. Getting Started

1. Open the app in your browser (`http://localhost:3000` locally, or your
   deployed URL).
2. Log in with your account (existing Week 2–3 authentication).
3. You'll land on the top navigation bar with six tabs: **Dashboard**,
   **Recommendations**, **Chat**, **Forum**, **Quizzes**, **Assignments**
   — plus a notification bell on the right.

## 2. Dashboard Tab

Your personal learning overview:
- **Course Completion Cards** — a percentage-complete card per enrolled course.
- **Lesson Progress List** — which lessons in the current course are not started / in progress / completed.
- **Quiz Progress List** — attempts, best score, and pass/fail per quiz.
- **Activity History** — a running feed of everything you've done (lessons completed, quizzes passed, milestones earned).
- **Milestone Tracker** — badges earned at 25%/50%/75%/100% course completion, on your first quiz pass, and for passing every quiz in a course ("Quiz Master").
- **Progress Charts** — bar and line charts summarizing completion and a 30-day activity trend.

**To make progress:** open a course, mark lessons complete as you finish
them, and take quizzes — your completion percentage and milestones update
automatically.

## 3. Recommendations Tab

Course suggestions tailored to you, in five sub-views:
- **For You** — the combined ranking (your best match), with a
  score breakdown per course showing which signal contributed most.
- **Interests** — matched against topics you've declared on your profile.
- **Completed** — similar to courses you've already finished.
- **Enrolled** — similar to courses you're currently taking.
- **History** — based on your recent lesson/quiz activity.

Use the category dropdown to filter any of the five views to one subject
area.

## 4. Chat Tab

Direct messaging with instructors or classmates:
- The left sidebar lists your conversations, most recent first.
- Select a conversation to see the message history and send new messages.
- Messages, typing indicators, and delivery are instant (Socket.IO) — no
  need to refresh.
- Unread conversations are marked automatically as read once opened.

## 5. Forum Tab

Course discussion boards:
- Browse existing posts for a course, or start a new one.
- Reply to a post — instructor replies are visually distinguished.
- Upvote helpful posts/answers.
- Post authors (and instructors) can delete a post.

## 6. Quizzes Tab

- Pick a course to see its available quizzes.
- Start a quiz — questions are multiple-choice; correct answers are not
  shown until after you submit.
- Submit your answers to get an instant score and pass/fail result.
- Review your **quiz history** to see past attempts and your best score.

## 7. Assignments Tab

- View assignments due for a course, with due dates and max score.
- Submit your work as text and/or a file attachment.
- Once an instructor grades your submission, your score and written
  feedback appear here.
- Resubmitting before grading replaces your previous submission.

## 8. Notifications

The bell icon in the top bar shows a live count of unread notifications
covering chat messages, forum replies, quiz results, and assignment
grading. Click it to view the list; mark individual items or everything
as read.

## 9. Tips

- Everything in this app requires you to be logged in — if any tab shows
  an error, check that your session hasn't expired and log in again.
- If a tab fails to load, the rest of the app keeps working — only that
  tab shows an error message, thanks to per-tab error isolation.
- Chat and notifications need a live connection; if they stop updating,
  a refresh will reconnect them.

---

*Document prepared as part of Week 8 — Final Documentation & Project Wrap-Up.*
