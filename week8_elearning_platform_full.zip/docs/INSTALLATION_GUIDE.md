# Installation Guide
## AI Powered Smart E-Learning Web Platform (MERN Stack)
**Week 8 — Final Documentation Release**

This guide covers getting the project running from a fresh clone, for
either local development or a quick evaluation run. For containerized and
cloud deployment, see [`DEPLOYMENT_GUIDE.md`](./DEPLOYMENT_GUIDE.md).

## 1. Prerequisites

| Requirement | Version | Notes |
|---|---|---|
| Node.js | v18 or later | Includes npm |
| MongoDB | v6+ | Local install, or a free MongoDB Atlas cluster |
| Git | any recent version | To clone the repository |
| Docker Desktop / Engine | 24+ (optional) | Only needed for the containerized run — see Deployment Guide |

Check your versions:
```bash
node -v
npm -v
mongod --version
```

## 2. Get the Code

```bash
git clone <your-repository-url>
cd <project-folder>
```

## 3. Backend Setup

```bash
cd server
npm install
cp .env.example .env
```

Open `.env` and set at minimum:

| Variable | Example | Required |
|---|---|---|
| `MONGO_URI` | `mongodb://localhost:27017/elearning_platform` | Yes |
| `JWT_SECRET` | a long random string | Yes |
| `PORT` | `5000` | No — defaults to 5000 |
| `CLIENT_URL` | `http://localhost:3000` | Yes (used for CORS + Socket.IO CORS) |
| `RATE_LIMIT_WINDOW_MS` / `RATE_LIMIT_MAX` | `900000` / `300` | No — sensible defaults apply |

Start the backend:
```bash
npm run dev      # nodemon, auto-restarts on file changes
# or
npm start        # plain node, for a production-style run
```

You should see:
```
Server running on port 5000 (HTTP + Socket.IO)
```

Verify it's alive:
```bash
curl http://localhost:5000/api/health
```

## 4. Frontend Setup

Open a second terminal:
```bash
cd client
npm install
```

If your API isn't at the default address, create `client/.env`:
```
REACT_APP_API_URL=http://localhost:5000/api
```

Start the frontend:
```bash
npm start
```

The app opens automatically at `http://localhost:3000`.

## 5. First-Run Checklist

1. Confirm MongoDB is running and reachable at your `MONGO_URI`.
2. Log in through the existing authentication flow (Week 2–3) so a JWT is
   stored in `localStorage` under the key `token` — every feature added
   from Week 4 onward depends on this token being present.
3. Open the app — you should land on the **Dashboard** tab with five more
   tabs available: Recommendations, Chat, Forum, Quizzes, Assignments.
4. Enroll in a course (`POST /api/progress/course/:courseId/enroll`) to
   start seeing dashboard data.

## 6. Running Tests

```bash
# Backend — Jest + Supertest + an in-memory MongoDB (no real DB needed)
cd server
npm test

# Frontend — React Testing Library via CRA's built-in Jest runner
cd client
npm test
```

See [`TESTING_REPORT.md`](./TESTING_REPORT.md) for what each suite covers.

## 7. Troubleshooting

| Symptom | Likely cause / fix |
|---|---|
| `MongoNetworkError` on backend start | MongoDB isn't running, or `MONGO_URI` is wrong |
| `401 Not authorized` on every API call | No/expired JWT in `localStorage` — log in again |
| Frontend loads but shows network errors | `REACT_APP_API_URL` doesn't match where the backend is running |
| Socket features (chat, live notifications) don't connect | `CLIENT_URL` on the backend doesn't match the frontend's actual origin |
| `EADDRINUSE` on port 5000 | Another process is already using the port — change `PORT` in `.env` or stop the other process |

---

*Document prepared as part of Week 8 — Final Documentation & Project Wrap-Up.*
