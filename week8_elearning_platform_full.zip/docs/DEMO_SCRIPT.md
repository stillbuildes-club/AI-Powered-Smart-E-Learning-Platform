# Demo Script
## AI Powered Smart E-Learning Web Platform (MERN Stack)
**Week 8 — Final Documentation Release**

A ~10-minute walkthrough script for presenting the project to evaluators,
covering every major module in a logical order. Prepare two logged-in
sessions (e.g. two browser windows, or one normal + one incognito) as
**Student A** and **Student B** ahead of time for the live-update
demonstrations in Steps 6–7.

## Setup (before the demo starts)
- Backend and frontend running (or the Docker Compose stack up).
- Seed data ready: at least 2–3 courses with lessons, a couple of quizzes,
  one assignment, and two student accounts.
- `GET /api/health` checked once to confirm the backend is live.

## Script

**1. Introduction (30 sec)**
> "This is an AI-powered Smart E-Learning platform built on the MERN
> stack. It covers personalized course recommendations, full student
> progress tracking, and interactive virtual learning — chat, forums,
> quizzes, and assignments — all in real time."

**2. Login & Dashboard (1.5 min)**
- Log in as Student A.
- Point out the Dashboard tab: course completion cards, lesson/quiz
  progress lists, activity history, milestone tracker, and the progress
  charts.
- Mark a lesson complete live → show the completion percentage update
  immediately and a new entry appear in Activity History.

**3. Milestones (1 min)**
- Take a quiz and pass it → show the "First Quiz Passed" milestone appear
  automatically on the Milestone Tracker.
- Mention the 25/50/75/100% completion milestones and the "Quiz Master"
  milestone, and that duplicates are prevented by a unique DB index.

**4. AI-Based Recommendations (1.5 min)**
- Switch to the Recommendations tab.
- Show the "For You" combined ranking and open the score breakdown for
  one course (interest/completed/enrolled/history/popularity signals).
- Switch to the "Interests" or "History" sub-tab to show an individual
  signal in isolation, and demonstrate the category filter.

**5. Interactive Quizzes (1 min)**
- Switch to the Quizzes tab, pick a course, start a quiz, submit answers,
  and show the instant scored result plus the quiz history.

**6. Chat — real-time (1.5 min)**
- In Student A's session, open Chat and send a message to Student B.
- Switch to Student B's session (already open) → show the message and
  typing indicator arriving instantly with no refresh, via Socket.IO.

**7. Discussion Forum & Live Notifications (1 min)**
- As Student B, post a reply on a Forum thread Student A started.
- Switch back to Student A → show the notification bell update live.

**8. Assignments (1 min)**
- As Student A, submit an assignment (text + file).
- As an instructor account (or explain the flow if only student accounts
  are seeded), grade the submission with a score and feedback.
- Show the graded result appear back on the student's Assignments tab.

**9. Resilience & Production-Readiness (1 min)**
- Mention: Dockerized frontend + backend + MongoDB via one
  `docker compose up`, `/api/health` for uptime checks, graceful shutdown,
  rate limiting, gzip compression, security headers (helmet), route-level
  code-splitting on the frontend, and per-tab error boundaries — briefly
  demonstrate the latter by triggering a tab error (e.g. via dev tools)
  and showing the rest of the app keeps working.

**10. Testing & Wrap-Up (1 min)**
- Mention the automated backend (Jest/Supertest, in-memory MongoDB) and
  frontend (React Testing Library) test suites, and run `npm test` in
  `server/` live if time allows.
- Close with the project's scope across all 8 weeks and the future scope
  items (see `CONCLUSION_AND_FUTURE_SCOPE.md`).

## Fallback Talking Points (if live demo has issues)

- Keep this documentation set (`docs/`) open as a backup — the
  `API_DOCUMENTATION.md` and screenshots/description in the project
  report can carry the explanation if a live feature misbehaves.
- If Socket.IO doesn't connect in the demo environment, explain the
  architecture (private `user:<id>` rooms, `emitToUser()` helper) instead
  of live-demoing it, and fall back to a page refresh to show the
  persisted result.

---

*Document prepared as part of Week 8 — Final Documentation & Project Wrap-Up.*
