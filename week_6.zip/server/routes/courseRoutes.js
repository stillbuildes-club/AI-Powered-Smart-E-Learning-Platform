const express = require("express");
const router = express.Router();
const { protect } = require("../middleware/auth");
const { getCourses, getCourseById } = require("../controllers/courseController");

router.get("/", protect, getCourses);
router.get("/:id", protect, getCourseById);

module.exports = router;
