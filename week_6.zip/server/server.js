require("dotenv").config();
const path = require("path");
const http = require("http");
const express = require("express");
const cors = require("cors");
const connectDB = require("./config/db");

const progressRoutes = require("./routes/progressRoutes");
const activityRoutes = require("./routes/activityRoutes");
const milestoneRoutes = require("./routes/milestoneRoutes");
const recommendationRoutes = require("./routes/recommendationRoutes");

// Week 6 feature routes
const courseRoutes = require("./routes/courseRoutes");
const chatRoutes = require("./routes/chatRoutes");
const forumRoutes = require("./routes/forumRoutes");
const notificationRoutes = require("./routes/notificationRoutes");
const quizRoutes = require("./routes/quizRoutes");
const assignmentRoutes = require("./routes/assignmentRoutes");

const socket = require("./socket");

const app = express();

connectDB();

app.use(cors({ origin: process.env.CLIENT_URL || "http://localhost:3000" }));
app.use(express.json());

// Serve uploaded assignment files (Week 6).
app.use("/uploads", express.static(path.join(__dirname, "uploads")));

// Week 4 feature routes: Student Progress Dashboard, Lesson/Quiz progress,
// Activity History, Milestone Tracking, Progress Charts data.
app.use("/api/progress", progressRoutes);
app.use("/api/activity", activityRoutes);
app.use("/api/milestones", milestoneRoutes);

// Week 5 feature routes: AI-Based Course Recommendation Engine.
app.use("/api/recommendations", recommendationRoutes);

// Week 6 feature routes: Chat, Discussion Forum, Live Notifications,
// Interactive Quiz System, Assignment Submission. `courseRoutes` was added
// alongside these since several of them need a course picker on the
// frontend and no generic course-listing endpoint existed yet.
app.use("/api/courses", courseRoutes);
app.use("/api/chat", chatRoutes);
app.use("/api/forum", forumRoutes);
app.use("/api/notifications", notificationRoutes);
app.use("/api/quizzes", quizRoutes);
app.use("/api/assignments", assignmentRoutes);

app.get("/", (req, res) => {
  res.send("E-Learning Platform API — Week 6: Chat, Forum, Notifications, Quizzes & Assignments running");
});

// Basic error handler
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ success: false, message: "Server error" });
});

const PORT = process.env.PORT || 5000;

// Week 6: app is now wrapped in a plain http.Server so Socket.IO can
// attach to the same port as the REST API (no separate server/port needed).
const server = http.createServer(app);
socket.init(server, process.env.CLIENT_URL || "http://localhost:3000");

server.listen(PORT, () => console.log(`Server running on port ${PORT} (HTTP + Socket.IO)`));
