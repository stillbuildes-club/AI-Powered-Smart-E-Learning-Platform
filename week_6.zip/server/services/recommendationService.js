const Course = require("../models/Course");
const Progress = require("../models/Progress");
const Activity = require("../models/Activity");

// ---------------------------------------------------------------------------
// Week 5: AI-Based Course Recommendation Engine
//
// This is a content-based / behavior-based scoring engine (no external AI
// service required). It combines four signals — declared interests,
// completed-course categories, currently-enrolled-course categories, and
// recent learning-activity categories — plus an overall popularity score,
// into a single weighted ranking. Each signal is also exposed individually
// through the controller for the "recommend by X" endpoints.
// ---------------------------------------------------------------------------

const WEIGHTS = {
  interest: 0.3,
  completed: 0.25,
  enrolled: 0.15,
  history: 0.2,
  popularity: 0.1,
};

// Builds a { category: frequency } map from a list of courses.
function buildCategoryFrequencyMap(courses) {
  const map = {};
  for (const course of courses) {
    if (!course || !course.category) continue;
    map[course.category] = (map[course.category] || 0) + 1;
  }
  return map;
}

// Normalizes a frequency map to 0-100 based on its own max value.
function normalizeMap(map) {
  const max = Math.max(1, ...Object.values(map));
  const normalized = {};
  for (const key of Object.keys(map)) {
    normalized[key] = (map[key] / max) * 100;
  }
  return normalized;
}

// Fetches every course the student has a Progress record for (enrolled,
// in-progress, or completed), split by status, so callers can build
// category-affinity maps for each of the "recommend by X" signals.
async function getStudentCourseHistory(studentId) {
  const progressRecords = await Progress.find({ student: studentId }).populate("course");

  const completedCourses = progressRecords
    .filter((p) => p.status === "completed")
    .map((p) => p.course)
    .filter(Boolean);

  const enrolledCourses = progressRecords // any course the student has touched, regardless of status
    .map((p) => p.course)
    .filter(Boolean);

  const enrolledCourseIds = new Set(progressRecords.map((p) => p.course?._id?.toString()));

  return { completedCourses, enrolledCourses, enrolledCourseIds };
}

// Builds a recency-weighted category affinity map from the student's recent
// activity log (lesson completions and quiz attempts/passes carry more
// weight than a course being merely started).
async function getHistoryAffinity(studentId) {
  const activities = await Activity.find({
    student: studentId,
    type: { $in: ["lesson_completed", "quiz_passed", "quiz_attempted", "course_completed"] },
  })
    .sort({ createdAt: -1 })
    .limit(200)
    .populate("course", "category");

  const now = Date.now();
  const map = {};

  for (const activity of activities) {
    if (!activity.course || !activity.course.category) continue;
    const ageDays = (now - new Date(activity.createdAt).getTime()) / (1000 * 60 * 60 * 24);
    // Exponential recency decay: activity from today counts ~1x, from 30 days
    // ago counts ~0.37x, older activity contributes progressively less.
    const recencyWeight = Math.exp(-ageDays / 30);
    const typeWeight = activity.type === "quiz_passed" || activity.type === "course_completed" ? 1.5 : 1;
    const category = activity.course.category;
    map[category] = (map[category] || 0) + recencyWeight * typeWeight;
  }

  return normalizeMap(map);
}

// Popularity: how many students overall are enrolled in each course.
// Returns a { courseId: normalizedScore(0-100) } map.
async function getPopularityScores(courseIds) {
  const counts = await Progress.aggregate([
    { $match: { course: { $in: courseIds } } },
    { $group: { _id: "$course", enrollments: { $sum: 1 } } },
  ]);

  const map = {};
  counts.forEach((c) => (map[c._id.toString()] = c.enrollments));
  const max = Math.max(1, ...Object.values(map));

  const normalized = {};
  courseIds.forEach((id) => {
    const key = id.toString();
    normalized[key] = ((map[key] || 0) / max) * 100;
  });
  return normalized;
}

// Interest match score for one course against a list of user interests.
// Category match is worth more than a single tag overlap.
function interestMatchScore(course, interests = []) {
  if (!interests || interests.length === 0) return 0;
  const normalizedInterests = interests.map((i) => i.toLowerCase().trim());
  let score = 0;

  if (course.category && normalizedInterests.includes(course.category.toLowerCase())) {
    score += 70;
  }

  const courseTags = (course.tags || []).map((t) => t.toLowerCase());
  const overlap = courseTags.filter((t) => normalizedInterests.includes(t)).length;
  score += Math.min(30, overlap * 15);

  return score;
}

/**
 * Core ranking function. Fetches every course the student is NOT already
 * enrolled in, scores each candidate against all four signals plus
 * popularity, and returns them sorted highest-score first.
 *
 * @param {string} studentId
 * @param {object} options
 * @param {string} [options.category] - optional category filter
 * @param {number} [options.limit=10]
 */
async function getSmartRecommendations(studentId, { category, limit = 10 } = {}) {
  const [user, { completedCourses, enrolledCourses, enrolledCourseIds }, historyAffinity] = await Promise.all([
    require("../models/User").findById(studentId),
    getStudentCourseHistory(studentId),
    getHistoryAffinity(studentId),
  ]);

  const completedAffinity = normalizeMap(buildCategoryFrequencyMap(completedCourses));
  const enrolledAffinity = normalizeMap(buildCategoryFrequencyMap(enrolledCourses));

  const candidateFilter = { _id: { $nin: Array.from(enrolledCourseIds).filter(Boolean) } };
  if (category) candidateFilter.category = category;

  const candidates = await Course.find(candidateFilter);
  const popularityMap = await getPopularityScores(candidates.map((c) => c._id));

  const scored = candidates.map((course) => {
    const interestScore = interestMatchScore(course, user?.interests || []);
    const completedScore = completedAffinity[course.category] || 0;
    const enrolledScore = enrolledAffinity[course.category] || 0;
    const historyScore = historyAffinity[course.category] || 0;
    const popularityScore = popularityMap[course._id.toString()] || 0;

    const totalScore =
      interestScore * WEIGHTS.interest +
      completedScore * WEIGHTS.completed +
      enrolledScore * WEIGHTS.enrolled +
      historyScore * WEIGHTS.history +
      popularityScore * WEIGHTS.popularity;

    return {
      course,
      score: Math.round(totalScore * 100) / 100,
      breakdown: {
        interestScore: Math.round(interestScore),
        completedScore: Math.round(completedScore),
        enrolledScore: Math.round(enrolledScore),
        historyScore: Math.round(historyScore),
        popularityScore: Math.round(popularityScore),
      },
    };
  });

  scored.sort((a, b) => b.score - a.score);
  return scored.slice(0, limit);
}

/** Recommend courses purely by matching declared interests. */
async function getRecommendationsByInterests(studentId, { category, limit = 10 } = {}) {
  const User = require("../models/User");
  const [user, { enrolledCourseIds }] = await Promise.all([
    User.findById(studentId),
    getStudentCourseHistory(studentId),
  ]);

  const filter = { _id: { $nin: Array.from(enrolledCourseIds).filter(Boolean) } };
  if (category) filter.category = category;

  const candidates = await Course.find(filter);
  const scored = candidates
    .map((course) => ({ course, score: interestMatchScore(course, user?.interests || []) }))
    .filter((c) => c.score > 0)
    .sort((a, b) => b.score - a.score);

  return scored.slice(0, limit);
}

/** Recommend courses in the same categories as courses the student completed. */
async function getRecommendationsByCompletedCourses(studentId, { category, limit = 10 } = {}) {
  const { completedCourses, enrolledCourseIds } = await getStudentCourseHistory(studentId);
  const affinity = normalizeMap(buildCategoryFrequencyMap(completedCourses));

  const filter = { _id: { $nin: Array.from(enrolledCourseIds).filter(Boolean) } };
  if (category) filter.category = category;

  const candidates = await Course.find(filter);
  const scored = candidates
    .map((course) => ({ course, score: affinity[course.category] || 0 }))
    .filter((c) => c.score > 0)
    .sort((a, b) => b.score - a.score);

  return scored.slice(0, limit);
}

/** Recommend courses in the same categories as courses the student is currently enrolled in. */
async function getRecommendationsByEnrolledCourses(studentId, { category, limit = 10 } = {}) {
  const { enrolledCourses, enrolledCourseIds } = await getStudentCourseHistory(studentId);
  const affinity = normalizeMap(buildCategoryFrequencyMap(enrolledCourses));

  const filter = { _id: { $nin: Array.from(enrolledCourseIds).filter(Boolean) } };
  if (category) filter.category = category;

  const candidates = await Course.find(filter);
  const scored = candidates
    .map((course) => ({ course, score: affinity[course.category] || 0 }))
    .filter((c) => c.score > 0)
    .sort((a, b) => b.score - a.score);

  return scored.slice(0, limit);
}

/** Recommend courses based on recent learning activity (recency-weighted). */
async function getRecommendationsByHistory(studentId, { category, limit = 10 } = {}) {
  const [{ enrolledCourseIds }, historyAffinity] = await Promise.all([
    getStudentCourseHistory(studentId),
    getHistoryAffinity(studentId),
  ]);

  const filter = { _id: { $nin: Array.from(enrolledCourseIds).filter(Boolean) } };
  if (category) filter.category = category;

  const candidates = await Course.find(filter);
  const scored = candidates
    .map((course) => ({ course, score: historyAffinity[course.category] || 0 }))
    .filter((c) => c.score > 0)
    .sort((a, b) => b.score - a.score);

  return scored.slice(0, limit);
}

module.exports = {
  getSmartRecommendations,
  getRecommendationsByInterests,
  getRecommendationsByCompletedCourses,
  getRecommendationsByEnrolledCourses,
  getRecommendationsByHistory,
};
