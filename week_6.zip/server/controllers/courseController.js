const Course = require("../models/Course");

// Week 6: a minimal read-only course list/detail API. Added because the
// new course-scoped features (Forum, Quiz, Assignments) need a course
// picker on the frontend, and no generic course listing endpoint existed
// yet in Weeks 1-5 (only nested progress/recommendation endpoints did).

// GET /api/courses
const getCourses = async (req, res) => {
  try {
    const courses = await Course.find().select("title category thumbnail instructor").sort({ title: 1 });
    res.status(200).json({ success: true, data: courses });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// GET /api/courses/:id
const getCourseById = async (req, res) => {
  try {
    const course = await Course.findById(req.params.id).populate("instructor", "name email role");
    if (!course) return res.status(404).json({ success: false, message: "Course not found" });
    res.status(200).json({ success: true, data: course });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

module.exports = { getCourses, getCourseById };
