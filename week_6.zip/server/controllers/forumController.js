const ForumPost = require("../models/ForumPost");
const ForumComment = require("../models/ForumComment");
const User = require("../models/User");
const { notify } = require("../utils/notify");

// Week 6: Discussion Forum — course-scoped Q&A threads.

// GET /api/forum/course/:courseId
const getPosts = async (req, res) => {
  try {
    const { courseId } = req.params;
    const posts = await ForumPost.find({ course: courseId })
      .populate("author", "name role")
      .sort({ isPinned: -1, createdAt: -1 });
    res.status(200).json({ success: true, data: posts });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// GET /api/forum/post/:postId
const getPostWithComments = async (req, res) => {
  try {
    const { postId } = req.params;
    const post = await ForumPost.findById(postId).populate("author", "name role");
    if (!post) return res.status(404).json({ success: false, message: "Post not found" });

    const comments = await ForumComment.find({ post: postId })
      .populate("author", "name role")
      .sort({ createdAt: 1 });

    res.status(200).json({ success: true, data: { post, comments } });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// POST /api/forum/course/:courseId  Body: { title, body, tags }
const createPost = async (req, res) => {
  try {
    const { courseId } = req.params;
    const { title, body, tags } = req.body;
    if (!title || !body) {
      return res.status(400).json({ success: false, message: "title and body are required" });
    }

    const post = await ForumPost.create({
      course: courseId,
      author: req.user.id,
      title,
      body,
      tags: Array.isArray(tags) ? tags : [],
    });

    const populated = await post.populate("author", "name role");
    res.status(201).json({ success: true, data: populated });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// POST /api/forum/post/:postId/comments  Body: { body }
const addComment = async (req, res) => {
  try {
    const { postId } = req.params;
    const { body } = req.body;
    if (!body || !body.trim()) {
      return res.status(400).json({ success: false, message: "Comment body is required" });
    }

    const post = await ForumPost.findById(postId);
    if (!post) return res.status(404).json({ success: false, message: "Post not found" });

    const author = await User.findById(req.user.id).select("role name");

    const comment = await ForumComment.create({
      post: postId,
      author: req.user.id,
      body,
      isInstructorReply: author?.role === "instructor",
    });

    post.commentsCount += 1;
    await post.save();

    // Notify the original poster (unless they're replying to themselves).
    if (post.author.toString() !== req.user.id) {
      await notify({
        user: post.author,
        type: "forum",
        title: "New reply to your post",
        message: `${author?.name || "Someone"} replied to "${post.title}"`,
        link: `forum:${postId}`,
      });
    }

    const populated = await comment.populate("author", "name role");
    res.status(201).json({ success: true, data: populated });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// PATCH /api/forum/post/:postId/upvote
const toggleUpvote = async (req, res) => {
  try {
    const { postId } = req.params;
    const post = await ForumPost.findById(postId);
    if (!post) return res.status(404).json({ success: false, message: "Post not found" });

    const alreadyUpvoted = post.upvotes.some((u) => u.toString() === req.user.id);
    if (alreadyUpvoted) {
      post.upvotes = post.upvotes.filter((u) => u.toString() !== req.user.id);
    } else {
      post.upvotes.push(req.user.id);
    }
    await post.save();

    res.status(200).json({ success: true, data: { upvoteCount: post.upvotes.length, upvoted: !alreadyUpvoted } });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// DELETE /api/forum/post/:postId  (author or instructor only)
const deletePost = async (req, res) => {
  try {
    const { postId } = req.params;
    const post = await ForumPost.findById(postId);
    if (!post) return res.status(404).json({ success: false, message: "Post not found" });

    const requester = await User.findById(req.user.id).select("role");
    if (post.author.toString() !== req.user.id && requester?.role !== "instructor" && requester?.role !== "admin") {
      return res.status(403).json({ success: false, message: "Not allowed to delete this post" });
    }

    await ForumComment.deleteMany({ post: postId });
    await post.deleteOne();

    res.status(200).json({ success: true, message: "Post deleted" });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

module.exports = { getPosts, getPostWithComments, createPost, addComment, toggleUpvote, deletePost };
