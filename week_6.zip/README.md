# Weeks 4–5 — Progress Tracking & AI-Based Course Recommendations
## AI Powered Smart E-Learning Web Platform (MERN Stack)

This module implements **Week 4** (Student Progress Tracking) and
**Week 5** (AI-Based Course Recommendation Engine) of the internship
project, built on top of the auth/course backend from Week 2–3.

Jump to: [Week 4](#features-implemented) · [Week 5](#week-5--ai-based-course-recommendation-engine)

## Features implemented

| Feature | Where |
|---|---|
| Student Progress Dashboard | `client/src/components/Dashboard/ProgressDashboard.jsx` |
| Course Completion Percentage | `Progress.completionPercentage`, `CourseCompletionCard.jsx` |
| Lesson Progress Tracking | `Progress.lessonsProgress`, `LessonProgressList.jsx` |
| Quiz Progress Tracking | `Progress.quizzesProgress`, `QuizProgressList.jsx` |
| Activity History | `models/Activity.js`, `ActivityHistory.jsx` |
| Milestone Tracking | `models/Milestone.js`, `utils/milestoneChecker.js`, `MilestoneTracker.jsx` |
| Progress Charts | `ProgressCharts.jsx` (recharts: bar + line charts) |
| Backend APIs | `routes/progressRoutes.js`, `activityRoutes.js`, `milestoneRoutes.js` |
| MongoDB integration | `config/db.js`, Mongoose models |
| React frontend | `client/src` |

## Folder structure

```
week4-elearning-progress/
├── server/
│   ├── config/
│   │   └── db.js                  # MongoDB connection
│   ├── models/
│   │   ├── User.js                # minimal — full version exists from Week 2/3
│   │   ├── Course.js
│   │   ├── Lesson.js
│   │   ├── Quiz.js
│   │   ├── Progress.js            # core Week 4 model
│   │   ├── Activity.js
│   │   └── Milestone.js
│   ├── controllers/
│   │   ├── progressController.js  # dashboard, completion %, lesson/quiz updates, charts
│   │   ├── activityController.js
│   │   └── milestoneController.js
│   ├── routes/
│   │   ├── progressRoutes.js
│   │   ├── activityRoutes.js
│   │   └── milestoneRoutes.js
│   ├── middleware/
│   │   └── auth.js                # JWT protect middleware
│   ├── utils/
│   │   └── milestoneChecker.js    # awards % and quiz-master milestones
│   ├── .env.example
│   ├── package.json
│   └── server.js
└── client/
    ├── public/
    │   └── index.html
    ├── src/
    │   ├── components/
    │   │   ├── common/
    │   │   │   ├── Loader.jsx
    │   │   │   └── ProgressBar.jsx
    │   │   └── Dashboard/
    │   │       ├── ProgressDashboard.jsx   # main screen
    │   │       ├── CourseCompletionCard.jsx
    │   │       ├── LessonProgressList.jsx
    │   │       ├── QuizProgressList.jsx
    │   │       ├── ActivityHistory.jsx
    │   │       ├── MilestoneTracker.jsx
    │   │       └── ProgressCharts.jsx
    │   ├── context/
    │   │   └── AuthContext.jsx     # placeholder, replace with your Week 2/3 version
    │   ├── services/
    │   │   ├── api.js              # axios instance with JWT interceptor
    │   │   └── progressService.js  # API call wrappers
    │   ├── App.jsx
    │   ├── index.js
    │   └── index.css
    └── package.json
```

## Data model summary

- **Progress** — one document per (student, course) enrollment. Holds an
  array of `lessonsProgress` (status per lesson) and `quizzesProgress`
  (attempts/best score/passed per quiz), plus an overall
  `completionPercentage` recalculated on every update.
- **Activity** — an append-only log of everything a student does
  (`course_started`, `lesson_completed`, `quiz_attempted`, `quiz_passed`,
  `course_completed`, `milestone_achieved`). Powers the Activity History feed.
- **Milestone** — awarded automatically at 25% / 50% / 75% / 100% course
  completion, on first quiz pass, and on passing every quiz in a course
  ("Quiz Master"). A unique index prevents duplicate awards.

Completion percentage is a weighted average: 70% from lesson completion,
30% from quiz pass rate (or 100% of whichever exists if a course only has
lessons or only has quizzes).

## API endpoints

All routes below require `Authorization: Bearer <token>`.

| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/progress/dashboard` | Full dashboard: summary stats, all enrolled courses, recent activity |
| GET | `/api/progress/course/:courseId` | Detailed lesson/quiz breakdown for one course |
| POST | `/api/progress/course/:courseId/enroll` | Initialize progress tracking for a course |
| PATCH | `/api/progress/course/:courseId/lesson/:lessonId` | Update lesson status — body: `{ status, timeSpentMinutes }` |
| PATCH | `/api/progress/course/:courseId/quiz/:quizId` | Record a quiz attempt — body: `{ score }` |
| GET | `/api/progress/charts` | Chart-ready data: completion per course, lessons vs quizzes, 30-day activity trend |
| GET | `/api/activity?page=&limit=&courseId=&type=` | Paginated activity history |
| GET | `/api/milestones?courseId=` | List unlocked milestones |

## Installation instructions

### Prerequisites
- Node.js v18+ and npm
- MongoDB running locally (or an Atlas connection string)

### 1. Backend setup

```bash
cd server
npm install
cp .env.example .env
# edit .env and set MONGO_URI, JWT_SECRET, CLIENT_URL
npm run dev
```

The API starts on `http://localhost:5000` (or whatever `PORT` you set).

### 2. Frontend setup

```bash
cd client
npm install
```

Create a `.env` file in `client/` if your API isn't on the default URL:

```
REACT_APP_API_URL=http://localhost:5000/api
```

Then run:

```bash
npm start
```

The dashboard opens at `http://localhost:3000`.

### 3. Try it out

1. Log in via your existing Week 2/3 auth flow so a JWT is saved to
   `localStorage` under the key `token`.
2. Enroll in a course: `POST /api/progress/course/:courseId/enroll`.
3. Mark a lesson complete: `PATCH /api/progress/course/:courseId/lesson/:lessonId`
   with body `{ "status": "completed" }`.
4. Submit a quiz score: `PATCH /api/progress/course/:courseId/quiz/:quizId`
   with body `{ "score": 85 }`.
5. Refresh the dashboard — completion percentage, activity history, and
   any newly unlocked milestones update automatically.

## Notes for integrating into the existing project

- `User.js`, `Course.js`, `Lesson.js`, and `Quiz.js` here are minimal stand-ins.
  If these already exist from Week 1–3, keep your existing versions and just
  add the Week 4 files (`Progress.js`, `Activity.js`, `Milestone.js`,
  controllers, routes, and frontend components).
- Mount the three new route files in your existing `server.js`/`app.js`
  alongside your auth and course routes.
- Swap the placeholder `AuthContext.jsx` for your real one — the dashboard
  only needs a valid JWT in `localStorage` to work.

---

## Week 5 — AI-Based Course Recommendation Engine

A content-based / behavior-based recommendation engine (no external AI
API required) that ranks courses for a student using four signals plus an
overall popularity score.

### Files changed vs. new

**New files:**
```
server/services/recommendationService.js       # scoring + ranking logic
server/controllers/recommendationController.js # 5 endpoints
server/routes/recommendationRoutes.js
client/src/services/recommendationService.js
client/src/components/Recommendations/RecommendedCourses.jsx   # main screen
client/src/components/Recommendations/RecommendedCourseCard.jsx
client/src/components/Recommendations/CategoryFilter.jsx
```

**Existing files modified (additive only — nothing removed, nothing renamed):**
```
server/models/User.js     # added `interests: [String]` field
server/models/Course.js   # added `tags: [String]` field
server/server.js          # added one require + one app.use() for the new routes
client/src/App.jsx        # added <RecommendedCourses /> below the existing dashboard
```
No Week 4 file's existing behavior changes — the Progress/Activity/Milestone
models, controllers, routes, and dashboard UI are untouched.

### How the ranking works

Each candidate course (any course the student isn't already enrolled in) is
scored 0–100 on five signals, then combined with these weights:

| Signal | Weight | Based on |
|---|---|---|
| Interests | 30% | `User.interests` matched against `Course.category` / `Course.tags` |
| Completed courses | 25% | Category frequency among the student's completed courses |
| Enrolled courses | 15% | Category frequency among all courses the student has touched |
| Learning history | 20% | Recency-weighted categories from the `Activity` log (lesson completions, quiz passes weighted higher, older activity decays exponentially) |
| Popularity | 10% | How many students overall are enrolled in each course |

The combined score powers the default `/api/recommendations` endpoint. Each
individual signal is also exposed as its own endpoint for the "recommend by
X" requirements.

### API endpoints

All routes require `Authorization: Bearer <token>` and accept optional
query params `?category=<name>&limit=<n>` (limit defaults to 10, max 50).

| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/recommendations` | Combined smart ranking (all signals + popularity) |
| GET | `/api/recommendations/interests` | Recommend by declared interests only |
| GET | `/api/recommendations/completed` | Recommend by completed-course categories |
| GET | `/api/recommendations/enrolled` | Recommend by currently-enrolled-course categories |
| GET | `/api/recommendations/history` | Recommend by recent learning activity |

Response shape:
```json
{
  "success": true,
  "count": 8,
  "data": [
    {
      "course": { "_id": "...", "title": "...", "category": "...", "tags": ["..."] },
      "score": 62.5,
      "breakdown": {
        "interestScore": 70,
        "completedScore": 40,
        "enrolledScore": 0,
        "historyScore": 55,
        "popularityScore": 20
      }
    }
  ]
}
```
(`breakdown` is only present on the combined `/api/recommendations` endpoint.)

### Setting up data to see recommendations work

1. Add interests to a user: `interests: ["Web Development", "Data Science"]`
   on their `User` document (a future Week could add a `PATCH /api/users/me`
   endpoint for this — not built here to avoid touching the existing user
   routes).
2. Add `tags` to a few `Course` documents, e.g. `tags: ["react", "frontend"]`.
3. Enroll in and complete a course or two via the Week 4 progress endpoints
   so the completed/enrolled/history signals have data to work with.
4. Call `GET /api/recommendations` — you'll see scored, ranked results.

### Frontend

`RecommendedCourses.jsx` renders below the Progress Dashboard in `App.jsx`.
It has five tabs (For You / Interests / Completed / Enrolled / History) and
a category filter dropdown that refetches the active tab with `?category=`.
Each result renders as a `RecommendedCourseCard` showing the match score and
(on the "For You" tab) a breakdown of which signals contributed.
