import { io } from "socket.io-client";

// Week 6: single shared Socket.IO connection for Chat + Live Notifications.
// Reuses the same JWT the axios instance (services/api.js) already attaches
// to REST calls, so no separate login step is needed for real-time features.
const SOCKET_URL = process.env.REACT_APP_SOCKET_URL || "http://localhost:5000";

let socket = null;

export const connectSocket = () => {
  const token = localStorage.getItem("token");
  if (!token) return null;

  if (socket && socket.connected) return socket;

  socket = io(SOCKET_URL, {
    auth: { token },
    transports: ["websocket", "polling"],
  });

  return socket;
};

export const getSocket = () => socket;

export const disconnectSocket = () => {
  if (socket) {
    socket.disconnect();
    socket = null;
  }
};
