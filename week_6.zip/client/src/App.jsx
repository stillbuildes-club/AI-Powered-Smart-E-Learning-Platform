import React, { useState } from "react";
import ProgressDashboard from "./components/Dashboard/ProgressDashboard";
import RecommendedCourses from "./components/Recommendations/RecommendedCourses";
import ChatPage from "./components/Chat/ChatPage";
import ForumPage from "./components/Forum/ForumPage";
import QuizPage from "./components/Quiz/QuizPage";
import AssignmentPage from "./components/Assignments/AssignmentPage";
import NotificationBell from "./components/Notifications/NotificationBell";

// Week 4 rendered the Progress Dashboard directly, and Week 5 added
// Recommended Courses below it. Week 6 adds Chat, Discussion Forum, Live
// Notifications, Interactive Quizzes, and Assignment Submission.
//
// This project doesn't use react-router yet (Weeks 1-5 kept everything on
// one screen), so Week 6 introduces a light, dependency-free tab switcher
// instead of stacking every section on one long page. Swap this for real
// routes (react-router-dom) whenever the rest of the app adopts routing.
const TABS = [
  { key: "dashboard", label: "Dashboard" },
  { key: "recommendations", label: "Recommendations" },
  { key: "chat", label: "Chat" },
  { key: "forum", label: "Forum" },
  { key: "quizzes", label: "Quizzes" },
  { key: "assignments", label: "Assignments" },
];

function App() {
  const [activeTab, setActiveTab] = useState("dashboard");

  return (
    <div className="App">
      <div style={styles.topBar}>
        <div style={styles.tabs}>
          {TABS.map((tab) => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              style={{ ...styles.tabBtn, ...(activeTab === tab.key ? styles.tabBtnActive : {}) }}
            >
              {tab.label}
            </button>
          ))}
        </div>
        <NotificationBell />
      </div>

      {activeTab === "dashboard" && <ProgressDashboard />}
      {activeTab === "recommendations" && <RecommendedCourses />}
      {activeTab === "chat" && <ChatPage />}
      {activeTab === "forum" && <ForumPage />}
      {activeTab === "quizzes" && <QuizPage />}
      {activeTab === "assignments" && <AssignmentPage />}
    </div>
  );
}

const styles = {
  topBar: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    padding: "10px 24px",
    borderBottom: "1px solid #e5e7eb",
    background: "#fff",
    position: "sticky",
    top: 0,
    zIndex: 40,
  },
  tabs: { display: "flex", gap: 4, flexWrap: "wrap" },
  tabBtn: {
    padding: "8px 14px",
    borderRadius: 8,
    border: "none",
    background: "transparent",
    color: "#6b7280",
    fontWeight: 600,
    fontSize: 14,
  },
  tabBtnActive: { background: "#eef2ff", color: "#4f46e5" },
};

export default App;
