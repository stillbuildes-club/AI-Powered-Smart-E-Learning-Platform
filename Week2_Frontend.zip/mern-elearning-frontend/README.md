# Pathwise — Smart E-Learning Platform (Frontend)

React frontend for an **AI-Powered Smart E-Learning Web Platform** built for the
MERN stack — personalized course recommendations, student progress tracking,
and interactive virtual learning. This package is the **frontend only**; it's
built to be dropped in front of an Express/MongoDB API.

## Tech stack

- **React 18** + **Vite** (fast dev server, no CRA)
- **React Router v6** for client-side routing and route protection
- Plain CSS with a shared design-token system (`src/index.css`) — no UI
  framework dependency, easy to restyle
- Mock data + a localStorage-backed `AuthContext` so the whole app runs and
  demos with **zero backend** — see "Connecting to your MERN API" below

## Pages

| Route | Page | Notes |
|---|---|---|
| `/` | Home | Hero, features, featured courses |
| `/login` | Login | Role-aware login (student/instructor/admin) |
| `/signup` | Signup | Account creation with role selection |
| `/courses` | Course Listing | Search, category & level filters, sorting |
| `/courses/:id` | Course Details | Modules, enroll flow |
| `/student-dashboard` | Student Dashboard | Enrollments, live classes, learning path |
| `/instructor-dashboard` | Instructor Dashboard | Course stats, student alerts |
| `/admin-dashboard` | Admin Dashboard | Platform stats, approvals, user table |
| `/progress` | Progress Dashboard | Cross-course progress breakdown |

Dashboard routes are guarded by `ProtectedRoute` — unauthenticated users are
redirected to `/login`, and users are redirected to their own dashboard if
they land on one that doesn't match their role.

## Folder structure

```
mern-elearning-frontend/
├── index.html
├── package.json
├── vite.config.js
├── .env.example
└── src/
    ├── main.jsx                 # App entry, wraps Router + AuthProvider
    ├── App.jsx                  # Route definitions
    ├── index.css                # Design tokens & global styles
    ├── context/
    │   └── AuthContext.jsx      # Mock auth (swap for real API calls)
    ├── data/
    │   └── mockData.js          # Courses, enrollments, stats, etc.
    ├── layouts/
    │   ├── DashboardLayout.jsx  # Shared shell for the 3 dashboards
    │   └── DashboardLayout.css
    ├── components/               # Reusable UI building blocks
    │   ├── Navbar.jsx / .css
    │   ├── Footer.jsx / .css
    │   ├── Button.jsx / .css
    │   ├── FormField.jsx / .css
    │   ├── CourseCard.jsx / .css
    │   ├── ProgressBar.jsx / .css
    │   ├── LearningPath.jsx / .css   # signature checkpoint-trail visual
    │   ├── StatCard.jsx / .css
    │   └── ProtectedRoute.jsx
    └── pages/
        ├── Home.jsx / .css
        ├── Login.jsx, Signup.jsx, Auth.css
        ├── CourseListing.jsx / .css
        ├── CourseDetails.jsx / .css
        ├── StudentDashboard.jsx
        ├── InstructorDashboard.jsx
        ├── AdminDashboard.jsx
        ├── Dashboard.css              # shared dashboard content styles
        ├── ProgressDashboard.jsx / Progress.css
        └── NotFound.jsx
```

## Installation

Requires **Node.js 18+**.

```bash
# 1. Move into the project folder
cd mern-elearning-frontend

# 2. Install dependencies
npm install

# 3. Start the dev server (opens http://localhost:5173)
npm run dev
```

Other scripts:

```bash
npm run build     # production build → dist/
npm run preview   # preview the production build locally
```

## Trying it out

The app runs fully standalone with mock data — no backend needed:

- Go to **Sign up**, pick a role (student / instructor / admin), and submit
  any name/email/password — you'll land on the matching dashboard.
- Browse **Courses**, open a course, and click **Enroll now**.
- Visit **My Progress** to see the cross-course tracking view.

## Connecting to your MERN API

This frontend is intentionally decoupled from any backend so it can be
generated and reviewed on its own. To wire it to a real Express + MongoDB
API:

1. Copy `.env.example` to `.env` and set `VITE_API_URL` to your API's base URL.
2. In `src/context/AuthContext.jsx`, replace the mock bodies of `login()` and
   `signup()` with `fetch` calls to `${import.meta.env.VITE_API_URL}/api/auth/...`,
   store the returned JWT, and attach it as an `Authorization` header on
   subsequent requests (a small `src/api/client.js` helper is a good next
   addition).
3. In `src/data/mockData.js`, replace the exported arrays with data fetched
   from your `/api/courses`, `/api/enrollments`, `/api/users`, etc. endpoints
   — the page components already consume this data by shape, so swapping the
   source (mock array → API response) requires no JSX changes.
4. Add a recommendation endpoint (e.g. `/api/recommendations`) and feed its
   response into the `learningPath` data used by `LearningPath` on the Home
   and Student Dashboard pages for real personalization.

## Responsive design

Every page is built mobile-first with CSS Grid/Flexbox breakpoints at
`980px`, `860px` (nav collapses to a hamburger), and `640px`. Dashboards
collapse their sidebar into a horizontal scroll strip below `900px`.

## Accessibility floor

- Visible focus outlines on all interactive elements
- `prefers-reduced-motion` respected globally
- Form fields use associated `<label>`s; progress bars expose
  `role="progressbar"` with `aria-valuenow`
