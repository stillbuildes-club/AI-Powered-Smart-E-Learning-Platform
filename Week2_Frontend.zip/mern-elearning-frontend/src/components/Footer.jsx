import React from 'react'
import { Link } from 'react-router-dom'
import './Footer.css'

export default function Footer() {
  return (
    <footer className="footer">
      <div className="container footer__inner">
        <div className="footer__brand">
          <span className="footer__mark" aria-hidden="true">◆</span>
          <div>
            <p className="footer__title">Pathwise</p>
            <p className="footer__tag">Learning, charted for you.</p>
          </div>
        </div>

        <div className="footer__cols">
          <div className="footer__col">
            <p className="footer__heading">Platform</p>
            <Link to="/courses">Browse courses</Link>
            <Link to="/signup">Become an instructor</Link>
            <Link to="/progress">Track progress</Link>
          </div>
          <div className="footer__col">
            <p className="footer__heading">Company</p>
            <a href="#about">About</a>
            <a href="#careers">Careers</a>
            <a href="#contact">Contact</a>
          </div>
          <div className="footer__col">
            <p className="footer__heading">Resources</p>
            <a href="#help">Help center</a>
            <a href="#privacy">Privacy policy</a>
            <a href="#terms">Terms of service</a>
          </div>
        </div>
      </div>
      <div className="container footer__bottom">
        <p>© {new Date().getFullYear()} Pathwise. All rights reserved.</p>
        <p className="footer__stack">Built on the MERN stack</p>
      </div>
    </footer>
  )
}
