import React from 'react'
import { Navigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext.jsx'

/**
 * ProtectedRoute — redirects to /login if not authenticated, and to the
 * user's own dashboard if their role doesn't match the required role.
 */
export default function ProtectedRoute({ children, requiredRole }) {
  const { user, loading } = useAuth()

  if (loading) return null

  if (!user) return <Navigate to="/login" replace />

  if (requiredRole && user.role !== requiredRole) {
    const fallback =
      user.role === 'instructor' ? '/instructor-dashboard' :
      user.role === 'admin' ? '/admin-dashboard' : '/student-dashboard'
    return <Navigate to={fallback} replace />
  }

  return children
}
