import React, { useState } from 'react'
import { Link, NavLink, useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext.jsx'
import './Navbar.css'

const dashboardPathForRole = (role) => {
  if (role === 'instructor') return '/instructor-dashboard'
  if (role === 'admin') return '/admin-dashboard'
  return '/student-dashboard'
}

export default function Navbar() {
  const { user, logout } = useAuth()
  const [open, setOpen] = useState(false)
  const navigate = useNavigate()

  const handleLogout = () => {
    logout()
    setOpen(false)
    navigate('/')
  }

  return (
    <header className="navbar">
      <div className="container navbar__inner">
        <Link to="/" className="navbar__brand" onClick={() => setOpen(false)}>
          <span className="navbar__mark" aria-hidden="true">◆</span>
          Pathwise
        </Link>

        <button
          className="navbar__toggle"
          aria-label={open ? 'Close menu' : 'Open menu'}
          aria-expanded={open}
          onClick={() => setOpen((o) => !o)}
        >
          <span />
          <span />
          <span />
        </button>

        <nav className={`navbar__links ${open ? 'is-open' : ''}`}>
          <NavLink to="/" end onClick={() => setOpen(false)}>Home</NavLink>
          <NavLink to="/courses" onClick={() => setOpen(false)}>Courses</NavLink>
          {user && (
            <NavLink to="/progress" onClick={() => setOpen(false)}>My Progress</NavLink>
          )}
          {user && (
            <NavLink to={dashboardPathForRole(user.role)} onClick={() => setOpen(false)}>Dashboard</NavLink>
          )}

          <div className="navbar__auth">
            {user ? (
              <>
                <span className="navbar__user">
                  <span className="navbar__avatar" aria-hidden="true">{user.name.charAt(0).toUpperCase()}</span>
                  {user.name}
                </span>
                <button className="btn btn--ghost btn--sm" onClick={handleLogout}>Log out</button>
              </>
            ) : (
              <>
                <Link to="/login" className="btn btn--ghost btn--sm" onClick={() => setOpen(false)}>Log in</Link>
                <Link to="/signup" className="btn btn--primary btn--sm" onClick={() => setOpen(false)}>Sign up free</Link>
              </>
            )}
          </div>
        </nav>
      </div>
    </header>
  )
}
