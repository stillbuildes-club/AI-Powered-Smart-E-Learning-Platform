import React from 'react'
import './LearningPath.css'

/**
 * LearningPath — the platform's signature visual: a dotted trail of
 * checkpoints representing a learner's personalized sequence of courses.
 * steps: [{ id, label, status: 'done' | 'current' | 'upcoming' }]
 */
export default function LearningPath({ steps, orientation = 'horizontal' }) {
  return (
    <ol className={`learning-path learning-path--${orientation}`}>
      {steps.map((step, i) => (
        <li key={step.id} className={`learning-path__step is-${step.status}`}>
          <span className="learning-path__node" aria-hidden="true">
            {step.status === 'done' ? '✓' : i + 1}
          </span>
          <span className="learning-path__label">{step.label}</span>
          {i < steps.length - 1 && <span className="learning-path__connector" aria-hidden="true" />}
        </li>
      ))}
    </ol>
  )
}
