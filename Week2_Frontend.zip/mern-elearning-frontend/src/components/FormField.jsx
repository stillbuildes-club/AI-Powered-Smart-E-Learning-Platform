import React from 'react'
import './FormField.css'

export default function FormField({ label, id, error, ...inputProps }) {
  return (
    <div className="form-field">
      <label htmlFor={id}>{label}</label>
      <input id={id} className={error ? 'has-error' : ''} {...inputProps} />
      {error && <p className="form-field__error">{error}</p>}
    </div>
  )
}
