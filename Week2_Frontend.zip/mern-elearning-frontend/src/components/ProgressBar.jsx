import React from 'react'
import './ProgressBar.css'

/**
 * ProgressBar — value 0-100.
 * tone: 'moss' (default, growth) | 'amber' | 'flag'
 */
export default function ProgressBar({ value = 0, label, tone = 'moss', showValue = true }) {
  const clamped = Math.max(0, Math.min(100, value))
  return (
    <div className="progress-bar">
      {(label || showValue) && (
        <div className="progress-bar__head">
          {label && <span className="progress-bar__label">{label}</span>}
          {showValue && <span className="progress-bar__value">{clamped}%</span>}
        </div>
      )}
      <div
        className="progress-bar__track"
        role="progressbar"
        aria-valuenow={clamped}
        aria-valuemin={0}
        aria-valuemax={100}
        aria-label={label || 'Progress'}
      >
        <div
          className={`progress-bar__fill progress-bar__fill--${tone}`}
          style={{ width: `${clamped}%` }}
        />
      </div>
    </div>
  )
}
