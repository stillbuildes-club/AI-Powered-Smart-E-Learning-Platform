import React from 'react'
import { Link } from 'react-router-dom'
import './CourseCard.css'

export default function CourseCard({ course }) {
  return (
    <Link to={`/courses/${course.id}`} className="course-card">
      <div className="course-card__fold" aria-hidden="true" />
      <div className="course-card__top">
        <span className="course-card__code">{course.code}</span>
        {course.match >= 85 && (
          <span className="course-card__match">{course.match}% match</span>
        )}
      </div>
      <h3 className="course-card__title">{course.title}</h3>
      <p className="course-card__instructor">{course.instructor}</p>
      <p className="course-card__desc">{course.description}</p>
      <div className="course-card__meta">
        <span>{course.level}</span>
        <span aria-hidden="true">·</span>
        <span>{course.duration}</span>
        <span aria-hidden="true">·</span>
        <span>★ {course.rating}</span>
      </div>
      <div className="course-card__footer">
        <span className="course-card__learners">{course.learners.toLocaleString()} learners</span>
        <span className="course-card__price">${course.price}</span>
      </div>
    </Link>
  )
}
