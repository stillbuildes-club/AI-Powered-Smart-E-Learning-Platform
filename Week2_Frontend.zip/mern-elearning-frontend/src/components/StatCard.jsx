import React from 'react'
import './StatCard.css'

export default function StatCard({ label, value, delta, tone = 'default' }) {
  return (
    <div className="stat-card">
      <p className="stat-card__label">{label}</p>
      <p className="stat-card__value">{value}</p>
      {delta && <p className={`stat-card__delta stat-card__delta--${tone}`}>{delta}</p>}
    </div>
  )
}
