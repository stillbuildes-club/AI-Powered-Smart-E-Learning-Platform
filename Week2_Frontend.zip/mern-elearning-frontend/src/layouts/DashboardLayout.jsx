import React from 'react'
import { NavLink } from 'react-router-dom'
import './DashboardLayout.css'

/**
 * DashboardLayout — shared shell for Student/Instructor/Admin dashboards.
 * items: [{ label, icon, href }]
 */
export default function DashboardLayout({ title, subtitle, items, children }) {
  return (
    <div className="dash">
      <aside className="dash__sidebar">
        <p className="dash__sidebar-heading">Navigate</p>
        <nav className="dash__tabs">
          {items.map((item) => (
            <a key={item.label} href={item.href} className="dash__tab">
              <span aria-hidden="true">{item.icon}</span>
              {item.label}
            </a>
          ))}
        </nav>
      </aside>

      <main className="dash__main">
        <header className="dash__header">
          <div>
            <h1 className="dash__title">{title}</h1>
            {subtitle && <p className="dash__subtitle">{subtitle}</p>}
          </div>
        </header>
        {children}
      </main>
    </div>
  )
}
