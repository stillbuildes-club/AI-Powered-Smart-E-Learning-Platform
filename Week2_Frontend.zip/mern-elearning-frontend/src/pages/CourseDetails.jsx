import React, { useState } from 'react'
import { useParams, Link, useNavigate } from 'react-router-dom'
import { courses } from '../data/mockData.js'
import Button from '../components/Button.jsx'
import { useAuth } from '../context/AuthContext.jsx'
import './CourseDetails.css'

const moduleIcon = { video: '▶', lab: '⚙', project: '★', quiz: '?' }

export default function CourseDetails() {
  const { id } = useParams()
  const navigate = useNavigate()
  const { user } = useAuth()
  const course = courses.find((c) => c.id === id)
  const [enrolled, setEnrolled] = useState(false)

  if (!course) {
    return (
      <div className="container section">
        <h1>Course not found</h1>
        <p>We couldn't find that course.</p>
        <Link to="/courses" className="btn btn--primary btn--md">Back to courses</Link>
      </div>
    )
  }

  const handleEnroll = () => {
    if (!user) {
      navigate('/login', { state: { from: `/courses/${course.id}` } })
      return
    }
    setEnrolled(true)
  }

  return (
    <div className="course-details">
      <div className="course-details__header">
        <div className="container">
          <Link to="/courses" className="course-details__back">← Back to courses</Link>
          <p className="eyebrow">{course.category} · {course.code}</p>
          <h1>{course.title}</h1>
          <p className="course-details__lead">{course.description}</p>
          <div className="course-details__meta">
            <span>By {course.instructor}</span>
            <span aria-hidden="true">·</span>
            <span>{course.level}</span>
            <span aria-hidden="true">·</span>
            <span>{course.duration}</span>
            <span aria-hidden="true">·</span>
            <span>★ {course.rating} ({course.learners.toLocaleString()} learners)</span>
          </div>
        </div>
      </div>

      <div className="container course-details__body">
        <div className="course-details__main">
          <section className="course-details__section">
            <h2>Course content</h2>
            <ul className="module-list">
              {course.modules.map((m, i) => (
                <li key={m.title} className="module-list__item">
                  <span className="module-list__index">{String(i + 1).padStart(2, '0')}</span>
                  <span className="module-list__icon" aria-hidden="true">{moduleIcon[m.type] || '▶'}</span>
                  <span className="module-list__title">{m.title}</span>
                  <span className="module-list__duration">{m.duration}</span>
                </li>
              ))}
            </ul>
          </section>

          <section className="course-details__section">
            <h2>What you'll need</h2>
            <p>A laptop, a free Pathwise account, and roughly {course.duration.replace('weeks', 'weeks of')} 3–5 hours a week. No prior setup required — everything runs in-browser.</p>
          </section>
        </div>

        <aside className="course-details__sidebar">
          <div className="enroll-card">
            <p className="enroll-card__price">${course.price}<span> one-time</span></p>

            {enrolled ? (
              <>
                <p className="enroll-card__success">✓ You're enrolled</p>
                <Button as={Link} to="/student-dashboard" variant="primary" size="lg" style={{ width: '100%' }}>
                  Go to dashboard
                </Button>
              </>
            ) : (
              <Button variant="secondary" size="lg" style={{ width: '100%' }} onClick={handleEnroll}>
                Enroll now
              </Button>
            )}

            <ul className="enroll-card__list">
              <li>{course.modules.length} modules</li>
              <li>Live virtual classroom access</li>
              <li>Progress tracking & certificate</li>
              <li>AI-personalized next steps</li>
            </ul>
          </div>
        </aside>
      </div>
    </div>
  )
}
