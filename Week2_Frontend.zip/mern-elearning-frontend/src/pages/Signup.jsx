import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext.jsx'
import FormField from '../components/FormField.jsx'
import Button from '../components/Button.jsx'
import './Auth.css'

const dashboardPathForRole = (role) => {
  if (role === 'instructor') return '/instructor-dashboard'
  if (role === 'admin') return '/admin-dashboard'
  return '/student-dashboard'
}

export default function Signup() {
  const { signup } = useAuth()
  const navigate = useNavigate()
  const [form, setForm] = useState({ name: '', email: '', password: '', confirm: '', role: 'student' })
  const [error, setError] = useState('')
  const [submitting, setSubmitting] = useState(false)

  const handleChange = (e) => {
    setForm((f) => ({ ...f, [e.target.name]: e.target.value }))
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError('')

    if (form.password !== form.confirm) {
      setError('Passwords do not match.')
      return
    }
    if (form.password.length < 6) {
      setError('Password must be at least 6 characters.')
      return
    }

    setSubmitting(true)
    try {
      const user = await signup(form)
      navigate(dashboardPathForRole(user.role), { replace: true })
    } catch (err) {
      setError(err.message || 'Something went wrong. Please try again.')
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div className="auth-page">
      <div className="auth-card">
        <p className="eyebrow">Get started</p>
        <h1>Create your account</h1>
        <p className="auth-sub">Tell us who you are and we'll build your dashboard around it.</p>

        <form onSubmit={handleSubmit} noValidate>
          <FormField
            label="Full name"
            id="name"
            name="name"
            type="text"
            autoComplete="name"
            placeholder="Jordan Lee"
            value={form.name}
            onChange={handleChange}
            required
          />
          <FormField
            label="Email address"
            id="email"
            name="email"
            type="email"
            autoComplete="email"
            placeholder="you@example.com"
            value={form.email}
            onChange={handleChange}
            required
          />
          <FormField
            label="Password"
            id="password"
            name="password"
            type="password"
            autoComplete="new-password"
            placeholder="At least 6 characters"
            value={form.password}
            onChange={handleChange}
            required
          />
          <FormField
            label="Confirm password"
            id="confirm"
            name="confirm"
            type="password"
            autoComplete="new-password"
            placeholder="Re-enter your password"
            value={form.confirm}
            onChange={handleChange}
            required
          />

          <div className="form-field">
            <label htmlFor="role">I am joining as a</label>
            <select id="role" name="role" value={form.role} onChange={handleChange}>
              <option value="student">Student</option>
              <option value="instructor">Instructor</option>
              <option value="admin">Admin</option>
            </select>
          </div>

          {error && <p className="auth-error" role="alert">{error}</p>}

          <Button type="submit" variant="primary" size="lg" disabled={submitting} style={{ width: '100%' }}>
            {submitting ? 'Creating account…' : 'Create account'}
          </Button>
        </form>

        <p className="auth-switch">
          Already have an account? <Link to="/login">Log in</Link>
        </p>
      </div>
    </div>
  )
}
