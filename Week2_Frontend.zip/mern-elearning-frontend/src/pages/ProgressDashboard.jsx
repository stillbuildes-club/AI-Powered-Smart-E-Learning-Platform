import React from 'react'
import { Link } from 'react-router-dom'
import StatCard from '../components/StatCard.jsx'
import ProgressBar from '../components/ProgressBar.jsx'
import LearningPath from '../components/LearningPath.jsx'
import { courses, studentEnrollments, learningPath } from '../data/mockData.js'
import './Progress.css'

export default function ProgressDashboard() {
  const overall = Math.round(
    studentEnrollments.reduce((sum, e) => sum + e.progress, 0) / studentEnrollments.length
  )

  return (
    <div className="container section progress-page">
      <p className="eyebrow">Progress</p>
      <h1>Your learning, measured</h1>
      <p className="progress-page__lead">
        A single view of how far you've come across every course on your path.
      </p>

      <div className="dash__grid">
        <StatCard label="Overall completion" value={`${overall}%`} />
        <StatCard label="Courses active" value={studentEnrollments.length} />
        <StatCard label="Longest streak" value="12 days" delta="personal best" tone="up" />
        <StatCard label="Certificates" value="2" />
      </div>

      <section className="dash__section">
        <div className="dash__section-head"><h2>Path progress</h2></div>
        <div className="path-panel">
          <LearningPath steps={learningPath} orientation="horizontal" />
        </div>
      </section>

      <section className="dash__section">
        <div className="dash__section-head"><h2>Course-by-course breakdown</h2></div>
        <div className="progress-list">
          {studentEnrollments.map((e) => {
            const c = courses.find((course) => course.id === e.courseId)
            if (!c) return null
            const tone = e.progress >= 75 ? 'moss' : e.progress >= 40 ? 'amber' : 'flag'
            return (
              <div className="progress-item" key={e.courseId}>
                <div className="progress-item__head">
                  <div>
                    <Link to={`/courses/${c.id}`} className="progress-item__title">{c.title}</Link>
                    <p className="progress-item__meta">{c.instructor} · Next up: {e.nextUp}</p>
                  </div>
                  <span className="progress-item__pct">{e.progress}%</span>
                </div>
                <ProgressBar value={e.progress} showValue={false} tone={tone} />
              </div>
            )
          })}
        </div>
      </section>
    </div>
  )
}
