import React from 'react'
import { Link } from 'react-router-dom'
import { courses, learningPath } from '../data/mockData.js'
import CourseCard from '../components/CourseCard.jsx'
import LearningPath from '../components/LearningPath.jsx'
import Button from '../components/Button.jsx'
import './Home.css'

const features = [
  {
    title: 'Personalized recommendations',
    body: 'Our recommendation engine reads your quiz results, pace, and goals to resequence your path after every module.',
    icon: '◇',
  },
  {
    title: 'Progress that tells a story',
    body: 'Every course rolls up into one path, so you always know what you finished, what you\'re on, and what\'s next.',
    icon: '↝',
  },
  {
    title: 'Live virtual classrooms',
    body: 'Join real-time sessions with instructors and peers — ask questions, share your screen, and get unstuck faster.',
    icon: '●',
  },
]

export default function Home() {
  const featured = courses.slice(0, 3)

  return (
    <div className="home">
      <section className="hero">
        <div className="container hero__inner">
          <div className="hero__copy">
            <p className="eyebrow">AI-powered · MERN stack</p>
            <h1>Your learning, charted one checkpoint at a time.</h1>
            <p className="hero__lead">
              Pathwise studies how you learn and rebuilds your course path after every lesson —
              so you're never stuck doing the wrong thing next.
            </p>
            <div className="hero__actions">
              <Button as={Link} to="/signup" variant="secondary" size="lg">Start learning free</Button>
              <Button as={Link} to="/courses" variant="ghost" size="lg">Browse courses</Button>
            </div>
            <div className="hero__proof">
              <span><strong>16,200+</strong> students</span>
              <span><strong>312</strong> courses</span>
              <span><strong>4.8</strong> average rating</span>
            </div>
          </div>

          <div className="hero__path-card">
            <p className="hero__path-heading">A learner's current path</p>
            <LearningPath steps={learningPath} orientation="vertical" />
          </div>
        </div>
      </section>

      <section className="section features">
        <div className="container">
          <p className="eyebrow">Why Pathwise</p>
          <h2>Built around how people actually finish courses</h2>
          <div className="features__grid">
            {features.map((f) => (
              <div className="feature-card" key={f.title}>
                <span className="feature-card__icon" aria-hidden="true">{f.icon}</span>
                <h3>{f.title}</h3>
                <p>{f.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section featured">
        <div className="container">
          <div className="featured__head">
            <div>
              <p className="eyebrow">Recommended this week</p>
              <h2>Popular with learners like you</h2>
            </div>
            <Link to="/courses" className="featured__link">View all courses →</Link>
          </div>
          <div className="featured__grid">
            {featured.map((c) => <CourseCard course={c} key={c.id} />)}
          </div>
        </div>
      </section>

      <section className="section cta">
        <div className="container cta__inner">
          <div>
            <h2>Ready to see your path?</h2>
            <p>Create a free account and get a personalized course sequence in under two minutes.</p>
          </div>
          <Button as={Link} to="/signup" variant="secondary" size="lg">Get started</Button>
        </div>
      </section>
    </div>
  )
}
