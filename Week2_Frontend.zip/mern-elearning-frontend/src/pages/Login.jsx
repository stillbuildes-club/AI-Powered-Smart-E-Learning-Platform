import React, { useState } from 'react'
import { Link, useNavigate, useLocation } from 'react-router-dom'
import { useAuth } from '../context/AuthContext.jsx'
import FormField from '../components/FormField.jsx'
import Button from '../components/Button.jsx'
import './Auth.css'

const dashboardPathForRole = (role) => {
  if (role === 'instructor') return '/instructor-dashboard'
  if (role === 'admin') return '/admin-dashboard'
  return '/student-dashboard'
}

export default function Login() {
  const { login } = useAuth()
  const navigate = useNavigate()
  const location = useLocation()
  const [form, setForm] = useState({ email: '', password: '', role: 'student' })
  const [error, setError] = useState('')
  const [submitting, setSubmitting] = useState(false)

  const handleChange = (e) => {
    setForm((f) => ({ ...f, [e.target.name]: e.target.value }))
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError('')
    setSubmitting(true)
    try {
      const user = await login(form)
      const redirectTo = location.state?.from || dashboardPathForRole(user.role)
      navigate(redirectTo, { replace: true })
    } catch (err) {
      setError(err.message || 'Something went wrong. Please try again.')
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div className="auth-page">
      <div className="auth-card">
        <p className="eyebrow">Welcome back</p>
        <h1>Log in to Pathwise</h1>
        <p className="auth-sub">Pick up your learning path right where you left it.</p>

        <form onSubmit={handleSubmit} noValidate>
          <FormField
            label="Email address"
            id="email"
            name="email"
            type="email"
            autoComplete="email"
            placeholder="you@example.com"
            value={form.email}
            onChange={handleChange}
            required
          />
          <FormField
            label="Password"
            id="password"
            name="password"
            type="password"
            autoComplete="current-password"
            placeholder="••••••••"
            value={form.password}
            onChange={handleChange}
            required
          />

          <div className="form-field">
            <label htmlFor="role">Log in as</label>
            <select id="role" name="role" value={form.role} onChange={handleChange}>
              <option value="student">Student</option>
              <option value="instructor">Instructor</option>
              <option value="admin">Admin</option>
            </select>
          </div>

          {error && <p className="auth-error" role="alert">{error}</p>}

          <Button type="submit" variant="primary" size="lg" disabled={submitting} style={{ width: '100%' }}>
            {submitting ? 'Logging in…' : 'Log in'}
          </Button>
        </form>

        <p className="auth-switch">
          New to Pathwise? <Link to="/signup">Create an account</Link>
        </p>
        <p className="auth-note">Demo mode: any email/password combination works.</p>
      </div>
    </div>
  )
}
