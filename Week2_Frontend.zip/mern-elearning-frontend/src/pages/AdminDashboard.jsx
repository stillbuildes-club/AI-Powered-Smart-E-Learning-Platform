import React from 'react'
import DashboardLayout from '../layouts/DashboardLayout.jsx'
import StatCard from '../components/StatCard.jsx'
import Button from '../components/Button.jsx'
import { platformStats, pendingApprovals, recentUsers } from '../data/mockData.js'
import './Dashboard.css'

const navItems = [
  { label: 'Overview', icon: '◆', href: '#overview' },
  { label: 'Approvals', icon: '✓', href: '#approvals' },
  { label: 'Users', icon: '☰', href: '#users' },
]

const statusBadge = { active: 'active', pending: 'pending', suspended: 'suspended' }

export default function AdminDashboard() {
  return (
    <DashboardLayout
      title="Platform overview"
      subtitle="Monitor growth, moderate content, and manage accounts."
      items={navItems}
    >
      <div id="overview" className="dash__grid">
        <StatCard label="Total users" value={platformStats.totalUsers.toLocaleString()} delta={`↑ ${platformStats.monthlyGrowth}% this month`} tone="up" />
        <StatCard label="Students" value={platformStats.totalStudents.toLocaleString()} />
        <StatCard label="Instructors" value={platformStats.totalInstructors.toLocaleString()} />
        <StatCard label="Courses live" value={platformStats.totalCourses} />
        <StatCard label="Active today" value={platformStats.activeToday.toLocaleString()} />
      </div>

      <section id="approvals" className="dash__section">
        <div className="dash__section-head">
          <h2>Pending approvals</h2>
        </div>
        <table className="data-table">
          <thead>
            <tr>
              <th>Type</th>
              <th>Name</th>
              <th>Submitted by</th>
              <th>Date</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {pendingApprovals.map((p) => (
              <tr key={p.id}>
                <td>{p.type}</td>
                <td>{p.name}</td>
                <td>{p.submitter}</td>
                <td>{p.date}</td>
                <td>
                  <div style={{ display: 'flex', gap: 8 }}>
                    <Button variant="ghost" size="sm">Review</Button>
                    <Button variant="primary" size="sm">Approve</Button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>

      <section id="users" className="dash__section">
        <div className="dash__section-head">
          <h2>Recently joined</h2>
        </div>
        <table className="data-table">
          <thead>
            <tr>
              <th>Name</th>
              <th>Role</th>
              <th>Joined</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {recentUsers.map((u) => (
              <tr key={u.id}>
                <td>{u.name}</td>
                <td>{u.role}</td>
                <td>{u.joined}</td>
                <td><span className={`badge badge--${statusBadge[u.status]}`}>{u.status}</span></td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>
    </DashboardLayout>
  )
}
