import React from 'react'
import DashboardLayout from '../layouts/DashboardLayout.jsx'
import StatCard from '../components/StatCard.jsx'
import ProgressBar from '../components/ProgressBar.jsx'
import { useAuth } from '../context/AuthContext.jsx'
import { instructorCourses, instructorAlerts } from '../data/mockData.js'
import './Dashboard.css'

const navItems = [
  { label: 'Overview', icon: '◆', href: '#overview' },
  { label: 'My Courses', icon: '▤', href: '#courses' },
  { label: 'Student Alerts', icon: '!', href: '#alerts' },
  { label: 'Live Sessions', icon: '●', href: '#live' },
]

export default function InstructorDashboard() {
  const { user } = useAuth()
  const totalStudents = instructorCourses.reduce((sum, c) => sum + c.students, 0)
  const pendingGrading = instructorCourses.reduce((sum, c) => sum + c.pendingGrading, 0)

  return (
    <DashboardLayout
      title={`Instructor console, ${user?.name || ''}`}
      subtitle="Track how your courses are landing with students."
      items={navItems}
    >
      <div id="overview" className="dash__grid">
        <StatCard label="Total students" value={totalStudents.toLocaleString()} />
        <StatCard label="Active courses" value={instructorCourses.length} />
        <StatCard label="Pending grading" value={pendingGrading} tone="down" delta="needs review" />
        <StatCard label="Avg. rating" value="4.85" delta="↑ 0.1 this month" tone="up" />
      </div>

      <section id="courses" className="dash__section">
        <div className="dash__section-head">
          <h2>Your courses</h2>
        </div>
        <div className="enrolled-list">
          {instructorCourses.map((c) => (
            <div className="enrolled-card" key={c.id}>
              <div className="enrolled-card__info">
                <p className="enrolled-card__title">{c.title}</p>
                <p className="enrolled-card__meta">
                  {c.students.toLocaleString()} students · ★ {c.rating} · {c.pendingGrading} submissions to grade
                </p>
              </div>
              <div className="enrolled-card__progress">
                <ProgressBar value={c.completion} showValue={false} tone="amber" />
                <span>{c.completion}%</span>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section id="alerts" className="dash__section">
        <div className="dash__section-head">
          <h2>Student alerts</h2>
        </div>
        <div className="alert-list">
          {instructorAlerts.map((a) => (
            <div className={`alert-card level-${a.level}`} key={a.id}>
              <div>
                <span className="alert-card__student">{a.student}</span>{' '}
                <span className="alert-card__course">· {a.course}</span>
                <p className="alert-card__note">{a.note}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section id="live" className="dash__section">
        <div className="dash__section-head">
          <h2>Your next live session</h2>
        </div>
        <div className="live-card">
          <span className="live-card__dot" aria-hidden="true" />
          <div className="live-card__info">
            <p className="live-card__title">Live Q&amp;A: Debugging React Hooks</p>
            <p className="live-card__meta">Today · 6:00 PM · 42 registered</p>
          </div>
        </div>
      </section>
    </DashboardLayout>
  )
}
