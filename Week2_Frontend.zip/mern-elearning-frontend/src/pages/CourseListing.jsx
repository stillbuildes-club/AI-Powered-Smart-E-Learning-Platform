import React, { useMemo, useState } from 'react'
import { courses, categories } from '../data/mockData.js'
import CourseCard from '../components/CourseCard.jsx'
import './CourseListing.css'

const levels = ['All', 'Beginner', 'Intermediate', 'Advanced']

export default function CourseListing() {
  const [query, setQuery] = useState('')
  const [category, setCategory] = useState('All')
  const [level, setLevel] = useState('All')
  const [sort, setSort] = useState('match')

  const filtered = useMemo(() => {
    let list = courses.filter((c) => {
      const matchesQuery =
        c.title.toLowerCase().includes(query.toLowerCase()) ||
        c.instructor.toLowerCase().includes(query.toLowerCase())
      const matchesCategory = category === 'All' || c.category === category
      const matchesLevel = level === 'All' || c.level === level
      return matchesQuery && matchesCategory && matchesLevel
    })

    if (sort === 'match') list = [...list].sort((a, b) => b.match - a.match)
    if (sort === 'rating') list = [...list].sort((a, b) => b.rating - a.rating)
    if (sort === 'popular') list = [...list].sort((a, b) => b.learners - a.learners)

    return list
  }, [query, category, level, sort])

  return (
    <div className="listing">
      <div className="listing__header">
        <div className="container">
          <p className="eyebrow">Course catalog</p>
          <h1>Find your next course</h1>
          <p className="listing__lead">Filter by category and level, or search for an instructor or topic.</p>

          <div className="listing__controls">
            <input
              type="search"
              placeholder="Search courses or instructors…"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="listing__search"
              aria-label="Search courses"
            />
            <select value={category} onChange={(e) => setCategory(e.target.value)} aria-label="Filter by category">
              {categories.map((c) => <option key={c} value={c}>{c}</option>)}
            </select>
            <select value={level} onChange={(e) => setLevel(e.target.value)} aria-label="Filter by level">
              {levels.map((l) => <option key={l} value={l}>{l}</option>)}
            </select>
            <select value={sort} onChange={(e) => setSort(e.target.value)} aria-label="Sort courses">
              <option value="match">Best match</option>
              <option value="rating">Highest rated</option>
              <option value="popular">Most popular</option>
            </select>
          </div>
        </div>
      </div>

      <div className="container section">
        <p className="listing__count">{filtered.length} course{filtered.length !== 1 ? 's' : ''} found</p>

        {filtered.length > 0 ? (
          <div className="listing__grid">
            {filtered.map((c) => <CourseCard course={c} key={c.id} />)}
          </div>
        ) : (
          <div className="listing__empty">
            <p>No courses match those filters yet.</p>
            <p className="listing__empty-sub">Try a different category, level, or search term.</p>
          </div>
        )}
      </div>
    </div>
  )
}
