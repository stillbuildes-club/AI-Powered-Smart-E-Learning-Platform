import React from 'react'
import { Link } from 'react-router-dom'
import DashboardLayout from '../layouts/DashboardLayout.jsx'
import StatCard from '../components/StatCard.jsx'
import ProgressBar from '../components/ProgressBar.jsx'
import LearningPath from '../components/LearningPath.jsx'
import { useAuth } from '../context/AuthContext.jsx'
import { courses, studentEnrollments, upcomingLiveClasses, learningPath } from '../data/mockData.js'
import './Dashboard.css'

const navItems = [
  { label: 'Overview', icon: '◆', href: '#overview' },
  { label: 'My Courses', icon: '▤', href: '#courses' },
  { label: 'Live Classes', icon: '●', href: '#live' },
  { label: 'My Path', icon: '↝', href: '#path' },
  { label: 'Progress', icon: '▲', href: '/progress' },
]

export default function StudentDashboard() {
  const { user } = useAuth()

  return (
    <DashboardLayout
      title={`Welcome back, ${user?.name || 'learner'}`}
      subtitle="Here's where your path stands today."
      items={navItems}
    >
      <div id="overview" className="dash__grid">
        <StatCard label="Courses in progress" value={studentEnrollments.length} />
        <StatCard label="Avg. completion" value="60%" delta="↑ 8% this week" tone="up" />
        <StatCard label="Hours learned" value="34.5" delta="this month" tone="default" />
        <StatCard label="Certificates earned" value="2" />
      </div>

      <section id="courses" className="dash__section">
        <div className="dash__section-head">
          <h2>Continue learning</h2>
          <Link to="/courses" className="dash__section-link">Browse more courses →</Link>
        </div>
        <div className="enrolled-list">
          {studentEnrollments.map((e) => {
            const c = courses.find((course) => course.id === e.courseId)
            if (!c) return null
            return (
              <Link to={`/courses/${c.id}`} className="enrolled-card" key={e.courseId}>
                <div className="enrolled-card__info">
                  <p className="enrolled-card__title">{c.title}</p>
                  <p className="enrolled-card__meta">Next: {e.nextUp} · Active {e.lastActivity}</p>
                </div>
                <div className="enrolled-card__progress">
                  <ProgressBar value={e.progress} showValue={false} />
                  <span>{e.progress}%</span>
                </div>
              </Link>
            )
          })}
        </div>
      </section>

      <section id="live" className="dash__section">
        <div className="dash__section-head">
          <h2>Upcoming live classes</h2>
        </div>
        <div className="live-list">
          {upcomingLiveClasses.map((lc) => (
            <div className="live-card" key={lc.id}>
              <span className="live-card__dot" aria-hidden="true" />
              <div className="live-card__info">
                <p className="live-card__title">{lc.title}</p>
                <p className="live-card__meta">{lc.instructor} · {lc.time}</p>
              </div>
              <span className="live-card__seats">{lc.seats} seats left</span>
            </div>
          ))}
        </div>
      </section>

      <section id="path" className="dash__section">
        <div className="dash__section-head">
          <h2>Your personalized path</h2>
        </div>
        <div className="path-panel">
          <LearningPath steps={learningPath} orientation="horizontal" />
        </div>
      </section>
    </DashboardLayout>
  )
}
