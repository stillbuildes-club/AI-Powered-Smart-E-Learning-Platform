import React from 'react'
import { Link } from 'react-router-dom'

export default function NotFound() {
  return (
    <div className="container section" style={{ textAlign: 'center', padding: '100px 24px' }}>
      <p className="eyebrow">404</p>
      <h1>This page isn't on your path</h1>
      <p style={{ maxWidth: 420, margin: '0 auto 24px' }}>
        The page you're looking for doesn't exist or may have moved.
      </p>
      <Link to="/" className="btn btn--primary btn--md">Back to home</Link>
    </div>
  )
}
