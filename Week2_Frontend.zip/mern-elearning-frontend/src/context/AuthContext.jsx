import React, { createContext, useContext, useEffect, useState } from 'react'

const AuthContext = createContext(null)

const STORAGE_KEY = 'pathwise_auth_user'

/**
 * AuthProvider — currently backed by localStorage mock data so the whole
 * frontend is runnable and demo-able with zero backend.
 *
 * To wire to the real MERN API:
 *   1. Replace login()/signup() bodies with fetch() calls to
 *      `${import.meta.env.VITE_API_URL}/api/auth/login` etc.
 *   2. Store the JWT returned by the API instead of the mock user object.
 *   3. Attach the token as an Authorization header in a shared api client.
 */
export function AuthProvider({ children }) {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const stored = localStorage.getItem(STORAGE_KEY)
    if (stored) {
      try { setUser(JSON.parse(stored)) } catch { /* ignore corrupt value */ }
    }
    setLoading(false)
  }, [])

  const login = async ({ email, password, role }) => {
    // MOCK — replace with: const res = await fetch(`${API}/auth/login`, {...})
    if (!email || !password) throw new Error('Email and password are required.')
    const mockUser = {
      id: 'u_' + Math.random().toString(36).slice(2, 9),
      name: email.split('@')[0].replace(/[._]/g, ' '),
      email,
      role: role || 'student',
    }
    localStorage.setItem(STORAGE_KEY, JSON.stringify(mockUser))
    setUser(mockUser)
    return mockUser
  }

  const signup = async ({ name, email, password, role }) => {
    // MOCK — replace with: const res = await fetch(`${API}/auth/signup`, {...})
    if (!name || !email || !password) throw new Error('All fields are required.')
    const mockUser = {
      id: 'u_' + Math.random().toString(36).slice(2, 9),
      name,
      email,
      role: role || 'student',
    }
    localStorage.setItem(STORAGE_KEY, JSON.stringify(mockUser))
    setUser(mockUser)
    return mockUser
  }

  const logout = () => {
    localStorage.removeItem(STORAGE_KEY)
    setUser(null)
  }

  return (
    <AuthContext.Provider value={{ user, loading, login, signup, logout }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be used within an AuthProvider')
  return ctx
}
