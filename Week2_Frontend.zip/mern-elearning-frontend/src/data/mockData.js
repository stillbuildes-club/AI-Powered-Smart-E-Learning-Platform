export const courses = [
  {
    id: 'c1',
    code: 'AI-201',
    title: 'Machine Learning Foundations',
    instructor: 'Dr. Rina Kapoor',
    category: 'Artificial Intelligence',
    level: 'Intermediate',
    duration: '6 weeks',
    rating: 4.8,
    learners: 2140,
    match: 96,
    price: 49,
    description:
      'Build intuition for supervised and unsupervised learning, then implement your first models in Python. Ends with a capstone that feeds your Pathwise portfolio.',
    modules: [
      { title: 'Why machines learn', duration: '45 min', type: 'video' },
      { title: 'Regression from scratch', duration: '1 hr 10 min', type: 'video' },
      { title: 'Classification lab', duration: '1 hr', type: 'lab' },
      { title: 'Model evaluation', duration: '40 min', type: 'video' },
      { title: 'Capstone: predict student outcomes', duration: '2 hr', type: 'project' },
    ],
  },
  {
    id: 'c2',
    code: 'WD-110',
    title: 'Full-Stack Web Development with MERN',
    instructor: 'Jonah Fields',
    category: 'Web Development',
    level: 'Beginner',
    duration: '8 weeks',
    rating: 4.9,
    learners: 5310,
    match: 88,
    price: 59,
    description:
      'Go from a static HTML page to a deployed MongoDB, Express, React, Node application, learning the "why" behind each layer of the stack.',
    modules: [
      { title: 'Setting up the stack', duration: '30 min', type: 'video' },
      { title: 'Express APIs & routing', duration: '1 hr 20 min', type: 'video' },
      { title: 'MongoDB data modeling', duration: '1 hr', type: 'lab' },
      { title: 'React front end', duration: '1 hr 30 min', type: 'video' },
      { title: 'Deploy your app', duration: '50 min', type: 'project' },
    ],
  },
  {
    id: 'c3',
    code: 'DS-305',
    title: 'Data Structures & Algorithms in Practice',
    instructor: 'Prof. Amaka Obi',
    category: 'Computer Science',
    level: 'Advanced',
    duration: '10 weeks',
    rating: 4.7,
    learners: 3421,
    match: 74,
    price: 65,
    description:
      'Sharpen problem-solving for technical interviews with trees, graphs, and dynamic programming — reinforced by weekly timed drills.',
    modules: [
      { title: 'Big-O and complexity', duration: '35 min', type: 'video' },
      { title: 'Trees & graphs', duration: '1 hr 15 min', type: 'video' },
      { title: 'Dynamic programming lab', duration: '1 hr 30 min', type: 'lab' },
      { title: 'Timed interview drill', duration: '45 min', type: 'quiz' },
    ],
  },
  {
    id: 'c4',
    code: 'UX-140',
    title: 'UX Design for Digital Products',
    instructor: 'Lena Ortiz',
    category: 'Design',
    level: 'Beginner',
    duration: '5 weeks',
    rating: 4.6,
    learners: 1876,
    match: 65,
    price: 39,
    description:
      'Learn user research, wireframing, and prototyping through a real product brief, critiqued live by working designers.',
    modules: [
      { title: 'Research & personas', duration: '40 min', type: 'video' },
      { title: 'Wireframing sprint', duration: '1 hr', type: 'lab' },
      { title: 'Prototype & test', duration: '1 hr 10 min', type: 'project' },
    ],
  },
  {
    id: 'c5',
    code: 'AI-330',
    title: 'Natural Language Processing with Transformers',
    instructor: 'Dr. Rina Kapoor',
    category: 'Artificial Intelligence',
    level: 'Advanced',
    duration: '7 weeks',
    rating: 4.9,
    learners: 1502,
    match: 91,
    price: 69,
    description:
      'Understand attention and transformer architectures, then fine-tune a language model for a classification task of your choice.',
    modules: [
      { title: 'Tokens & embeddings', duration: '50 min', type: 'video' },
      { title: 'Attention mechanisms', duration: '1 hr', type: 'video' },
      { title: 'Fine-tuning lab', duration: '1 hr 30 min', type: 'lab' },
      { title: 'Capstone project', duration: '2 hr', type: 'project' },
    ],
  },
  {
    id: 'c6',
    code: 'CLD-220',
    title: 'Cloud Infrastructure Essentials',
    instructor: 'Marcus Whitfield',
    category: 'Cloud Computing',
    level: 'Intermediate',
    duration: '6 weeks',
    rating: 4.5,
    learners: 987,
    match: 58,
    price: 55,
    description:
      'Provision, scale, and monitor infrastructure across major cloud providers, with a focus on cost-aware architecture decisions.',
    modules: [
      { title: 'Compute & storage basics', duration: '40 min', type: 'video' },
      { title: 'Networking lab', duration: '1 hr', type: 'lab' },
      { title: 'Monitoring & alerts', duration: '45 min', type: 'video' },
    ],
  },
]

export const categories = [
  'All',
  'Artificial Intelligence',
  'Web Development',
  'Computer Science',
  'Design',
  'Cloud Computing',
]

// A learner's current path — used by the signature "learning path" component
export const learningPath = [
  { id: 'p1', label: 'HTML & CSS Basics', status: 'done' },
  { id: 'p2', label: 'JavaScript Essentials', status: 'done' },
  { id: 'p3', label: 'Full-Stack MERN', status: 'current' },
  { id: 'p4', label: 'ML Foundations', status: 'upcoming' },
  { id: 'p5', label: 'NLP with Transformers', status: 'upcoming' },
]

export const studentEnrollments = [
  { courseId: 'c2', progress: 62, lastActivity: '2 hours ago', nextUp: 'React front end' },
  { courseId: 'c1', progress: 28, lastActivity: 'Yesterday', nextUp: 'Classification lab' },
  { courseId: 'c3', progress: 90, lastActivity: '3 days ago', nextUp: 'Timed interview drill' },
]

export const upcomingLiveClasses = [
  { id: 'lc1', title: 'Live Q&A: Debugging React Hooks', instructor: 'Jonah Fields', time: 'Today · 6:00 PM', seats: 42 },
  { id: 'lc2', title: 'Workshop: Prompting for ML Feature Design', instructor: 'Dr. Rina Kapoor', time: 'Tomorrow · 11:00 AM', seats: 18 },
  { id: 'lc3', title: 'Mock Interview Circle', instructor: 'Prof. Amaka Obi', time: 'Fri · 4:30 PM', seats: 9 },
]

export const instructorCourses = [
  { id: 'c1', title: 'Machine Learning Foundations', students: 2140, completion: 68, rating: 4.8, pendingGrading: 12 },
  { id: 'c5', title: 'Natural Language Processing with Transformers', students: 1502, completion: 54, rating: 4.9, pendingGrading: 7 },
]

export const instructorAlerts = [
  { id: 'a1', student: 'Meera S.', course: 'ML Foundations', note: 'No activity in 9 days — flagged as at-risk', level: 'warning' },
  { id: 'a2', student: 'Tomás R.', course: 'NLP with Transformers', note: 'Scored 98% on capstone draft', level: 'success' },
  { id: 'a3', student: 'Priya D.', course: 'ML Foundations', note: 'Asked a question awaiting reply', level: 'info' },
]

export const platformStats = {
  totalUsers: 18420,
  totalStudents: 16210,
  totalInstructors: 640,
  totalCourses: 312,
  activeToday: 3980,
  monthlyGrowth: 7.4,
}

export const pendingApprovals = [
  { id: 'pa1', type: 'Course', name: 'Ethical Hacking Fundamentals', submitter: 'Owen Vance', date: 'Jul 15' },
  { id: 'pa2', type: 'Instructor', name: 'Dana Whitcombe', submitter: 'Application', date: 'Jul 14' },
  { id: 'pa3', type: 'Course', name: 'Product Analytics with SQL', submitter: 'Priya Nandakumar', date: 'Jul 13' },
]

export const recentUsers = [
  { id: 'u1', name: 'Meera Suresh', role: 'Student', joined: 'Jul 16', status: 'active' },
  { id: 'u2', name: 'Owen Vance', role: 'Instructor', joined: 'Jul 15', status: 'active' },
  { id: 'u3', name: 'Kofi Boateng', role: 'Student', joined: 'Jul 15', status: 'suspended' },
  { id: 'u4', name: 'Dana Whitcombe', role: 'Instructor', joined: 'Jul 14', status: 'pending' },
]
