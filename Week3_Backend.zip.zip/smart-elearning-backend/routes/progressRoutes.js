const express = require("express");
const {
  getCourseProgress,
  getMyProgress,
  markLessonComplete,
  getAllProgressForCourse,
} = require("../controllers/progressController");
const { protect, authorize } = require("../middleware/authMiddleware");

const router = express.Router();

router.get("/me", protect, authorize("student"), getMyProgress);
router.get(
  "/course/:courseId",
  protect,
  authorize("student"),
  getCourseProgress
);
router.put(
  "/course/:courseId/lesson/:lessonId",
  protect,
  authorize("student"),
  markLessonComplete
);
router.get(
  "/course/:courseId/all",
  protect,
  authorize("instructor", "admin"),
  getAllProgressForCourse
);

module.exports = router;
