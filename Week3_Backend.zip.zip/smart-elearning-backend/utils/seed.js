// Optional helper script: populates the database with sample data for quick testing.
// Run with: npm run seed
const dotenv = require("dotenv");
dotenv.config();

const connectDB = require("../config/db");
const User = require("../models/User");
const Course = require("../models/Course");

const run = async () => {
  await connectDB();

  console.log("Clearing existing sample data...");
  await User.deleteMany({ email: { $in: ["admin@example.com", "instructor@example.com", "student@example.com"] } });
  await Course.deleteMany({ title: "Introduction to MERN Stack" });

  console.log("Creating sample users...");
  const admin = await User.create({
    name: "Admin User",
    email: "admin@example.com",
    password: "Password123",
    role: "admin",
  });

  const instructor = await User.create({
    name: "Instructor User",
    email: "instructor@example.com",
    password: "Password123",
    role: "instructor",
  });

  const student = await User.create({
    name: "Student User",
    email: "student@example.com",
    password: "Password123",
    role: "student",
    interests: ["web development", "javascript"],
  });

  console.log("Creating sample course...");
  const course = await Course.create({
    title: "Introduction to MERN Stack",
    description: "Learn the fundamentals of MongoDB, Express, React, and Node.js",
    category: "Web Development",
    tags: ["mern", "javascript", "fullstack"],
    difficulty: "beginner",
    instructor: instructor._id,
    lessons: [
      { title: "Setting up Node.js and Express", duration: 20 },
      { title: "Connecting to MongoDB with Mongoose", duration: 25 },
      { title: "Building REST APIs", duration: 30 },
    ],
  });

  console.log("\nSeed complete. Sample credentials (all passwords: Password123):");
  console.log(`Admin:      admin@example.com`);
  console.log(`Instructor: instructor@example.com`);
  console.log(`Student:    student@example.com`);
  console.log(`Course ID:  ${course._id}`);

  process.exit(0);
};

run().catch((err) => {
  console.error(err);
  process.exit(1);
});
