const asyncHandler = require("express-async-handler");
const User = require("../models/User");

// @desc    Get all users (with optional role filter & pagination)
// @route   GET /api/users?role=student&page=1&limit=10
// @access  Private/Admin
const getUsers = asyncHandler(async (req, res) => {
  const { role, page = 1, limit = 10 } = req.query;

  const filter = {};
  if (role) filter.role = role;

  const users = await User.find(filter)
    .limit(Number(limit))
    .skip((Number(page) - 1) * Number(limit))
    .sort({ createdAt: -1 });

  const total = await User.countDocuments(filter);

  res.status(200).json({
    success: true,
    count: users.length,
    total,
    page: Number(page),
    pages: Math.ceil(total / Number(limit)),
    users,
  });
});

// @desc    Get single user by ID
// @route   GET /api/users/:id
// @access  Private/Admin
const getUserById = asyncHandler(async (req, res) => {
  const user = await User.findById(req.params.id);
  if (!user) {
    res.status(404);
    throw new Error("User not found");
  }
  res.status(200).json({ success: true, user });
});

// @desc    Update logged-in user's own profile
// @route   PUT /api/users/profile
// @access  Private
const updateMyProfile = asyncHandler(async (req, res) => {
  const { name, interests } = req.body;

  const user = await User.findById(req.user._id);
  if (!user) {
    res.status(404);
    throw new Error("User not found");
  }

  if (name) user.name = name;
  if (interests) user.interests = interests;

  const updatedUser = await user.save();

  res.status(200).json({
    success: true,
    user: {
      id: updatedUser._id,
      name: updatedUser.name,
      email: updatedUser.email,
      role: updatedUser.role,
      interests: updatedUser.interests,
    },
  });
});

// @desc    Update any user by ID (role, active status, etc.)
// @route   PUT /api/users/:id
// @access  Private/Admin
const updateUser = asyncHandler(async (req, res) => {
  const { name, role, isActive, interests } = req.body;

  const user = await User.findById(req.params.id);
  if (!user) {
    res.status(404);
    throw new Error("User not found");
  }

  if (name) user.name = name;
  if (role) user.role = role;
  if (typeof isActive === "boolean") user.isActive = isActive;
  if (interests) user.interests = interests;

  const updatedUser = await user.save();
  res.status(200).json({ success: true, user: updatedUser });
});

// @desc    Delete a user
// @route   DELETE /api/users/:id
// @access  Private/Admin
const deleteUser = asyncHandler(async (req, res) => {
  const user = await User.findById(req.params.id);
  if (!user) {
    res.status(404);
    throw new Error("User not found");
  }

  await user.deleteOne();
  res.status(200).json({ success: true, message: "User deleted successfully" });
});

module.exports = {
  getUsers,
  getUserById,
  updateMyProfile,
  updateUser,
  deleteUser,
};
