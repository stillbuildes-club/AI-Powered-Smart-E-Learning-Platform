const asyncHandler = require("express-async-handler");
const Course = require("../models/Course");
const User = require("../models/User");

// @desc    Create a new course
// @route   POST /api/courses
// @access  Private/Instructor,Admin
const createCourse = asyncHandler(async (req, res) => {
  const { title, description, category, tags, difficulty, lessons, thumbnail } =
    req.body;

  if (!title || !description || !category) {
    res.status(400);
    throw new Error("Title, description, and category are required");
  }

  const course = await Course.create({
    title,
    description,
    category,
    tags,
    difficulty,
    lessons,
    thumbnail,
    instructor: req.user._id,
  });

  res.status(201).json({ success: true, course });
});

// @desc    Get all courses (search, filter by category/difficulty, pagination)
// @route   GET /api/courses?category=web&difficulty=beginner&search=react&page=1&limit=10
// @access  Public
const getCourses = asyncHandler(async (req, res) => {
  const { category, difficulty, search, page = 1, limit = 10 } = req.query;

  const filter = { isPublished: true };
  if (category) filter.category = category;
  if (difficulty) filter.difficulty = difficulty;
  if (search) {
    filter.$or = [
      { title: { $regex: search, $options: "i" } },
      { description: { $regex: search, $options: "i" } },
      { tags: { $regex: search, $options: "i" } },
    ];
  }

  const courses = await Course.find(filter)
    .populate("instructor", "name email")
    .limit(Number(limit))
    .skip((Number(page) - 1) * Number(limit))
    .sort({ createdAt: -1 });

  const total = await Course.countDocuments(filter);

  res.status(200).json({
    success: true,
    count: courses.length,
    total,
    page: Number(page),
    pages: Math.ceil(total / Number(limit)),
    courses,
  });
});

// @desc    Get single course by ID
// @route   GET /api/courses/:id
// @access  Public
const getCourseById = asyncHandler(async (req, res) => {
  const course = await Course.findById(req.params.id).populate(
    "instructor",
    "name email"
  );

  if (!course) {
    res.status(404);
    throw new Error("Course not found");
  }

  res.status(200).json({ success: true, course });
});

// @desc    Update a course
// @route   PUT /api/courses/:id
// @access  Private/Instructor(owner),Admin
const updateCourse = asyncHandler(async (req, res) => {
  const course = await Course.findById(req.params.id);

  if (!course) {
    res.status(404);
    throw new Error("Course not found");
  }

  const isOwner = course.instructor.toString() === req.user._id.toString();
  if (!isOwner && req.user.role !== "admin") {
    res.status(403);
    throw new Error("Not authorized to update this course");
  }

  Object.assign(course, req.body);
  const updatedCourse = await course.save();

  res.status(200).json({ success: true, course: updatedCourse });
});

// @desc    Delete a course
// @route   DELETE /api/courses/:id
// @access  Private/Instructor(owner),Admin
const deleteCourse = asyncHandler(async (req, res) => {
  const course = await Course.findById(req.params.id);

  if (!course) {
    res.status(404);
    throw new Error("Course not found");
  }

  const isOwner = course.instructor.toString() === req.user._id.toString();
  if (!isOwner && req.user.role !== "admin") {
    res.status(403);
    throw new Error("Not authorized to delete this course");
  }

  await course.deleteOne();
  res.status(200).json({ success: true, message: "Course deleted successfully" });
});

// @desc    Enroll the logged-in student in a course
// @route   POST /api/courses/:id/enroll
// @access  Private/Student
const enrollInCourse = asyncHandler(async (req, res) => {
  const course = await Course.findById(req.params.id);
  if (!course) {
    res.status(404);
    throw new Error("Course not found");
  }

  const user = await User.findById(req.user._id);

  const alreadyEnrolled = user.enrolledCourses.some(
    (id) => id.toString() === course._id.toString()
  );

  if (alreadyEnrolled) {
    res.status(400);
    throw new Error("Already enrolled in this course");
  }

  user.enrolledCourses.push(course._id);
  await user.save();

  res.status(200).json({
    success: true,
    message: "Enrolled successfully",
    enrolledCourses: user.enrolledCourses,
  });
});

module.exports = {
  createCourse,
  getCourses,
  getCourseById,
  updateCourse,
  deleteCourse,
  enrollInCourse,
};
