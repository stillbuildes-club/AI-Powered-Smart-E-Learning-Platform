const asyncHandler = require("express-async-handler");
const Progress = require("../models/Progress");
const Course = require("../models/Course");

// Helper: recompute percentage & status from completed lessons vs total lessons
const recompute = (progressDoc, totalLessons) => {
  const completedCount = progressDoc.completedLessons.length;
  const percent =
    totalLessons > 0 ? Math.round((completedCount / totalLessons) * 100) : 0;

  progressDoc.progressPercent = percent;

  if (percent === 0) progressDoc.status = "not-started";
  else if (percent >= 100) progressDoc.status = "completed";
  else progressDoc.status = "in-progress";
};

// @desc    Get or initialize a student's progress for a specific course
// @route   GET /api/progress/course/:courseId
// @access  Private/Student
const getCourseProgress = asyncHandler(async (req, res) => {
  const { courseId } = req.params;

  const course = await Course.findById(courseId);
  if (!course) {
    res.status(404);
    throw new Error("Course not found");
  }

  let progress = await Progress.findOne({
    student: req.user._id,
    course: courseId,
  });

  if (!progress) {
    progress = await Progress.create({
      student: req.user._id,
      course: courseId,
      completedLessons: [],
    });
  }

  res.status(200).json({ success: true, progress });
});

// @desc    Get all progress records for the logged-in student (dashboard view)
// @route   GET /api/progress/me
// @access  Private/Student
const getMyProgress = asyncHandler(async (req, res) => {
  const progressList = await Progress.find({ student: req.user._id }).populate(
    "course",
    "title category difficulty"
  );

  res.status(200).json({
    success: true,
    count: progressList.length,
    progress: progressList,
  });
});

// @desc    Mark a lesson as completed, updating percent/status automatically
// @route   PUT /api/progress/course/:courseId/lesson/:lessonId
// @access  Private/Student
const markLessonComplete = asyncHandler(async (req, res) => {
  const { courseId, lessonId } = req.params;

  const course = await Course.findById(courseId);
  if (!course) {
    res.status(404);
    throw new Error("Course not found");
  }

  const lessonExists = course.lessons.some(
    (lesson) => lesson._id.toString() === lessonId
  );
  if (!lessonExists) {
    res.status(404);
    throw new Error("Lesson not found in this course");
  }

  let progress = await Progress.findOne({
    student: req.user._id,
    course: courseId,
  });

  if (!progress) {
    progress = new Progress({
      student: req.user._id,
      course: courseId,
      completedLessons: [],
    });
  }

  const alreadyCompleted = progress.completedLessons.some(
    (id) => id.toString() === lessonId
  );
  if (!alreadyCompleted) {
    progress.completedLessons.push(lessonId);
  }

  progress.lastAccessed = Date.now();
  recompute(progress, course.lessons.length);

  await progress.save();

  res.status(200).json({ success: true, progress });
});

// @desc    Get progress of all students for a course (instructor/admin view)
// @route   GET /api/progress/course/:courseId/all
// @access  Private/Instructor,Admin
const getAllProgressForCourse = asyncHandler(async (req, res) => {
  const { courseId } = req.params;

  const course = await Course.findById(courseId);
  if (!course) {
    res.status(404);
    throw new Error("Course not found");
  }

  const isOwner = course.instructor.toString() === req.user._id.toString();
  if (!isOwner && req.user.role !== "admin") {
    res.status(403);
    throw new Error("Not authorized to view progress for this course");
  }

  const progressList = await Progress.find({ course: courseId }).populate(
    "student",
    "name email"
  );

  res.status(200).json({
    success: true,
    count: progressList.length,
    progress: progressList,
  });
});

module.exports = {
  getCourseProgress,
  getMyProgress,
  markLessonComplete,
  getAllProgressForCourse,
};
