# Smart E-Learning Platform — Backend (Week 3)

Backend for the **AI Powered Smart E-Learning Web Platform** (MERN stack).
This deliverable covers: JWT authentication, user management, course
management, and student progress tracking APIs.

## Folder Structure

```
smart-elearning-backend/
├── config/
│   └── db.js                 # MongoDB connection
├── controllers/
│   ├── authController.js     # signup, login, getMe
│   ├── userController.js     # user CRUD / profile update
│   ├── courseController.js   # course CRUD / enrollment
│   └── progressController.js # progress tracking logic
├── middleware/
│   ├── authMiddleware.js     # JWT verification + role-based access
│   └── errorMiddleware.js    # centralized error handling
├── models/
│   ├── User.js                # bcrypt password hashing, roles
│   ├── Course.js               # course + embedded lessons
│   └── Progress.js             # per-student per-course progress
├── routes/
│   ├── authRoutes.js
│   ├── userRoutes.js
│   ├── courseRoutes.js
│   └── progressRoutes.js
├── utils/
│   ├── generateToken.js       # JWT signing helper
│   └── seed.js                # optional sample data seeder
├── .env.example
├── .gitignore
├── package.json
└── server.js                  # app entry point
```

## Prerequisites

- Node.js 18+
- MongoDB running locally, or a MongoDB Atlas connection string
- npm

## Setup

```bash
cd smart-elearning-backend
npm install
cp .env.example .env
# edit .env and set MONGO_URI and JWT_SECRET
npm run dev        # starts with nodemon (auto-restart)
# or
npm start          # plain node
```

The server starts on `http://localhost:5000` by default.

### (Optional) Seed sample data

```bash
npm run seed
```

This creates three users (admin, instructor, student — all with password
`Password123`) and one sample course, and prints their emails and the
course ID to the console for use in testing.

## Environment Variables (`.env`)

| Variable | Description |
|---|---|
| `PORT` | Port the server listens on (default 5000) |
| `NODE_ENV` | `development` or `production` |
| `MONGO_URI` | MongoDB connection string |
| `JWT_SECRET` | Secret used to sign JWTs — use a long random string |
| `JWT_EXPIRES_IN` | Token lifetime, e.g. `7d` |
| `CLIENT_ORIGIN` | Allowed CORS origin for your frontend |

## Authentication Model

- Passwords are hashed with **bcrypt** (via `bcryptjs`) before being saved (see `User.js` pre-save hook).
- On signup/login, a **JWT** is issued containing the user's `id` and `role`.
- Protected routes require header: `Authorization: Bearer <token>`.
- Roles: `student`, `instructor`, `admin` — enforced via the `authorize()` middleware.

## API Reference & Testing Instructions

You can test with **Postman**, **Insomnia**, or **curl**. Base URL: `http://localhost:5000/api`

### Health Check
```
GET /api/health
```

### Auth

**Signup**
```
POST /api/auth/signup
Content-Type: application/json

{
  "name": "Jane Student",
  "email": "jane@example.com",
  "password": "Password123",
  "role": "student"
}
```
curl:
```bash
curl -X POST http://localhost:5000/api/auth/signup \
  -H "Content-Type: application/json" \
  -d '{"name":"Jane Student","email":"jane@example.com","password":"Password123","role":"student"}'
```
Response includes a `token` — save it for subsequent requests.

**Login**
```
POST /api/auth/login
{
  "email": "jane@example.com",
  "password": "Password123"
}
```
curl:
```bash
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"jane@example.com","password":"Password123"}'
```

**Get current user**
```
GET /api/auth/me
Authorization: Bearer <token>
```
curl:
```bash
curl http://localhost:5000/api/auth/me -H "Authorization: Bearer <token>"
```

### User Management

| Method | Route | Access | Description |
|---|---|---|---|
| PUT | `/api/users/profile` | Logged-in user | Update own name/interests |
| GET | `/api/users` | Admin | List users (`?role=student&page=1&limit=10`) |
| GET | `/api/users/:id` | Admin | Get a user by ID |
| PUT | `/api/users/:id` | Admin | Update a user's role/status/etc. |
| DELETE | `/api/users/:id` | Admin | Delete a user |

curl example (admin listing users):
```bash
curl http://localhost:5000/api/users -H "Authorization: Bearer <admin_token>"
```

### Course Management

| Method | Route | Access | Description |
|---|---|---|---|
| GET | `/api/courses` | Public | List/search courses (`?category=&difficulty=&search=&page=&limit=`) |
| GET | `/api/courses/:id` | Public | Get a single course |
| POST | `/api/courses` | Instructor/Admin | Create a course |
| PUT | `/api/courses/:id` | Owner/Admin | Update a course |
| DELETE | `/api/courses/:id` | Owner/Admin | Delete a course |
| POST | `/api/courses/:id/enroll` | Student | Enroll in a course |

Create course curl (use an instructor or admin token):
```bash
curl -X POST http://localhost:5000/api/courses \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer <instructor_token>" \
  -d '{
    "title": "Introduction to MERN Stack",
    "description": "Learn MongoDB, Express, React, and Node.js",
    "category": "Web Development",
    "difficulty": "beginner",
    "lessons": [
      {"title": "Setting up Node & Express", "duration": 20},
      {"title": "Connecting MongoDB", "duration": 25}
    ]
  }'
```

Enroll (use a student token):
```bash
curl -X POST http://localhost:5000/api/courses/<courseId>/enroll \
  -H "Authorization: Bearer <student_token>"
```

### Student Progress

| Method | Route | Access | Description |
|---|---|---|---|
| GET | `/api/progress/me` | Student | All progress records for the logged-in student |
| GET | `/api/progress/course/:courseId` | Student | Get/initialize progress for one course |
| PUT | `/api/progress/course/:courseId/lesson/:lessonId` | Student | Mark a lesson complete (auto-recalculates % and status) |
| GET | `/api/progress/course/:courseId/all` | Instructor(owner)/Admin | View all students' progress for a course |

Mark lesson complete curl:
```bash
curl -X PUT http://localhost:5000/api/progress/course/<courseId>/lesson/<lessonId> \
  -H "Authorization: Bearer <student_token>"
```

## Testing Workflow (end-to-end example)

1. `npm run seed` to create sample admin/instructor/student + a course, or sign up manually.
2. Login as the **instructor** → copy the token → create a course, note its `_id` and each lesson's `_id` from the response.
3. Login as the **student** → copy the token → `POST /api/courses/:id/enroll`.
4. As the student, call `GET /api/progress/course/:courseId` to initialize progress.
5. As the student, call `PUT /api/progress/course/:courseId/lesson/:lessonId` for each lesson to watch `progressPercent` and `status` update.
6. As the instructor, call `GET /api/progress/course/:courseId/all` to see the student's progress.

## Postman

Import the endpoints above into a Postman collection, or set up a collection-level variable `token` and `baseUrl = http://localhost:5000/api`, then set the `Authorization` header on protected requests to `Bearer {{token}}`.

## Notes for Next Steps (beyond Week 3)

- The `User.interests` and course `tags`/`category` fields are already in place to support the personalized course recommendation feature planned for later weeks.
- Consider adding refresh tokens, email verification, and rate limiting before production deployment.
