# Week 4 — Student Progress Tracking
## AI Powered Smart E-Learning Web Platform (MERN Stack)

This module implements **Week 4** of the internship project: the Student
Progress Tracking system, built on top of the auth/course backend from
Week 2–3.

## Features implemented

| Feature | Where |
|---|---|
| Student Progress Dashboard | `client/src/components/Dashboard/ProgressDashboard.jsx` |
| Course Completion Percentage | `Progress.completionPercentage`, `CourseCompletionCard.jsx` |
| Lesson Progress Tracking | `Progress.lessonsProgress`, `LessonProgressList.jsx` |
| Quiz Progress Tracking | `Progress.quizzesProgress`, `QuizProgressList.jsx` |
| Activity History | `models/Activity.js`, `ActivityHistory.jsx` |
| Milestone Tracking | `models/Milestone.js`, `utils/milestoneChecker.js`, `MilestoneTracker.jsx` |
| Progress Charts | `ProgressCharts.jsx` (recharts: bar + line charts) |
| Backend APIs | `routes/progressRoutes.js`, `activityRoutes.js`, `milestoneRoutes.js` |
| MongoDB integration | `config/db.js`, Mongoose models |
| React frontend | `client/src` |

## Folder structure

```
week4-elearning-progress/
├── server/
│   ├── config/
│   │   └── db.js                  # MongoDB connection
│   ├── models/
│   │   ├── User.js                # minimal — full version exists from Week 2/3
│   │   ├── Course.js
│   │   ├── Lesson.js
│   │   ├── Quiz.js
│   │   ├── Progress.js            # core Week 4 model
│   │   ├── Activity.js
│   │   └── Milestone.js
│   ├── controllers/
│   │   ├── progressController.js  # dashboard, completion %, lesson/quiz updates, charts
│   │   ├── activityController.js
│   │   └── milestoneController.js
│   ├── routes/
│   │   ├── progressRoutes.js
│   │   ├── activityRoutes.js
│   │   └── milestoneRoutes.js
│   ├── middleware/
│   │   └── auth.js                # JWT protect middleware
│   ├── utils/
│   │   └── milestoneChecker.js    # awards % and quiz-master milestones
│   ├── .env.example
│   ├── package.json
│   └── server.js
└── client/
    ├── public/
    │   └── index.html
    ├── src/
    │   ├── components/
    │   │   ├── common/
    │   │   │   ├── Loader.jsx
    │   │   │   └── ProgressBar.jsx
    │   │   └── Dashboard/
    │   │       ├── ProgressDashboard.jsx   # main screen
    │   │       ├── CourseCompletionCard.jsx
    │   │       ├── LessonProgressList.jsx
    │   │       ├── QuizProgressList.jsx
    │   │       ├── ActivityHistory.jsx
    │   │       ├── MilestoneTracker.jsx
    │   │       └── ProgressCharts.jsx
    │   ├── context/
    │   │   └── AuthContext.jsx     # placeholder, replace with your Week 2/3 version
    │   ├── services/
    │   │   ├── api.js              # axios instance with JWT interceptor
    │   │   └── progressService.js  # API call wrappers
    │   ├── App.jsx
    │   ├── index.js
    │   └── index.css
    └── package.json
```

## Data model summary

- **Progress** — one document per (student, course) enrollment. Holds an
  array of `lessonsProgress` (status per lesson) and `quizzesProgress`
  (attempts/best score/passed per quiz), plus an overall
  `completionPercentage` recalculated on every update.
- **Activity** — an append-only log of everything a student does
  (`course_started`, `lesson_completed`, `quiz_attempted`, `quiz_passed`,
  `course_completed`, `milestone_achieved`). Powers the Activity History feed.
- **Milestone** — awarded automatically at 25% / 50% / 75% / 100% course
  completion, on first quiz pass, and on passing every quiz in a course
  ("Quiz Master"). A unique index prevents duplicate awards.

Completion percentage is a weighted average: 70% from lesson completion,
30% from quiz pass rate (or 100% of whichever exists if a course only has
lessons or only has quizzes).

## API endpoints

All routes below require `Authorization: Bearer <token>`.

| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/progress/dashboard` | Full dashboard: summary stats, all enrolled courses, recent activity |
| GET | `/api/progress/course/:courseId` | Detailed lesson/quiz breakdown for one course |
| POST | `/api/progress/course/:courseId/enroll` | Initialize progress tracking for a course |
| PATCH | `/api/progress/course/:courseId/lesson/:lessonId` | Update lesson status — body: `{ status, timeSpentMinutes }` |
| PATCH | `/api/progress/course/:courseId/quiz/:quizId` | Record a quiz attempt — body: `{ score }` |
| GET | `/api/progress/charts` | Chart-ready data: completion per course, lessons vs quizzes, 30-day activity trend |
| GET | `/api/activity?page=&limit=&courseId=&type=` | Paginated activity history |
| GET | `/api/milestones?courseId=` | List unlocked milestones |

## Installation instructions

### Prerequisites
- Node.js v18+ and npm
- MongoDB running locally (or an Atlas connection string)

### 1. Backend setup

```bash
cd server
npm install
cp .env.example .env
# edit .env and set MONGO_URI, JWT_SECRET, CLIENT_URL
npm run dev
```

The API starts on `http://localhost:5000` (or whatever `PORT` you set).

### 2. Frontend setup

```bash
cd client
npm install
```

Create a `.env` file in `client/` if your API isn't on the default URL:

```
REACT_APP_API_URL=http://localhost:5000/api
```

Then run:

```bash
npm start
```

The dashboard opens at `http://localhost:3000`.

### 3. Try it out

1. Log in via your existing Week 2/3 auth flow so a JWT is saved to
   `localStorage` under the key `token`.
2. Enroll in a course: `POST /api/progress/course/:courseId/enroll`.
3. Mark a lesson complete: `PATCH /api/progress/course/:courseId/lesson/:lessonId`
   with body `{ "status": "completed" }`.
4. Submit a quiz score: `PATCH /api/progress/course/:courseId/quiz/:quizId`
   with body `{ "score": 85 }`.
5. Refresh the dashboard — completion percentage, activity history, and
   any newly unlocked milestones update automatically.

## Notes for integrating into the existing project

- `User.js`, `Course.js`, `Lesson.js`, and `Quiz.js` here are minimal stand-ins.
  If these already exist from Week 1–3, keep your existing versions and just
  add the Week 4 files (`Progress.js`, `Activity.js`, `Milestone.js`,
  controllers, routes, and frontend components).
- Mount the three new route files in your existing `server.js`/`app.js`
  alongside your auth and course routes.
- Swap the placeholder `AuthContext.jsx` for your real one — the dashboard
  only needs a valid JWT in `localStorage` to work.
