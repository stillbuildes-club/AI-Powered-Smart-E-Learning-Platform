const mongoose = require("mongoose");

const courseSchema = new mongoose.Schema(
  {
    title: { type: String, required: true, trim: true },
    description: { type: String, default: "" },
    category: { type: String, default: "General" },
    instructor: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
    thumbnail: { type: String, default: "" },
    totalLessons: { type: Number, default: 0 },
    totalQuizzes: { type: Number, default: 0 },
  },
  { timestamps: true }
);

module.exports = mongoose.model("Course", courseSchema);
