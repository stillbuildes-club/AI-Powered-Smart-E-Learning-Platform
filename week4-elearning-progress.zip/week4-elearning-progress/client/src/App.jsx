import React from "react";
import ProgressDashboard from "./components/Dashboard/ProgressDashboard";

// For Week 4 this app renders the Progress Dashboard directly.
// In the full platform this is one route among others (courses, auth, etc.)
// wired up with react-router-dom from earlier weeks.
function App() {
  return (
    <div className="App">
      <ProgressDashboard />
    </div>
  );
}

export default App;
